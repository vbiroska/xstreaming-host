# Etapa 5 — capas dos jogos vindas da loja nova (Microsoft)

As capas em pé dos jogos da Loja (Início, Biblioteca e tela de carregamento) agora são as mesmas da aba Loja:
o app pega o productId no link de jogar de cada jogo e busca a capa no catálogo da Microsoft.

- Capa escolhida por você na galeria continua com prioridade.
- Se a Microsoft não responder para um jogo, ele usa a capa antiga (reserva).
- Na primeira abertura depois de atualizar, as capas antigas baixadas são apagadas e as novas são baixadas.
- Banners não mudam. Jogos obtidos na etapa 4 já usam a capa da Microsoft.

Rode `apply_covers_dart.py` dentro de `ryzen_app`, DEPOIS da etapa 4 (já está no `build.yml`).
