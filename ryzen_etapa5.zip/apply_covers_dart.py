#!/usr/bin/env python3
"""Etapa 5 (lado do Ryzen): as capas dos jogos da Loja (Início, Biblioteca, carregamento) passam a vir do
catálogo da Microsoft, as mesmas da aba Loja. Se a Microsoft não responder para um jogo, usa a capa antiga.
Rode dentro de ryzen_app, DEPOIS da etapa 4."""
import pathlib

lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"
sp = lib / "state.dart"
t = sp.read_text()

def sub(old, new, what):
    global t
    assert old in t, "não achado no state.dart: " + what
    t = t.replace(old, new, 1)

if "_msPosters" not in t:
    # 1) uma vez: descarta as capas baixadas antes (as dos jogos obtidos na etapa 4 ficam)
    sub("    if ((_p.getInt('bannerSrc') ?? 0) != 3) {", """    if ((_p.getInt('covMs') ?? 0) < 1) {
      // capas da Loja agora vêm do catálogo da Microsoft (as mesmas da aba Loja): descarta as antigas
      try {
        final base = await getApplicationSupportDirectory();
        final d = Directory('${base.path}/xbox_covers');
        if (d.existsSync()) d.deleteSync(recursive: true);
      } catch (_) {}
      storeCovMap.removeWhere((k, v) => !v.contains('xbox_owned'));
      storeCovMiss = {};
      _saveMap('storeCovMap', storeCovMap);
      _saveMap('storeCovMiss', storeCovMiss);
      _p.setInt('covMs', 1);
    }
    if ((_p.getInt('bannerSrc') ?? 0) != 3) {""", "migração de capas")

    # 2) antes do laço de download, pega os links da Microsoft de uma vez
    sub("""      final dir = Directory('${base.path}/xbox_covers');
      final now = DateTime.now().millisecondsSinceEpoch;
      for (final title in List.of(storeTitles)) {""", """      final dir = Directory('${base.path}/xbox_covers');
      final now = DateTime.now().millisecondsSinceEpoch;
      final msPoster = await _msPosters([
        for (final x in storeTitles)
          if (!storeMap.containsKey(x) && !(storeCovMap[x] != null && File(storeCovMap[x]!).existsSync())) x
      ]);
      for (final title in List.of(storeTitles)) {""", "início do laço de capas")

    # 3) Microsoft primeiro; capa antiga só como reserva
    sub("""          final link = storeCoverUrls[title];
          if (link != null) path = await CatalogCovers.download(link, dest);""",
        """          final ms = msPoster[title];
          if (ms != null) path = await CatalogCovers.download(ms, dest);
          final link = storeCoverUrls[title];
          if (path == null && link != null) path = await CatalogCovers.download(link, dest);""",
        "download da capa")

    # 4) busca no catálogo da Microsoft
    sub("  Future<void> _tick() async {", """  /// Capa em pé (Poster, senão BoxArt) do catálogo da Microsoft para os jogos da Loja que têm productId no link.
  /// Devolve título -> link da imagem. Falha de rede = só o que deu para pegar.
  Future<Map<String, String>> _msPosters(List<String> titles) async {
    final out = <String, String>{};
    final re = RegExp(r'play\\.xbox\\.com/stream/([A-Za-z0-9]+)', caseSensitive: false);
    final byPid = <String, String>{};
    for (final t in titles) {
      final m = re.firstMatch(storeLink(t));
      if (m != null) byPid[m.group(1)!.toUpperCase()] = t;
    }
    final ids = byPid.keys.toList();
    if (ids.isEmpty) return out;
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      for (var i = 0; i < ids.length; i += 20) {
        final batch = ids.sublist(i, math.min(i + 20, ids.length));
        try {
          final uri = Uri.parse('https://displaycatalog.mp.microsoft.com/v7.0/products'
              '?bigIds=${batch.join(',')}&market=BR&languages=pt-BR&MS-CV=DGU1mcuYo0WMMp%2BF.1');
          final req = await client.getUrl(uri);
          req.headers.set('Accept', 'application/json');
          final res = await req.close().timeout(const Duration(seconds: 25));
          if (res.statusCode != 200) {
            await res.drain<void>();
            continue;
          }
          final j = jsonDecode(await res.transform(utf8.decoder).join());
          final prods = j is Map ? j['Products'] : null;
          if (prods is! List) continue;
          for (final p in prods) {
            if (p is! Map) continue;
            final title = byPid[(p['ProductId'] ?? '').toString().toUpperCase()];
            final lps = p['LocalizedProperties'];
            if (title == null || lps is! List || lps.isEmpty || lps.first is! Map) continue;
            final imgs = (lps.first as Map)['Images'];
            if (imgs is! List) continue;
            String? poster, box;
            for (final im in imgs) {
              if (im is! Map) continue;
              final purpose = (im['ImagePurpose'] ?? '').toString();
              if (purpose == 'Poster') poster ??= im['Uri']?.toString();
              if (purpose == 'BoxArt') box ??= im['Uri']?.toString();
            }
            var u = poster ?? box;
            if (u == null || u.isEmpty) continue;
            if (u.startsWith('//')) u = 'https:$u';
            out[title] = u.contains('?') ? u : '$u?w=480';
          }
        } catch (_) {}
      }
    } finally {
      client.close(force: true);
    }
    return out;
  }

  Future<void> _tick() async {""", "_tick")
    sp.write_text(t)
print("ok")
