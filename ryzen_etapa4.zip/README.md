# Etapa 4 — Catálogo Xbox vira a aba Loja + botão "Obter"

## O que muda
- A aba **Loja** passa a mostrar o **Catálogo Xbox** (filtros Todos / Posso jogar / Sem acesso, busca, card do jogo).
  Os 40 jogos fixos da Loja antiga ficam ocultos nessa aba. O atalho **LT / RT Catálogo Xbox** foi removido
  (LT/RT agora trocam o filtro dentro da Loja).
- No card do jogo, o botão fica assim:
  - jogo liberado -> **Jogar na nuvem**
  - jogo bloqueado -> **Obter** (+ preço). Abre a página do jogo na loja da Microsoft dentro do app; depois de
    obter/comprar lá, ao voltar o app confere a conta. Se o jogo apareceu, o botão vira **Jogar na nuvem**
    e o jogo é **fixado na Biblioteca (e na Início)**, com capa e banner, e continua lá depois de fechar o app.
- B fecha o card; B de novo volta para a Início (comportamento normal do Ryzen).

## Arquivos
- `dart/xbox_store.dart` — substitui o da etapa 3.
- `apply_store_dart.py` — rode dentro de `ryzen_app`, DEPOIS de `apply_ryzen_dart.py` (2b) e `apply_native_dart.py` (3).
  Altera `state.dart`, `tabs.dart` e `main.dart`. Pode rodar mais de uma vez.

## Como usar
Coloque `ryzen_etapa4.zip` na raiz do repositório host, troque o `build.yml` pelo novo e rode o workflow.

## Limites (importante)
- A Microsoft não tem API pública para um app "dar" um jogo a uma conta. O que existe (`purchases/grant`) é só para
  serviços cadastrados no Partner Center. Por isso o **Obter** usa a própria página de compra da Microsoft:
  jogo grátis é um toque; jogo pago, a Microsoft cobra como sempre; jogo do Game Pass pede a assinatura.
- Pode ser preciso entrar na conta Microsoft uma vez dentro dessa página (o login do motor é separado do da WebView).
- Depois da compra a Microsoft pode levar alguns segundos para liberar o jogo na nuvem: o app tenta conferir 3 vezes.
