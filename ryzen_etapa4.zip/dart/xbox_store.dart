import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';
import 'engine_play.dart';
import 'state.dart';
import 'ui.dart';

/// Loja do Ryzen (aba "Loja"): catálogo Xbox inteiro (jogos do xCloud da sua conta, pelo motor)
/// + capa, descrição e preço do catálogo público da Microsoft.
///  - Jogo liberado: "Jogar na nuvem".
///  - Jogo bloqueado: "Obter" abre a página de compra da Microsoft (já logada), e ao voltar o app
///    confere a conta; se o jogo apareceu, libera "Jogar na nuvem" e leva o jogo para a Biblioteca.

class XboxGame {
  XboxGame(this.pid, this.titleId, this.playable);
  final String pid;
  final String titleId;
  bool playable;
  bool triedOk = false; // o catálogo já respondeu sobre este jogo
  String name = '';
  String desc = '';
  String dev = '';
  String cat = '';
  String? poster;
  String? hero;
  double? price; // preço de lista (versão completa); 0 = grátis; null = desconhecido
  String currency = '';
  final List<String> shots = [];

  String get title => name.isEmpty ? pid : name;

  String get priceText {
    final p = price;
    if (p == null) return '';
    if (p == 0) return 'Gratuito';
    final v = p.toStringAsFixed(2);
    return currency == 'BRL' || currency.isEmpty ? 'R\$ ${v.replaceAll('.', ',')}' : '$currency $v';
  }

  /// Endereço da página do jogo na loja da Microsoft (onde fica o botão de obter/comprar).
  String get storeUrl {
    var slug = name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
    if (slug.isEmpty) slug = 'game';
    return 'https://www.xbox.com/pt-BR/games/store/$slug/$pid';
  }
}

class _Catalog {
  static List<XboxGame>? games; // cache enquanto o app está aberto
  static final HttpClient _client = HttpClient()..connectionTimeout = const Duration(seconds: 12);

  static Future<List<XboxGame>> load({bool refresh = false}) async {
    if (games != null && !refresh) return games!;
    Engine.init();
    final ok = await Engine.initSession();
    if (!ok) {
      throw 'Entre na conta Microsoft abrindo um jogo uma vez e volte aqui.';
    }
    final t = await EnginePlay.titles(refresh: refresh);
    final list = <XboxGame>[];
    t.forEach((pid, v) {
      list.add(XboxGame(pid, (v['titleId'] ?? '').toString(), v['playable'] == true));
    });
    return games = list;
  }

  static String? _img(dynamic u, int w) {
    if (u == null) return null;
    var x = u.toString();
    if (x.isEmpty) return null;
    if (x.startsWith('//')) x = 'https:$x';
    return x.contains('?') ? x : '$x?w=$w';
  }

  /// Menor preço de lista entre as versões completas (ignora demos/testes).
  static void _price(XboxGame g, Map p) {
    final dsa = p['DisplaySkuAvailabilities'];
    if (dsa is! List) return;
    double? best;
    var cur = '';
    for (final sku in dsa) {
      if (sku is! Map) continue;
      final info = sku['Sku'];
      if (info is Map && info['SkuType'] != null && info['SkuType'].toString().toLowerCase() != 'full') continue;
      final avs = sku['Availabilities'];
      if (avs is! List) continue;
      for (final av in avs) {
        if (av is! Map) continue;
        final acts = av['Actions'];
        if (acts is List && !acts.contains('Purchase')) continue;
        final om = av['OrderManagementData'];
        final pr = om is Map ? om['Price'] : null;
        if (pr is! Map) continue;
        final lp = pr['ListPrice'];
        if (lp is! num) continue;
        final v = lp.toDouble();
        if (best == null || v < best) {
          best = v;
          cur = (pr['CurrencyCode'] ?? '').toString();
        }
      }
    }
    g.price = best;
    g.currency = cur;
  }

  /// Busca nome, capa, descrição, categoria e preço de um lote de jogos (até ~20 por chamada).
  static Future<void> fetchDetails(List<XboxGame> batch) async {
    final todo = batch.where((g) => !g.triedOk).toList();
    if (todo.isEmpty) return;
    try {
      final ids = todo.map((g) => g.pid).join(',');
      final uri = Uri.parse('https://displaycatalog.mp.microsoft.com/v7.0/products'
          '?bigIds=$ids&market=BR&languages=pt-BR&MS-CV=DGU1mcuYo0WMMp%2BF.1');
      final req = await _client.getUrl(uri);
      req.headers.set('Accept', 'application/json');
      final res = await req.close().timeout(const Duration(seconds: 25));
      if (res.statusCode != 200) {
        await res.drain<void>();
        return;
      }
      final body = await res.transform(utf8.decoder).join();
      final j = jsonDecode(body);
      final prods = (j is Map ? j['Products'] : null) as List? ?? const [];
      final byId = {for (final g in todo) g.pid: g};
      for (final p in prods) {
        if (p is! Map) continue;
        final g = byId[(p['ProductId'] ?? '').toString().toUpperCase()];
        if (g == null) continue;
        final lps = p['LocalizedProperties'];
        if (lps is! List || lps.isEmpty || lps.first is! Map) continue;
        final lp = lps.first as Map;
        g.name = (lp['ProductTitle'] ?? '').toString();
        final sd = (lp['ShortDescription'] ?? '').toString();
        g.desc = sd.isNotEmpty ? sd : (lp['ProductDescription'] ?? '').toString();
        g.dev = (lp['DeveloperName'] ?? lp['PublisherName'] ?? '').toString();
        final props = p['Properties'];
        g.cat = props is Map ? (props['Category'] ?? '').toString() : '';
        _price(g, p);
        final imgs = lp['Images'];
        String? poster, box, hero, titled, key;
        if (imgs is List) {
          for (final im in imgs) {
            if (im is! Map) continue;
            final purpose = (im['ImagePurpose'] ?? '').toString();
            final u = im['Uri'];
            if (purpose == 'Poster') poster ??= _img(u, 480);
            if (purpose == 'BoxArt') box ??= _img(u, 480);
            if (purpose == 'SuperHeroArt') hero ??= _img(u, 1280);
            if (purpose == 'TitledHeroArt') titled ??= _img(u, 1280);
            if (purpose == 'BrandedKeyArt') key ??= _img(u, 1280);
            if (purpose == 'Screenshot' && g.shots.length < 4) {
              final sImg = _img(u, 640);
              if (sImg != null) g.shots.add(sImg);
            }
          }
        }
        g.poster = poster ?? box;
        g.hero = hero ?? titled ?? key;
        g.triedOk = true;
      }
      // quem o catálogo não devolveu não será pedido de novo
      for (final g in todo) {
        g.triedOk = true;
      }
    } catch (_) {
      // sem rede agora: tenta de novo na próxima vez
    }
  }
}

/// Estado da Loja. Fica fora da aba para não perder a lista, o filtro e a posição ao trocar de aba.
final xc = XboxCatalog();

class XboxCatalog extends ChangeNotifier {
  static const filters = ['Todos', 'Posso jogar', 'Sem acesso'];

  final ScrollController gc = ScrollController();
  List<XboxGame> all = [];
  bool loading = false;
  bool loaded = false;
  String? error;
  int filter = 0;
  String q = '';
  int idx = 0;
  int cols = 6;
  double cellH = 300;
  XboxGame? detail;
  String? busy; // texto enquanto confere a conta
  String? note; // resultado da última tentativa de obter
  bool noteOk = false;
  bool _bg = false;

  /// Carrega a lista na primeira vez que a aba Loja é aberta.
  void ensureLoaded() {
    if (loaded || loading) return;
    load();
  }

  Future<void> load({bool refresh = false}) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final l = await _Catalog.load(refresh: refresh);
      all = [...l.where((g) => g.playable), ...l.where((g) => !g.playable)];
      loaded = true;
      loading = false;
      notifyListeners();
      _background();
    } catch (e) {
      error = e.toString().replaceFirst('PlatformException', '').trim();
      loading = false;
      notifyListeners();
    }
  }

  /// Carrega as capas aos poucos (3 pedidos ao mesmo tempo), na ordem da lista.
  Future<void> _background() async {
    if (_bg) return;
    _bg = true;
    final src = List<XboxGame>.of(all);
    const bs = 20;
    var next = 0;
    Future<void> worker() async {
      while (true) {
        final i = next;
        if (i >= src.length) break;
        next = i + bs;
        await _Catalog.fetchDetails(src.sublist(i, math.min(i + bs, src.length)));
        notifyListeners();
      }
    }

    try {
      await Future.wait([worker(), worker(), worker()]);
    } finally {
      _bg = false;
    }
  }

  List<XboxGame> get list {
    final s = q.toLowerCase();
    return all.where((g) {
      if (g.triedOk && g.name.isEmpty) return false; // não está no catálogo da loja
      if (filter == 1 && !g.playable) return false;
      if (filter == 2 && g.playable) return false;
      if (s.isNotEmpty && !g.name.toLowerCase().contains(s)) return false;
      return true;
    }).toList();
  }

  void follow() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      followIndex(gc, (idx ~/ cols) * cellH, cellH);
    });
  }

  void _move(int d, int len) {
    if (len == 0) return;
    final n = (idx + d).clamp(0, len - 1).toInt();
    if (n == idx) return;
    idx = n;
    st.sfx('move');
    notifyListeners();
    follow();
  }

  void setFilter(int d) {
    filter = (filter + d + filters.length) % filters.length;
    idx = 0;
    st.sfx('tab');
    if (gc.hasClients) gc.jumpTo(0);
    notifyListeners();
  }

  void setFilterTo(int i) {
    filter = i;
    idx = 0;
    if (gc.hasClients) gc.jumpTo(0);
    notifyListeners();
  }

  void select(int i) {
    idx = i;
    notifyListeners();
  }

  void openDetail(XboxGame g) {
    detail = g;
    note = null;
    st.sfx('ok');
    notifyListeners();
  }

  void closeDetail() {
    detail = null;
    note = null;
    st.sfx('back');
    notifyListeners();
  }

  Future<void> search() async {
    final ctx = EnginePlay.navKey.currentState?.overlay?.context;
    if (ctx == null) return;
    final c = TextEditingController(text: q);
    final r = await showDialog<String>(
      context: ctx,
      builder: (d) => AlertDialog(
        title: const Text('Buscar jogo'),
        content: TextField(
          controller: c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onSubmitted: (v) => Navigator.pop(d, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, ''), child: const Text('Limpar')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('Buscar')),
        ],
      ),
    );
    if (r != null) {
      q = r.trim();
      idx = 0;
      if (gc.hasClients) gc.jumpTo(0);
      notifyListeners();
    }
  }

  /// Teclas / controle (chamado pelo st.act quando a aba Loja está aberta).
  /// true = a Loja tratou a tecla.
  bool act(Act a) {
    if (busy != null) return true; // conferindo a conta: ignora o resto
    final d = detail;
    if (d != null) {
      if (a == Act.cancel) {
        closeDetail();
      } else if (a == Act.accept) {
        primary(d);
      }
      return true;
    }
    final l = list;
    switch (a) {
      case Act.left:
        _move(-1, l.length);
        return true;
      case Act.right:
        _move(1, l.length);
        return true;
      case Act.up:
        _move(-cols, l.length);
        return true;
      case Act.down:
        _move(cols, l.length);
        return true;
      case Act.accept:
        if (l.isNotEmpty) openDetail(l[math.min(idx, l.length - 1)]);
        return true;
      case Act.filterNext:
        setFilter(1);
        return true;
      case Act.filterPrev:
        setFilter(-1);
        return true;
      case Act.search:
        search();
        return true;
      case Act.details:
      case Act.favorite:
        return true;
      default:
        return false; // cancelar, trocar de aba, menu: segue o comportamento normal do Ryzen
    }
  }

  /// Botão principal do card: jogar (se liberado) ou obter (se bloqueado).
  void primary(XboxGame g) {
    if (busy != null) return;
    if (g.playable) {
      play(g);
    } else {
      acquire(g);
    }
  }

  void play(XboxGame g) {
    final cover = g.poster != null ? NetworkImage(g.poster!) : null;
    final banner = g.hero != null ? NetworkImage(g.hero!) : null;
    final title = st.xboxTitleFor(g.pid) ?? g.title;
    final inLib = storeTitles.contains(title);
    detail = null;
    notifyListeners();
    EnginePlay.play(
      'https://play.xbox.com/stream/${g.pid}',
      title,
      cover: cover,
      banner: banner,
      // a tela de carregamento já se fecha sozinha; só mostra o stream
      onReady: (info) =>
          st.openStream(info, key: inLib ? RyzenState.storeKey(title) : null, title: title, cover: cover, banner: banner),
    );
  }

  /// "Obter": abre a página de compra da Microsoft (a conta é a mesma do app) e, ao voltar,
  /// confere se o jogo entrou na conta.
  Future<void> acquire(XboxGame g) async {
    final nav = EnginePlay.navKey.currentState;
    if (nav == null) return;
    st.sfx('ok');
    note = null;
    await nav.push<void>(MaterialPageRoute(builder: (_) => _AcquirePage(game: g)));
    await _verify(g);
  }

  Future<void> _verify(XboxGame g) async {
    busy = 'Conferindo sua conta…';
    notifyListeners();
    var ok = false;
    try {
      // a Microsoft pode levar alguns segundos para liberar o jogo na nuvem
      for (var i = 0; i < 3 && !ok; i++) {
        if (i > 0) await Future<void>.delayed(const Duration(seconds: 3));
        ok = await _refreshOwnership(g);
      }
    } catch (_) {}
    if (ok) {
      busy = 'Adicionando à Biblioteca…';
      notifyListeners();
      try {
        await st.addXboxGame(g.title, g.pid, posterUrl: g.poster, heroUrl: g.hero);
      } catch (_) {}
      all = [...all.where((e) => e.playable), ...all.where((e) => !e.playable)];
      final i = list.indexWhere((e) => identical(e, g));
      if (i >= 0) idx = i;
      note = 'Pronto! O jogo entrou na sua conta e está na Biblioteca. Já dá para jogar na nuvem.';
      noteOk = true;
      st.sfx('ok');
    } else {
      note = 'O jogo ainda não apareceu na sua conta. Se você concluiu a compra, espere um pouco e toque em Obter para conferir de novo.';
      noteOk = false;
    }
    busy = null;
    notifyListeners();
  }

  Future<bool> _refreshOwnership(XboxGame g) async {
    final t = await EnginePlay.titles(refresh: true);
    for (final x in all) {
      final v = t[x.pid];
      if (v != null) x.playable = v['playable'] == true;
    }
    return g.playable;
  }
}

// ============================ TELA (dentro da aba Loja) ============================
class XboxStoreView extends StatefulWidget {
  const XboxStoreView({super.key});
  @override
  State<XboxStoreView> createState() => _XboxStoreViewState();
}

class _XboxStoreViewState extends State<XboxStoreView> {
  @override
  void initState() {
    super.initState();
    xc.ensureLoaded();
    xc.follow();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: xc,
      builder: (context, _) {
        final s = context.s;
        return Stack(children: [
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.fromLTRB(30 * s, 10 * s, 30 * s, 10 * s),
              child: Column(children: [
                _header(context),
                SizedBox(height: 12 * s),
                Expanded(child: _body(context)),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('LT / RT  Filtrar', style: ts(context, 14, color: st.subTxt)),
                ),
              ]),
            ),
          ),
          if (xc.detail != null) _detailView(context, xc.detail!),
          if (xc.busy != null)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black54,
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const CircularProgressIndicator(),
                    SizedBox(height: 14 * s),
                    Text(xc.busy!, style: ts(context, 18, color: Colors.white)),
                  ]),
                ),
              ),
            ),
        ]);
      },
    );
  }

  Widget _header(BuildContext context) {
    final s = context.s;
    return Row(children: [
      for (int i = 0; i < XboxCatalog.filters.length; i++)
        Padding(
          padding: EdgeInsets.only(right: 10 * s),
          child: GestureDetector(
            onTap: () => xc.setFilterTo(i),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 18 * s, vertical: 8 * s),
              decoration: BoxDecoration(
                color: i == xc.filter ? st.accent : Colors.transparent,
                borderRadius: BorderRadius.circular(30 * s),
                border: Border.all(color: st.accent, width: 2 * s),
              ),
              child: Text(XboxCatalog.filters[i],
                  style: ts(context, 17, color: i == xc.filter ? Colors.white : st.txt)),
            ),
          ),
        ),
      const Spacer(),
      if (xc.q.isNotEmpty) Text('"${xc.q}"  ', style: ts(context, 16, color: st.subTxt)),
      GestureDetector(
        onTap: xc.search,
        child: Icon(Icons.search, color: st.txt, size: 28 * s),
      ),
      SizedBox(width: 14 * s),
      Text('${xc.list.length} jogos', style: ts(context, 15, color: st.subTxt)),
    ]);
  }

  Widget _body(BuildContext context) {
    final s = context.s;
    if (xc.loading) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircularProgressIndicator(),
          SizedBox(height: 16 * s),
          Text('Carregando os jogos da sua conta...', style: ts(context, 16, color: st.subTxt)),
        ]),
      );
    }
    if (xc.error != null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(xc.error!, textAlign: TextAlign.center, style: ts(context, 18, color: Colors.redAccent)),
          SizedBox(height: 16 * s),
          FilledButton(onPressed: () => xc.load(refresh: true), child: const Text('Tentar de novo')),
        ]),
      );
    }
    final list = xc.list;
    if (list.isEmpty) {
      return Center(
        child: Text(xc.all.isEmpty ? 'Nenhum jogo encontrado.' : 'Nenhum jogo com esse filtro ou busca.',
            style: ts(context, 18, color: st.subTxt)),
      );
    }
    final sel = math.min(xc.idx, list.length - 1);
    return LayoutBuilder(builder: (ctx, c) {
      xc.cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
      xc.cellH = c.maxWidth / xc.cols * 335 / 235;
      return GridView.builder(
        controller: xc.gc,
        padding: EdgeInsets.zero,
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 235 * s,
          childAspectRatio: 235 / 335,
        ),
        itemCount: list.length,
        itemBuilder: (c2, i) {
          final g = list[i];
          final cur = i == sel;
          return GestureDetector(
            onTap: () {
              xc.select(i);
              xc.openDetail(g);
            },
            child: FractionallySizedBox(
              widthFactor: 205 / 235,
              heightFactor: 300 / 335,
              child: AnimatedScale(
                scale: cur ? 1.05 : 1.0,
                duration: const Duration(milliseconds: 120),
                child: Glass(
                  radius: 14 * s,
                  frosted: false,
                  border: cur ? Colors.white : st.tileEdge,
                  borderWidth: cur ? 4 * s : 1,
                  child: Stack(children: [
                    Padding(
                      padding: EdgeInsets.all(6 * s),
                      child: Art(
                        img: g.poster != null ? NetworkImage(g.poster!) : null,
                        fit: BoxFit.cover,
                        title: g.name.isEmpty ? '...' : g.name,
                      ),
                    ),
                    Positioned(
                      top: 10 * s,
                      right: 10 * s,
                      child: Icon(
                        g.playable ? Icons.check_circle : Icons.lock,
                        size: 22 * s,
                        color: g.playable ? Colors.lightGreenAccent : Colors.white70,
                      ),
                    ),
                  ]),
                ),
              ),
            ),
          );
        },
      );
    });
  }

  Widget _detailView(BuildContext context, XboxGame g) {
    final s = context.s;
    final name = g.title;
    final sub = [if (g.dev.isNotEmpty) g.dev, if (g.cat.isNotEmpty) g.cat].join('  ·  ');
    final playable = g.playable;
    return Positioned.fill(
      child: GestureDetector(
        onTap: xc.closeDetail,
        child: Container(
          color: Colors.black87,
          alignment: Alignment.center,
          child: GestureDetector(
            onTap: () {},
            child: Container(
              width: 1000 * s,
              constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height - 230 * s),
              decoration: BoxDecoration(
                color: const Color(0xFF141923),
                borderRadius: BorderRadius.circular(18 * s),
              ),
              clipBehavior: Clip.antiAlias,
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  if (g.hero != null)
                    SizedBox(
                      height: 180 * s,
                      width: double.infinity,
                      child: Image(
                        image: ResizeImage(NetworkImage(g.hero!), width: 1280),
                        fit: BoxFit.cover,
                        errorBuilder: (c, e, st2) => const SizedBox.shrink(),
                      ),
                    ),
                  Padding(
                    padding: EdgeInsets.all(22 * s),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      SizedBox(
                        width: 160 * s,
                        height: 229 * s,
                        child: Glass(
                          radius: 12 * s,
                          frosted: false,
                          child: Padding(
                            padding: EdgeInsets.all(5 * s),
                            child: Art(
                              img: g.poster != null ? NetworkImage(g.poster!) : null,
                              fit: BoxFit.cover,
                              title: name,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 22 * s),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(name, style: ts(context, 28, bold: true, color: Colors.white)),
                          if (sub.isNotEmpty) ...[
                            SizedBox(height: 4 * s),
                            Text(sub, style: ts(context, 15, color: Colors.white60)),
                          ],
                          SizedBox(height: 10 * s),
                          Row(children: [
                            Icon(playable ? Icons.check_circle : Icons.lock,
                                size: 20 * s, color: playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                            SizedBox(width: 8 * s),
                            Expanded(
                              child: Text(
                                playable
                                    ? 'Disponível para jogar na nuvem'
                                    : 'Sua conta não tem este jogo ainda. Toque em Obter para adicioná-lo.',
                                style: ts(context, 16,
                                    color: playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                              ),
                            ),
                          ]),
                          if (xc.note != null) ...[
                            SizedBox(height: 8 * s),
                            Text(xc.note!,
                                style: ts(context, 15, color: xc.noteOk ? Colors.lightGreenAccent : Colors.white70)),
                          ],
                          SizedBox(height: 12 * s),
                          Text(g.desc.isEmpty ? 'Sem descrição.' : g.desc,
                              maxLines: 5,
                              overflow: TextOverflow.ellipsis,
                              style: ts(context, 16, color: Colors.white70)),
                          SizedBox(height: 16 * s),
                          Row(children: [
                            FilledButton.icon(
                              onPressed: () => xc.primary(g),
                              icon: Icon(playable ? Icons.play_arrow : Icons.add_shopping_cart),
                              label: Text(playable ? 'Jogar na nuvem' : 'Obter'),
                            ),
                            if (!playable && g.priceText.isNotEmpty) ...[
                              SizedBox(width: 12 * s),
                              Text(g.priceText, style: ts(context, 17, bold: true, color: Colors.white)),
                            ],
                            SizedBox(width: 12 * s),
                            TextButton(onPressed: xc.closeDetail, child: const Text('Fechar')),
                          ]),
                        ]),
                      ),
                    ]),
                  ),
                  if (g.shots.isNotEmpty)
                    Padding(
                      padding: EdgeInsets.fromLTRB(22 * s, 0, 22 * s, 22 * s),
                      child: SizedBox(
                        height: 110 * s,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: g.shots.length,
                          separatorBuilder: (_, __) => SizedBox(width: 10 * s),
                          itemBuilder: (c, i) => ClipRRect(
                            borderRadius: BorderRadius.circular(8 * s),
                            child: Image(
                              image: ResizeImage(NetworkImage(g.shots[i]), width: 420),
                              fit: BoxFit.cover,
                              errorBuilder: (c2, e, st2) => const SizedBox.shrink(),
                            ),
                          ),
                        ),
                      ),
                    ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================ OBTER (página de compra da Microsoft) ============================
/// Abre a página do jogo na loja da Microsoft dentro do app. O botão "Obter/Comprar" dali coloca
/// o jogo na conta (grátis ou pago, a Microsoft é quem cobra). Ao fechar, o catálogo confere a conta.
class _AcquirePage extends StatefulWidget {
  const _AcquirePage({required this.game});
  final XboxGame game;

  @override
  State<_AcquirePage> createState() => _AcquirePageState();
}

class _AcquirePageState extends State<_AcquirePage> {
  late final WebViewController _c;
  bool _loading = true;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36')
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) {
          if (mounted) setState(() => _loading = true);
        },
        onPageFinished: (_) {
          if (mounted) setState(() => _loading = false);
        },
        onWebResourceError: (e) {
          if (e.isForMainFrame ?? true) {
            if (mounted) {
              setState(() {
                _error = true;
                _loading = false;
              });
            }
          }
        },
      ))
      ..loadRequest(Uri.parse(widget.game.storeUrl));
  }

  void _retry() {
    setState(() {
      _error = false;
      _loading = true;
    });
    _c.loadRequest(Uri.parse(widget.game.storeUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          Container(
            color: const Color(0xFF141923),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(children: [
              IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
              ),
              Expanded(
                child: Text(widget.game.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 18, decoration: TextDecoration.none)),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).maybePop(),
                child: const Text('Concluí / Voltar'),
              ),
            ]),
          ),
          Expanded(
            child: Stack(children: [
              Positioned.fill(child: WebViewWidget(controller: _c)),
              if (_loading && !_error) const Center(child: CircularProgressIndicator()),
              if (_error)
                Positioned.fill(
                  child: ColoredBox(
                    color: Colors.black,
                    child: Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('Sem conexão com a loja da Microsoft.',
                            style: TextStyle(color: Colors.white, fontSize: 16, decoration: TextDecoration.none)),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: _retry, child: const Text('Tentar de novo')),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}
