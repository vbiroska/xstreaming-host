#!/usr/bin/env python3
"""Etapa 4 (lado do Ryzen): o Catálogo Xbox vira a aba Loja e o botão "Obter" põe o jogo na conta.
Rode dentro de ryzen_app, DEPOIS do apply_ryzen_dart.py (etapa 2b) e do apply_native_dart.py (etapa 3)."""
import pathlib, re, shutil

HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"
assert (lib / "xbox_store.dart").exists(), "rode a etapa 3 antes (xbox_store.dart não existe)"

# 1) tela nova (substitui a da etapa 3)
shutil.copy(HERE / "dart" / "xbox_store.dart", lib / "xbox_store.dart")

# ---------------------------------------------------------------- state.dart
sp = lib / "state.dart"
t = sp.read_text()

def sub(old, new, what):
    global t
    assert old in t, "não achado no state.dart: " + what
    t = t.replace(old, new, 1)

# a lista de títulos da Loja passa a poder crescer (jogos obtidos entram nela)
if "List<String>.unmodifiable(_allStoreTitles)" in t:
    sub("final storeTitles = List<String>.unmodifiable(_allStoreTitles);",
        "final storeTitles = List<String>.of(_allStoreTitles); // cresce com os jogos obtidos no Catálogo Xbox",
        "storeTitles")

# tira o atalho antigo (LT/RT abria o catálogo por cima do Ryzen)
old_open = """  /// Abre o Catálogo Xbox (loja própria) por cima do Ryzen.
  void openXboxStore() {
    final nav = EnginePlay.navKey.currentState;
    if (nav == null) return;
    sfx('ok');
    nav.push(MaterialPageRoute(builder: (_) => const XboxStorePage()));
  }

"""
if old_open in t:
    t = t.replace(old_open, "", 1)
old_filter = """      if (tab == 1) {
        setFilter(a == Act.filterNext ? 1 : -1);
      } else if (tab == 2) {
        openXboxStore();
      }"""
if old_filter in t:
    t = t.replace(old_filter, "      if (tab == 1) setFilter(a == Act.filterNext ? 1 : -1);", 1)
assert "openXboxStore" not in t and "XboxStorePage" not in t, "sobrou referência ao catálogo antigo no state.dart"

# a aba Loja recebe as teclas/controle antes do resto
if "xc.act(a)" not in t:
    sub("""    if (layer != Layer.none) {
      _layerAct(a);
      return;
    }
    if (a == Act.menu) {""",
        """    if (layer != Layer.none) {
      _layerAct(a);
      return;
    }
    // aba Loja = Catálogo Xbox: setas, A, B (fecha o card), LT/RT (filtro) e Select (buscar) são dele
    if (tab == 2 && a != Act.menu && a != Act.next && a != Act.prev && xc.act(a)) return;
    if (a == Act.menu) {""", "início do act()")

# jogos obtidos: campo, restauração ao abrir o app e métodos
if "xboxGames" not in t:
    sub("  List<String> pinned = [];",
        "  List<String> pinned = [];\n  List<Map<String, String>> xboxGames = []; // obtidos no Catálogo Xbox: pid, title, poster, hero",
        "campo pinned")
    sub("    autoLinks = _strMap(_p.getString('autoLinks'));\n",
        "    autoLinks = _strMap(_p.getString('autoLinks'));\n    _restoreXboxGames();\n",
        "carga do autoLinks")
    sub("  void togglePin(String title) {", """  // ---------- jogos obtidos pelo Catálogo Xbox (vão para a Biblioteca e para a Início) ----------
  /// Nome com que o jogo (productId) aparece na Biblioteca; null se ainda não foi adicionado.
  String? xboxTitleFor(String pid) {
    for (final g in xboxGames) {
      if (g['pid'] == pid) return g['title'];
    }
    return null;
  }

  void _applyXboxGame(Map<String, String> g) {
    final title = g['title'] ?? '';
    final pid = g['pid'] ?? '';
    if (title.isEmpty || pid.isEmpty) return;
    if (!storeTitles.contains(title)) storeTitles.add(title);
    autoLinks[title] = 'https://play.xbox.com/stream/$pid';
  }

  void _restoreXboxGames() {
    xboxGames = [];
    for (final j in _p.getStringList('xboxGames') ?? const <String>[]) {
      try {
        final m = (jsonDecode(j) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
        xboxGames.add(m);
        _applyXboxGame(m);
      } catch (_) {}
    }
    if (xboxGames.isNotEmpty) _fetchXboxArt();
  }

  /// Baixa capa e banner dos jogos obtidos que ainda não estão no aparelho.
  Future<void> _fetchXboxArt() async {
    try {
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/xbox_owned');
      for (final g in xboxGames) {
        final t = g['title'] ?? '';
        final pid = g['pid'] ?? '';
        final poster = g['poster'] ?? '';
        final hero = g['hero'] ?? '';
        if (t.isEmpty || pid.isEmpty) continue;
        if (poster.isNotEmpty && !storeMap.containsKey(t)) {
          final have = storeCovMap[t];
          if (have == null || !File(have).existsSync()) {
            final p = await CatalogCovers.download(poster, File('${dir.path}/$pid.jpg'));
            if (p != null) {
              storeCovMap[t] = p;
              _saveMap('storeCovMap', storeCovMap);
            }
          }
        }
        if (hero.isNotEmpty) {
          final have = bannerMap[t];
          if (have == null || !File(have).existsSync()) {
            final p = await CatalogCovers.download(hero, File('${dir.path}/${pid}_banner.jpg'));
            if (p != null) {
              bannerMap[t] = p;
              _saveMap('bannerMap', bannerMap);
            }
          }
        }
      }
      notifyListeners();
    } catch (_) {}
  }

  /// Leva um jogo recém-obtido para a Biblioteca: vira um jogo fixado (Biblioteca e Início), com capa e banner.
  Future<String> addXboxGame(String title, String pid, {String? posterUrl, String? heroUrl}) async {
    final known = xboxTitleFor(pid);
    var name = known ?? title;
    if (known == null) {
      // nome igual ao de outro jogo da Loja (com outro link): diferencia
      final link = storeLink(name);
      if (storeTitles.contains(name) && link.isNotEmpty && !link.toUpperCase().contains(pid.toUpperCase())) {
        name = '$title (Xbox)';
      }
      xboxGames.add({'pid': pid, 'title': name, 'poster': posterUrl ?? '', 'hero': heroUrl ?? ''});
      _p.setStringList('xboxGames', [for (final g in xboxGames) jsonEncode(g)]);
    }
    _applyXboxGame({'pid': pid, 'title': name});
    _saveMap('autoLinks', autoLinks);
    if (!pinned.contains(name)) {
      pinned.add(name);
      _p.setStringList('pinnedStore', pinned);
    }
    _rebuild();
    notifyListeners();
    await _fetchXboxArt();
    return name;
  }

  void togglePin(String title) {""", "togglePin")
sp.write_text(t)

# ---------------------------------------------------------------- tabs.dart
tp = lib / "tabs.dart"
tb = tp.read_text()
a = "// ============================ LOJA ============================\n"
b = "// ============================ CONFIG ============================"
assert a in tb and b in tb, "marcadores LOJA/CONFIG não achados no tabs.dart"
i, j = tb.index(a), tb.index(b)
if "XboxStoreView" not in tb[i:j]:
    tb = tb[:i] + a + """/// Aba Loja = Catálogo Xbox (jogos do xCloud da sua conta). Os jogos fixos da Loja antiga ficam ocultos aqui.
class StoreTab extends StatelessWidget {
  const StoreTab({super.key});

  @override
  Widget build(BuildContext context) => const XboxStoreView();
}

""" + tb[j:]
if "import 'xbox_store.dart';" not in tb:
    k = "import 'covers.dart';"
    assert k in tb, "import covers.dart não achado no tabs.dart"
    tb = tb.replace(k, k + "\nimport 'xbox_store.dart';", 1)
tp.write_text(tb)

# ---------------------------------------------------------------- main.dart (rodapé)
mp = lib / "main.dart"
m = mp.read_text()
old = "tr(st.tab == 2 ? 'Fixar / Desafixar na Início' : 'Selecionar')"
if old in m:
    m = m.replace(old, "tr(st.tab == 2 ? 'Abrir' : 'Selecionar')", 1)
    mp.write_text(m)
print("ok")
