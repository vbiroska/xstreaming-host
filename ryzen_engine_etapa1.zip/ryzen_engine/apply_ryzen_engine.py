#!/usr/bin/env python3
"""Aplica a Etapa 1 na raiz do projeto XStreaming. Rode da raiz: python3 ryzen_engine/apply_ryzen_engine.py"""
import re, shutil, pathlib, sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()
JAVA = ROOT / "android/app/src/main/java/com/xstreaming"
assert JAVA.is_dir(), "rode na raiz do XStreaming"

# 1) arquivos novos
(ROOT / "src/ryzen").mkdir(exist_ok=True)
shutil.copy(HERE / "src/ryzen/RyzenEngine.ts", ROOT / "src/ryzen/RyzenEngine.ts")
shutil.copy(HERE / "index.ryzen.js", ROOT / "index.ryzen.js")
for f in (HERE / "android/com/xstreaming").glob("*.java"):
    shutil.copy(f, JAVA / f.name)

# 2) MainApplication.java
p = JAVA / "MainApplication.java"
s = p.read_text()
if "RyzenEnginePackage" not in s:
    s = s.replace("packages.add(new XalPackage());",
                  "packages.add(new XalPackage());\n            packages.add(new RyzenEnginePackage());", 1)
    s = s.replace('return "index";', 'return "index.ryzen";', 1)
    selftest = '''
    // --- Ryzen: autoteste do motor (só registra o resultado no log, sem aviso na tela) ---
    RyzenEngine.start(this);
    RyzenEngine.call("init", "{}", (ok, json) -> {
      android.util.Log.i("RyzenEngine", "init ok=" + ok + " " + json);
    });
  }
}'''
    s = re.sub(r"\n  }\n}\s*$", selftest + "\n", s)
    p.write_text(s)

# 3) build.gradle: achar o clang do NDK no Linux (o original só procurava macOS)
g = ROOT / "android/app/build.gradle"
t = g.read_text()
if "linux-x86_64" not in t:
    t = re.sub(r"def nanoRustHostTag = \{ ndkDir ->.*?\n\}\n",
        'def nanoRustHostTag = { ndkDir ->\n'
        '    for (tag in ["linux-x86_64", "darwin-arm64", "darwin-x86_64", "windows-x86_64"]) {\n'
        '        if (file("${ndkDir}/toolchains/llvm/prebuilt/${tag}").exists()) return tag\n'
        '    }\n'
        '    return "linux-x86_64"\n}\n', t, count=1, flags=re.S)
    g.write_text(t)
# 4) o bundle do release deve sair do index.ryzen.js (senão o motor não é carregado)
t = g.read_text()
if 'index.ryzen.js' not in t:
    t = t.replace("react {\n", 'react {\n    entryFile = file("../../index.ryzen.js")\n', 1)
    g.write_text(t)
print("ok")
