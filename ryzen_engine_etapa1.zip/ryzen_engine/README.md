# Etapa 1 — motor do XStreaming sem tela

## No projeto XStreaming (hospedeiro)
1. Copie `index.ryzen.js` para a raiz e `src/ryzen/RyzenEngine.ts` para `src/ryzen/`.
2. Copie `android/com/xstreaming/*.java` para `android/app/src/main/java/com/xstreaming/`.
3. `MainApplication.java`:
   - em `getPackages()`: `packages.add(new RyzenEnginePackage());`
   - `getJSMainModuleName()` passa a devolver `"index.ryzen"` (o bundle não leva mais as telas do XStreaming).

## No Ryzen (Flutter)
4. `flutter/engine.dart` -> `lib/engine.dart` e chame `Engine.init()` no `main()`.
5. Cole `flutter/MainActivity_engine_snippet.kt` no `MainActivity.kt`.

## Teste rápido
`Engine.initSession()` → `false` na 1ª vez → `Engine.loginStart()` devolve `authUrl`
→ abra no WebView até a URL começar com `ms-xal-000000004c20a908:` → `Engine.loginFinish(url)`
→ `Engine.titles()` deve listar os jogos → `Engine.prepareStream(titleId)` devolve o `streamInfo`.
