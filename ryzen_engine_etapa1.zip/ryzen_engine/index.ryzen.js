/**
 * Entrada do motor do Ryzen: sem telas, só login + sessão do xCloud.
 */
import {AppRegistry} from 'react-native';
import './src/ryzen/RyzenEngine';

// A MainActivity do XStreaming ainda pede o componente "xstreaming".
// Registramos um vazio para não dar erro (no Ryzen final essa Activity não é usada).
AppRegistry.registerComponent('xstreaming', () => () => null);
