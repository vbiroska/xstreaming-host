package com.xstreaming;

import android.app.Application;

import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Liga o React Native sem tela e faz chamadas ao motor JS (RPC por JSON). */
public final class RyzenEngine {
    public interface Result { void done(boolean ok, String json); }
    public interface Events { void on(String name, String json); }

    private static final Map<String, Result> pending = new ConcurrentHashMap<>();
    private static final List<Runnable> queued = new ArrayList<>();
    private static ReactInstanceManager mgr;
    private static volatile ReactContext ctx;
    private static volatile Events events;

    private RyzenEngine() {}

    public static synchronized void start(Application app) {
        if (mgr != null) return;
        mgr = ((ReactApplication) app).getReactNativeHost().getReactInstanceManager();
        mgr.addReactInstanceEventListener(c -> {
            synchronized (RyzenEngine.class) {
                ctx = c;
                for (Runnable r : queued) r.run();
                queued.clear();
            }
        });
        if (mgr.getCurrentReactContext() != null) {
            ctx = mgr.getCurrentReactContext();
        } else {
            mgr.createReactContextInBackground();
        }
    }

    public static void setEvents(Events e) { events = e; }

    public static synchronized void call(String cmd, String argsJson, Result cb) {
        final String id = UUID.randomUUID().toString();
        pending.put(id, cb);
        Runnable send = () -> {
            WritableMap m = Arguments.createMap();
            m.putString("id", id);
            m.putString("cmd", cmd);
            m.putString("args", argsJson == null ? "{}" : argsJson);
            ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                    .emit("ryzenCmd", m);
        };
        if (ctx != null) send.run(); else queued.add(send);
    }

    static void onReply(String id, boolean ok, String json) {
        Result r = pending.remove(id);
        if (r != null) r.done(ok, json);
    }

    static void onEvent(String name, String json) {
        Events e = events;
        if (e != null) e.on(name, json);
    }
}
