package com.xstreaming;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class RyzenEngineModule extends ReactContextBaseJavaModule {
    public RyzenEngineModule(ReactApplicationContext ctx) { super(ctx); }

    @Override public String getName() { return "RyzenEngine"; }

    @ReactMethod public void reply(String id, boolean ok, String json) {
        RyzenEngine.onReply(id, ok, json);
    }

    @ReactMethod public void emit(String name, String json) {
        RyzenEngine.onEvent(name, json);
    }
}
