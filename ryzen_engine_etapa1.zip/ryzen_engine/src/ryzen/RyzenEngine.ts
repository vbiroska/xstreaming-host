import {DeviceEventEmitter, NativeModules} from 'react-native';
import Authentication from '../Authentication';
import XcloudApi from '../xCloud';
import StreamingToken from '../tokens/streamingtoken';
import {getSettings} from '../store/settingStore';

const Bridge = NativeModules.RyzenEngine;
const XAL_SCHEME = 'ms-xal-000000004c20a908:';

type Waiter = {resolve: () => void; reject: (e: Error) => void};

let auth: Authentication | null = null;
let redirect: any = null;
let streamingTokens: any = null;
let webToken: any = null;
let waiter: Waiter | null = null;

const emit = (name: string, data: any) =>
  Bridge?.emit?.(name, JSON.stringify(data ?? {}));

function ensureAuth(): Authentication {
  if (auth) return auth;
  auth = new Authentication(
    async (tokens: any, web: any) => {
      streamingTokens = tokens;
      webToken = web;
      waiter?.resolve();
      waiter = null;
    },
    (msg: string) => {
      waiter?.reject(new Error(msg));
      waiter = null;
    },
    (stage: string) => emit('loginProgress', {stage}),
  );
  return auth;
}

function waitAuth(ms = 45000): Promise<void> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => {
      waiter = null;
      reject(new Error('login timeout'));
    }, ms);
    waiter = {
      resolve: () => {
        clearTimeout(t);
        resolve();
      },
      reject: (e: Error) => {
        clearTimeout(t);
        reject(e);
      },
    };
  });
}

function cloudToken(): any {
  const t = streamingTokens?.xCloudToken;
  if (!t) throw new Error('sem token do xCloud (conta sem Game Pass?)');
  return t instanceof StreamingToken ? t : new StreamingToken(t.data, t.offering);
}

const commands: Record<string, (args: any) => Promise<any>> = {
  // Já existe login salvo? Se sim, renova em silêncio.
  async init() {
    const a = ensureAuth();
    const p = waitAuth();
    const has = await a.checkAuthentication();
    if (!has) {
      waiter = null;
      return {loggedIn: false};
    }
    await p;
    return {loggedIn: true};
  },

  // Passo 1 do login: devolve a URL da Microsoft para o Flutter abrir.
  async loginStart() {
    redirect = await ensureAuth()._xal.getRedirectUri();
    return {authUrl: redirect.sisuAuth.MsaOauthRedirect, scheme: XAL_SCHEME};
  },

  // Passo 2: o Flutter devolve a URL final (ms-xal-...:?code=...).
  async loginFinish({url}: {url: string}) {
    if (!redirect) throw new Error('loginStart não foi chamado');
    const p = waitAuth();
    ensureAuth().startAuthflow(redirect, url);
    await p;
    return {loggedIn: true};
  },

  async titles() {
    const t = cloudToken();
    const api = new XcloudApi(t.getDefaultRegion().baseUri, t.data.gsToken, 'cloud');
    return api.getTitles();
  },

  // Monta o streamInfo que o NanoStreamView nativo espera (igual ao NanoStream.tsx).
  async prepareStream({titleId}: {titleId: string}) {
    const a = ensureAuth();
    const t = cloudToken();
    a._tokenStore.load();
    const msal = await a._xal.getMsalToken(a._tokenStore);
    const lpt = msal?.data?.lpt;
    if (!lpt) throw new Error('token de conexão vazio');
    const region = t.getDefaultRegion();
    const settings = getSettings();
    return {
      sessionId: titleId,
      streamType: 'cloud',
      render_engine: 'nano',
      settings,
      postUrl: `${region.baseUri}/v5/sessions/cloud/play`,
      baseUri: region.baseUri,
      gsToken: t.data.gsToken,
      isUsbMode: false,
      usbController: '',
      auth: {webToken, connectUserToken: lpt, streamingTokens},
    };
  },
};

DeviceEventEmitter.addListener('ryzenCmd', async (m: any) => {
  const {id, cmd, args} = m;
  try {
    const fn = commands[cmd];
    if (!fn) throw new Error('comando desconhecido: ' + cmd);
    const out = await fn(args ? JSON.parse(args) : {});
    Bridge.reply(id, true, JSON.stringify(out ?? null));
  } catch (e: any) {
    Bridge.reply(id, false, String(e?.message || e));
  }
});

emit('engineReady', {});
