// Cole em MainActivity.kt (Ryzen), dentro de configureFlutterEngine(...), perto do canal "ryzen/native".
// Imports: com.xstreaming.RyzenEngine

val eng = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/engine")
RyzenEngine.start(application)
RyzenEngine.setEvents { name, json ->
    runOnUiThread { eng.invokeMethod("event", mapOf("name" to name, "json" to json)) }
}
eng.setMethodCallHandler { call, result ->
    if (call.method == "call") {
        RyzenEngine.call(call.argument<String>("cmd")!!, call.argument<String>("args")) { ok, json ->
            runOnUiThread {
                if (ok) result.success(json) else result.error("engine", json, null)
            }
        }
    } else result.notImplemented()
}
