/**
 * Etapa 3: render "native" (WebRTC) sem tela.
 * Repete o fluxo do NativeStream.tsx do XStreaming (startSession -> offer -> SDP -> ICE -> conectado),
 * mas sem UI: o vídeo é desenhado por uma view nativa dentro do Flutter (RyzenNativeView.java).
 *
 * Comandos novos: nativeStart, nativeStop, nativePad, nativeStats.
 * Eventos para o Flutter: nativeStage, nativeQueue, nativeStream, nativeState, nativeRumble, nativeError.
 */
import {MediaStream, RTCRtpReceiver} from 'react-native-webrtc';
import webRTCClient from '../webrtc';
import XcloudApi from '../xCloud';
import {getSettings} from '../store/settingStore';

const CONNECTED = 'connected';
const STOP_STREAM_TIMEOUT_MS = 5000;
const PROCESSED_FRAME_FEEDBACK_DECODE_MS = 10;

// mesma ordem do RyzenStreamView.PAD_KEYS (17 botões + 4 eixos)
const PAD_KEYS = [
  'A', 'B', 'X', 'Y', 'LeftShoulder', 'RightShoulder', 'LeftTrigger', 'RightTrigger',
  'View', 'Menu', 'LeftThumb', 'RightThumb', 'DPadUp', 'DPadDown', 'DPadLeft', 'DPadRight',
  'Nexus', 'LeftThumbXAxis', 'LeftThumbYAxis', 'RightThumbXAxis', 'RightThumbYAxis',
];

const nowMs = () => globalThis.performance?.now?.() ?? Date.now();

// quadro de "feedback" que o XStreaming manda a cada 10 s para o servidor manter a resolução estável
const stableResolutionFrame = () => {
  const decoded = nowMs();
  const submitted = decoded - PROCESSED_FRAME_FEEDBACK_DECODE_MS;
  return {
    serverDataKey: Date.now(),
    firstFramePacketArrivalTimeMs: submitted,
    frameSubmittedTimeMs: submitted,
    frameDecodedTimeMs: decoded,
    frameRenderedTimeMs: decoded,
    expectedDisplayTime: decoded + 1,
  };
};

// Prioriza o codec escolhido no SDP (cópia do setCodec do NativeStream.tsx; devolve o SDP original se nada casar)
function applyCodec(sdp: string, codec: string): string {
  const [mimeType, profiles] = String(codec || '').split('-');
  if (!mimeType || !profiles) return sdp;
  const caps: any = RTCRtpReceiver.getCapabilities('video');
  if (!caps) return sdp;
  const pref: any[] = [];
  for (const c of caps.codecs) {
    if (c.mimeType !== mimeType) continue;
    for (let j = 0; j < profiles.length; j++) {
      if (c.sdpFmtpLine?.indexOf('profile-level-id=' + profiles[j]) !== -1) pref.push(c);
    }
  }
  if (!pref.length) return sdp;
  if (mimeType.indexOf('H264') > -1) {
    const re = /a=fmtp:(\d+).*profile-level-id=([0-9a-f]{6})/g;
    const ids: string[] = [];
    for (const m of sdp.matchAll(re) as any) {
      if (m[2].startsWith(profiles[0])) ids.push(m[1]);
    }
    if (!ids.length) return sdp;
    const lines = sdp.split('\r\n');
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('m=video')) continue;
      const tmp = lines[i].trim().split(' ');
      const rest = tmp.slice(3).filter(x => !ids.includes(x));
      lines[i] = tmp.slice(0, 3).concat(ids, rest).join(' ');
      break;
    }
    return lines.join('\r\n');
  }
  return sdp;
}

type Ctx = {
  commands: Record<string, (args: any) => Promise<any>>;
  ensureAuth: () => any;
  cloudToken: () => any;
  emit: (name: string, data: any) => void;
};

export function installNative({commands, ensureAuth, cloudToken, emit}: Ctx) {
  let client: any = null;
  let api: any = null;
  let stream: any = null;
  let keepalive: any = null;
  let frameTimer: any = null;
  let frameFirst: any = null;

  // estado do controle: o driver do XStreaming lê este objeto a cada poll e manda ao Xbox
  const gp: any = {GamepadIndex: 0};
  PAD_KEYS.forEach(k => (gp[k] = 0));

  const clearTimers = () => {
    if (keepalive) clearInterval(keepalive);
    if (frameTimer) clearInterval(frameTimer);
    if (frameFirst) clearTimeout(frameFirst);
    keepalive = frameTimer = frameFirst = null;
  };

  const stopOnServer = async (a: any) => {
    if (!a || typeof a.stopStream !== 'function') return;
    let t: any;
    const timeout = new Promise((_, rej) => {
      t = setTimeout(() => rej(new Error('STOP_STREAM_TIMEOUT')), STOP_STREAM_TIMEOUT_MS);
    });
    try {
      await Promise.race([Promise.resolve().then(() => a.stopStream()), timeout]);
    } catch (e) {
      // sem resposta do servidor: segue, o "cleanup" da próxima sessão limpa o resto
    } finally {
      clearTimeout(t);
    }
  };

  const teardown = async (stopServer: boolean) => {
    clearTimers();
    const c = client;
    const a = api;
    client = null;
    api = null;
    stream = null;
    PAD_KEYS.forEach(k => (gp[k] = 0));
    try {
      c?.close();
    } catch (e) {}
    if (stopServer) await stopOnServer(a);
  };

  const fail = (cl: any, e: any) => {
    if (client !== cl) return;
    const msg = typeof e === 'string' ? e : e?.message || String(e);
    emit('nativeError', {message: msg});
  };

  commands.nativeStart = async ({titleId, settings: over}: {titleId: string; settings?: any}) => {
    await teardown(true);

    const token = cloudToken();
    const auth = ensureAuth();
    const s: any = {...getSettings(), ...(over || {})};

    const cl: any = new webRTCClient();
    client = cl;
    const a: any = new XcloudApi(token.getDefaultRegion().baseUri, token.data.gsToken, 'cloud', auth);
    api = a;

    cl.init();
    stream = new MediaStream(undefined);
    cl.setPollRate(s.polling_rate);
    cl.setMaxTouchPoints(0);
    cl.setSupportedSystemUis([]); // sem diálogos do sistema do Xbox (teclado virtual etc.) por enquanto
    cl.setSystemUiHandler(() => {});
    cl.setMessageHandler(() => {});
    if (s.coop) cl.setCoop();
    cl.setGamepadState(gp);

    cl.setTrackHandler((event: any) => {
      const track = event.track;
      if (!stream) stream = new MediaStream();
      stream.addTrack(track, stream);
    });

    cl.setSdpHandler((_c: any, offer: any) => {
      a.sendChatSdp(offer)
        .then((r: any) => cl.setRemoteOffer(JSON.parse(r.exchangeResponse).sdp))
        .catch(() => {});
    });

    cl.setRumbleHandler((r: any) => {
      if (client !== cl || !s.vibration) return;
      emit('nativeRumble', {
        weakMagnitude: r.weakMagnitude,
        strongMagnitude: r.strongMagnitude,
        leftTrigger: r.leftTrigger,
        rightTrigger: r.rightTrigger,
        duration: r.duration,
      });
    });

    cl.setConnectedHandler((state: string) => {
      if (client !== cl) return;
      emit('nativeState', {state});
      if (state !== CONNECTED) return;

      if (stream?.toURL) emit('nativeStream', {url: stream.toURL()});

      const sendFrame = () => cl.getChannelProcessor('input')?.addProcessedFrame(stableResolutionFrame());
      if (!frameFirst) frameFirst = setTimeout(sendFrame, 2000);
      if (!frameTimer) frameTimer = setInterval(sendFrame, 10 * 1000);

      if (!keepalive) {
        const every = a.getKeepaliveIntervalMs?.() ?? 20 * 1000;
        keepalive = setInterval(() => {
          a.sendKeepalive().catch(() => {});
        }, every);
      }
    });

    // Sessão: roda em segundo plano (pode ficar minutos na fila); o Flutter acompanha pelos eventos.
    (async () => {
      emit('nativeStage', {stage: 'session'});
      await a.startSession(titleId, s.resolution, (info: any) => emit('nativeQueue', info));
      if (client !== cl) return;

      emit('nativeStage', {stage: 'offer'});
      const offer = await cl.createOffer();
      if (s.codec) offer.sdp = applyCodec(offer.sdp, s.codec);

      const sdpRes = await a.sendSDPOffer(offer);
      if (client !== cl) return;
      emit('nativeStage', {stage: 'sdp'});
      await cl.setRemoteOffer(JSON.parse(sdpRes.exchangeResponse).sdp);

      const iceDetails = await a.sendICECandidates(cl.getIceCandidates());
      if (client !== cl) return;
      emit('nativeStage', {stage: 'ice'});
      cl.setIceCandidates(iceDetails);
    })().catch(e => fail(cl, e));

    // Como a view nativa deve desenhar (o Flutter lê isto)
    const fit = (s.native_touch ? '' : s.video_format) === 'Zoom' ? 'cover' : 'contain';
    return {
      started: true,
      view: {
        mode: s.smart_frame_generation ? 'framegen' : 'fsr', // 'fsr' com fsr=false = vídeo normal
        fsr: !!s.fsr,
        objectFit: fit,
        videoFormat: (s.native_touch ? '' : s.video_format) || '',
        fsrSharpness: s.fsr_display_options?.sharpness ?? 2,
        logVerbose: !!s.debug,
        videoFps: 60,
      },
    };
  };

  commands.nativeStop = async () => {
    await teardown(true);
    return {ok: true};
  };

  // Estado do controle vindo do Flutter (21 valores, ordem PAD_KEYS). O driver reenvia a cada poll.
  commands.nativePad = async ({v}: {v: number[]}) => {
    if (!Array.isArray(v)) return null;
    for (let i = 0; i < PAD_KEYS.length && i < v.length; i++) gp[PAD_KEYS[i]] = v[i];
    return null;
  };

  commands.nativeStats = async () => (client ? client.getStreamState() : null);
}
