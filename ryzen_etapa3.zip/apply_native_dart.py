#!/usr/bin/env python3
"""Etapa 3 (lado do Ryzen): tela de stream pelo render native.
Rode dentro de ryzen_app, DEPOIS do apply_ryzen_dart.py da etapa 2b."""
import pathlib, shutil

HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"
assert (lib / "engine_play.dart").exists() and (lib / "stream_view.dart").exists(), "rode a etapa 2b antes"

for f in ("engine_native.dart", "native_stream.dart", "xbox_store.dart"):
    shutil.copy(HERE / "dart" / f, lib / f)

# engine_play.dart: escolha do render + ajustes do render native; o início do stream não chama mais o nano
p = lib / "engine_play.dart"
s = p.read_text()
if "useNative" not in s:
    a = "  static const defaultProfile = <String, dynamic>{'resolution': 1080};\n"
    assert a in s, "defaultProfile não achado no engine_play.dart"
    s = s.replace(a, a + '''
  /// Render do stream: true = native (WebRTC, com FSR e frame generation); false = nano.
  static const useNative = true;

  /// Ajustes só do render native (por cima do perfil do jogo).
  /// fsr: AMD FSR 1. smart_frame_generation: LSFG (precisa do Lossless.dll original no aparelho).
  static const nativeProfile = <String, dynamic>{
    'fsr': true,
    'smart_frame_generation': false,
    'fsr_display_options': {'sharpness': 2},
  };
''', 1)
    b = "    final info = await Engine.prepareStream(item['titleId'] as String, EnginePlay.profileFor(widget.pid));\n"
    assert b in s, "prepareStream não achado no engine_play.dart"
    s = s.replace(b, '''    final Map info = EnginePlay.useNative
        ? {
            'render_engine': 'native',
            'titleId': item['titleId'],
            'settings': {...EnginePlay.profileFor(widget.pid), ...EnginePlay.nativeProfile},
          }
        : await Engine.prepareStream(item['titleId'] as String, EnginePlay.profileFor(widget.pid));
''', 1)
    p.write_text(s)

# stream_view.dart: se o stream é native, usa o corpo novo
v = lib / "stream_view.dart"
t = v.read_text()
if "NativeStreamBody" not in t:
    t = t.replace("import 'nano_view.dart';", "import 'nano_view.dart';\nimport 'native_stream.dart';", 1)
    a = "  @override\n  Widget build(BuildContext context) {\n    return ColoredBox("
    assert a in t, "build do StreamView não achado"
    t = t.replace(a, "  @override\n  Widget build(BuildContext context) {\n"
                     "    if (widget.info['render_engine'] == 'native') return _nativeBody();\n"
                     "    return ColoredBox(", 1)
    b = "  // mesma tela de carregamento dos outros jogos do Ryzen\n"
    assert b in t, "âncora do _splash não achada"
    t = t.replace(b, '''  // stream pelo render native (WebRTC)
  Widget _nativeBody() => ColoredBox(
        color: Colors.black,
        child: NativeStreamBody(
          info: widget.info,
          showStats: st.streamStats,
          nintendo: st.nintendo,
          fit: st.gameFit,
          splash: _splash,
          errorBuilder: (m) => _loading(true, m),
        ),
      );

''' + b, 1)
    v.write_text(t)
# state.dart: a opção "Ajuste da tela" (Padrão / Preencher / Esticar) também aparece no menu do stream
stp = lib / "state.dart"
tt = stp.read_text()
old = "if (streamInfo == null) QRow(tr('Ajuste da tela'),"
if old in tt:
    stp.write_text(tt.replace(old, "QRow(tr('Ajuste da tela'),", 1))

# Loja própria (Catálogo Xbox): tela nova + atalho na aba Loja (toque no texto ou LT/RT)
stp = lib / "state.dart"
tt = stp.read_text()
if "XboxStorePage" not in tt:
    a = "import 'native.dart';"
    assert a in tt, "import native.dart não achado no state.dart"
    tt = tt.replace(a, a + "\nimport 'xbox_store.dart';", 1)
    b = "      if (tab == 1) setFilter(a == Act.filterNext ? 1 : -1);"
    assert b in tt, "filtro da Biblioteca não achado no state.dart"
    tt = tt.replace(b, "      if (tab == 1) {\n        setFilter(a == Act.filterNext ? 1 : -1);\n      } else if (tab == 2) {\n        openXboxStore();\n      }", 1)
    c = "  void tapStore(int i) {"
    assert c in tt, "tapStore não achado no state.dart"
    tt = tt.replace(c, """  /// Abre o Catálogo Xbox (loja própria) por cima do Ryzen.
  void openXboxStore() {
    final nav = EnginePlay.navKey.currentState;
    if (nav == null) return;
    sfx('ok');
    nav.push(MaterialPageRoute(builder: (_) => const XboxStorePage()));
  }

  void tapStore(int i) {""", 1)
    stp.write_text(tt)

tbp = lib / "tabs.dart"
tb = tbp.read_text()
if "openXboxStore" not in tb:
    d = "      Positioned.fill(child: _grid(context)),\n"
    assert d in tb, "grade da Loja não achada no tabs.dart"
    tb = tb.replace(d, d + """      Positioned(
        right: 30 * s,
        bottom: 4 * s,
        child: GestureDetector(
          onTap: st.openXboxStore,
          child: Text('LT / RT   Catálogo Xbox', style: ts(context, 14, color: st.subTxt)),
        ),
      ),
""", 1)
    tbp.write_text(tb)
print("ok")
