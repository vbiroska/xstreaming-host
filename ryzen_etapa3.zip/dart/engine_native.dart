import 'dart:async';

import 'engine.dart';

/// Etapa 3: comandos e eventos do render "native" (WebRTC) do motor.
/// Eventos: nativeStage, nativeQueue, nativeStream, nativeState, nativeRumble, nativeError.
class NativeEngine {
  static final _events = StreamController<MapEntry<String, Map<String, dynamic>>>.broadcast();
  static void Function(String, Map<String, dynamic>)? _mine;

  static Stream<MapEntry<String, Map<String, dynamic>>> get events => _events.stream;

  /// Liga o canal de eventos do motor e encaminha os "native*" (mantém quem já ouvia antes).
  static void hook() {
    Engine.init();
    if (identical(Engine.onEvent, _mine)) return;
    final prev = Engine.onEvent;
    _mine = (name, data) {
      prev?.call(name, data);
      if (name.startsWith('native') && !_events.isClosed) _events.add(MapEntry(name, data));
    };
    Engine.onEvent = _mine;
  }

  /// Inicia a sessão em segundo plano. Devolve {started, view:{mode, fsr, objectFit, ...}}.
  static Future<Map<String, dynamic>> start(String titleId, [Map<String, dynamic>? settings]) async =>
      Map<String, dynamic>.from(await Engine.call('nativeStart', {
        'titleId': titleId,
        if (settings != null) 'settings': settings,
      }));

  static Future<void> stop() => Engine.call('nativeStop');

  /// Busca os eventos acumulados no motor (nativeStage, nativeQueue, nativeStream, nativeState...).
  static Future<List<MapEntry<String, Map<String, dynamic>>>> poll() async {
    final r = await Engine.call('nativePoll');
    if (r is! List) return const [];
    return [
      for (final e in r)
        if (e is Map && e['name'] is String)
          MapEntry(e['name'] as String, Map<String, dynamic>.from((e['data'] as Map?) ?? const {})),
    ];
  }

  /// {resolution, rtt, jit, fps, pl, fl, br, decode, bytesReceived, bytesSent}
  static Future<Map<String, dynamic>?> stats() async {
    final r = await Engine.call('nativeStats');
    return r is Map ? Map<String, dynamic>.from(r) : null;
  }
}
