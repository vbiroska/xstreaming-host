import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'engine_native.dart';
import 'native.dart';

const _viewType = 'ryzen/native_view';

/// Stream pelo render "native" (WebRTC): inicia a sessão no motor, mostra a tela de carregamento
/// (com a fila, se houver), desenha o vídeo (FSR / frame generation) e passa o rumble ao controle.
/// A tela de carregamento e a de erro vêm de fora, para ficarem iguais às do resto do Ryzen.
class NativeStreamBody extends StatefulWidget {
  const NativeStreamBody({
    super.key,
    required this.info,
    required this.showStats,
    required this.nintendo,
    required this.splash,
    required this.errorBuilder,
  });

  /// {render_engine: 'native', titleId, settings}
  final Map<dynamic, dynamic> info;
  final bool showStats;
  final bool nintendo;
  final Widget Function() splash;
  final Widget Function(String message) errorBuilder;

  @override
  State<NativeStreamBody> createState() => _NativeStreamBodyState();
}

class _NativeStreamBodyState extends State<NativeStreamBody> {
  StreamSubscription<MapEntry<String, Map<String, dynamic>>>? _sub;
  Timer? _statsTimer;
  MethodChannel? _viewCh;

  Map<String, dynamic>? view; // como desenhar (vem do motor)
  String? url; // stream do WebRTC (só existe depois de conectar)
  bool connected = false;
  bool ended = false;
  String? error;
  String queue = '';
  Map<String, dynamic> stats = const {};

  @override
  void initState() {
    super.initState();
    NativeEngine.hook();
    _sub = NativeEngine.events.listen(_onEvent);
    _start();
  }

  Future<void> _start() async {
    try {
      final settings = Map<String, dynamic>.from((widget.info['settings'] as Map?) ?? const {});
      final r = await NativeEngine.start(widget.info['titleId'].toString(), settings);
      if (!mounted) return;
      setState(() => view = Map<String, dynamic>.from((r['view'] as Map?) ?? const {}));
    } catch (e) {
      _fail(e);
    }
  }

  void _fail(Object e) {
    if (!mounted) return;
    setState(() => error = e.toString().replaceFirst('PlatformException', '').trim());
  }

  void _onEvent(MapEntry<String, Map<String, dynamic>> ev) {
    if (!mounted) return;
    final d = ev.value;
    switch (ev.key) {
      case 'nativeQueue':
        _onQueue(d);
        break;
      case 'nativeStream':
        setState(() => url = d['url']?.toString());
        _viewCh?.invokeMethod('streamUrl', url).catchError((_) {});
        break;
      case 'nativeState':
        final s = (d['state'] ?? '').toString();
        if (s == 'connected') {
          setState(() {
            connected = true;
            queue = '';
          });
          _statsTimer ??= Timer.periodic(const Duration(seconds: 1), (_) => _pollStats());
        } else if (s == 'closed' || s == 'failed') {
          setState(() {
            ended = true;
            error = connected ? 'A conexão com o jogo foi encerrada.' : 'Falha de rede ao conectar (NAT).';
          });
        }
        break;
      case 'nativeRumble':
        _onRumble(d);
        break;
      case 'nativeError':
        setState(() => error = (d['message'] ?? 'Erro ao iniciar o jogo').toString());
        break;
    }
  }

  void _onQueue(Map<String, dynamic> d) {
    final state = (d['state'] ?? '').toString();
    final wait = (d['estimatedWaitInSeconds'] as num?)?.toInt() ?? 0;
    final pos = (d['position'] as num?)?.toInt() ?? 0;
    String t;
    if (state == 'WaitingForResources') {
      t = wait > 60
          ? 'Na fila: ~${(wait / 60).ceil()} min'
          : (wait > 0 ? 'Na fila: menos de 1 min' : 'Na fila, aguardando servidor...');
      if (pos > 0) t += '\nPosição: $pos';
    } else if (state == 'Provisioning') {
      t = 'Alocando servidor...';
    } else if (state == 'ReadyToConnect') {
      t = 'Conectando...';
    } else {
      return;
    }
    setState(() => queue = t);
  }

  Future<void> _pollStats() async {
    if (!mounted || !widget.showStats) return;
    try {
      final s = await NativeEngine.stats();
      if (mounted && s != null) setState(() => stats = s);
    } catch (_) {}
  }

  // vibração pedida pelo jogo -> controle (valores do WebRTC vêm de 0 a 1)
  void _onRumble(Map<String, dynamic> m) {
    final dur = (m['duration'] as num?)?.toInt() ?? 0;
    var mag = math.max((m['weakMagnitude'] as num?)?.toDouble() ?? 0,
        (m['strongMagnitude'] as num?)?.toDouble() ?? 0);
    if (mag > 1) mag /= 100;
    final amp = (mag * 255).round().clamp(0, 255);
    if (dur <= 0 || amp <= 0) {
      Native.rumble(0, 0);
    } else {
      Native.rumble(dur.clamp(1, 2000), amp);
    }
  }

  @override
  void didUpdateWidget(covariant NativeStreamBody old) {
    super.didUpdateWidget(old);
    if (old.nintendo != widget.nintendo) {
      _viewCh?.invokeMethod('nintendo', widget.nintendo).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _statsTimer?.cancel();
    Native.rumble(0, 0);
    // encerra a sessão no servidor
    NativeEngine.stop().catchError((_) {});
    super.dispose();
  }

  String _s(dynamic v) => (v ?? '').toString();

  @override
  Widget build(BuildContext context) {
    if (error != null) return widget.errorBuilder(error!);
    final playing = connected && url != null && view != null;
    return Stack(fit: StackFit.expand, children: [
      if (playing) _video(),
      if (!playing) widget.splash(),
      if (!playing && queue.isNotEmpty)
        Positioned(
          left: 24,
          right: 24,
          bottom: 56,
          child: Text(queue,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 15)),
        ),
      if (playing && widget.showStats)
        Positioned(
          left: 12,
          top: 8,
          child: Text(
            '${_s(stats['resolution'])}  ${_s(stats['fps'])} fps  ${_s(stats['rtt'])}  ${_s(stats['br'])}',
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ),
    ]);
  }

  // Hybrid Composition: as views de vídeo usam SurfaceView
  Widget _video() {
    final params = <String, dynamic>{...view!, 'url': url};
    return PlatformViewLink(
      viewType: _viewType,
      surfaceFactory: (context, controller) => AndroidViewSurface(
        controller: controller as AndroidViewController,
        gestureRecognizers: const <Factory<OneSequenceGestureRecognizer>>{},
        hitTestBehavior: PlatformViewHitTestBehavior.transparent,
      ),
      onCreatePlatformView: (p) {
        return PlatformViewsService.initExpensiveAndroidView(
          id: p.id,
          viewType: _viewType,
          layoutDirection: TextDirection.ltr,
          creationParams: params,
          creationParamsCodec: const StandardMessageCodec(),
          onFocus: () => p.onFocusChanged(true),
        )
          ..addOnPlatformViewCreatedListener((id) {
            p.onPlatformViewCreated(id);
            _viewCh = MethodChannel('ryzen/native_view_$id');
            if (widget.nintendo) _viewCh!.invokeMethod('nintendo', true).catchError((_) {});
          })
          ..create();
      },
    );
  }
}
