import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'engine_native.dart';
import 'native.dart';

const _viewType = 'ryzen/native_view';

/// Stream pelo render "native" (WebRTC): inicia a sessão no motor, mostra a tela de carregamento
/// (com a fila, se houver), desenha o vídeo (FSR / frame generation) e passa o rumble ao controle.
/// A tela de carregamento e a de erro vêm de fora, para ficarem iguais às do resto do Ryzen.
class NativeStreamBody extends StatefulWidget {
  const NativeStreamBody({
    super.key,
    required this.info,
    required this.showStats,
    required this.nintendo,
    required this.splash,
    required this.errorBuilder,
  });

  /// {render_engine: 'native', titleId, settings}
  final Map<dynamic, dynamic> info;
  final bool showStats;
  final bool nintendo;
  final Widget Function() splash;
  final Widget Function(String message) errorBuilder;

  @override
  State<NativeStreamBody> createState() => _NativeStreamBodyState();
}

class _NativeStreamBodyState extends State<NativeStreamBody> {
  StreamSubscription<MapEntry<String, Map<String, dynamic>>>? _sub;
  Timer? _statsTimer;
  Timer? _watchdog;
  Timer? _pollTimer;
  bool _polling = false;
  DateTime _last = DateTime.now();
  String stage = '';
  String rtc = '';
  final List<String> _log = [];

  void _addLog(String m) {
    final t = DateTime.now();
    final hh = '${t.minute.toString().padLeft(2, '0')}:${t.second.toString().padLeft(2, '0')}';
    _log.add('$hh $m');
    if (_log.length > 8) _log.removeAt(0);
  }
  MethodChannel? _viewCh;

  Map<String, dynamic>? view; // como desenhar (vem do motor)
  String? url; // stream do WebRTC (só existe depois de conectar)
  bool connected = false;
  bool ended = false;
  String? error;
  String queue = '';
  Map<String, dynamic> stats = const {};

  @override
  void initState() {
    super.initState();
    NativeEngine.hook();
    _sub = NativeEngine.events.listen(_onEvent);
    // sem nenhum sinal do motor por 2 min: mostra em que etapa travou, em vez de carregar para sempre
    _pollTimer = Timer.periodic(const Duration(milliseconds: 150), (_) async {
      if (_polling || !mounted) return;
      _polling = true;
      try {
        for (final ev in await NativeEngine.poll()) {
          if (!mounted) break;
          _onEvent(ev);
        }
      } catch (_) {
      } finally {
        _polling = false;
      }
    });
    _watchdog = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || connected || error != null) return;
      if (DateTime.now().difference(_last).inSeconds > 120) {
        _fail('Travou na etapa "${stage.isEmpty ? 'inicio' : stage}" (sem resposta há 2 min).'
            '${rtc.isEmpty ? '' : ' Conexão: $rtc.'}');
      }
    });
    _start();
  }

  Future<void> _start() async {
    try {
      final settings = Map<String, dynamic>.from((widget.info['settings'] as Map?) ?? const {});
      setState(() => _addLog('dart: chamando nativeStart'));
      final r = await NativeEngine.start(widget.info['titleId'].toString(), settings)
          .timeout(const Duration(seconds: 25), onTimeout: () => throw 'o motor não respondeu ao nativeStart em 25 s');
      if (!mounted) return;
      _addLog('dart: nativeStart respondeu');
      setState(() => view = Map<String, dynamic>.from((r['view'] as Map?) ?? const {}));
    } catch (e) {
      _fail(e);
    }
  }

  void _fail(Object e) {
    if (!mounted) return;
    setState(() {
      _addLog('dart: erro ${e.toString().split('\n').first}');
      error = '${e.toString().replaceFirst('PlatformException', '').trim()}\n\n${_log.join('\n')}';
    });
  }

  void _onEvent(MapEntry<String, Map<String, dynamic>> ev) {
    if (!mounted) return;
    _last = DateTime.now();
    final d = ev.value;
    final raw = d.toString();
    _addLog('${ev.key} ${raw.length > 70 ? raw.substring(0, 70) : raw}');
    switch (ev.key) {
      case 'nativeStage':
        setState(() => stage = _s(d['stage']));
        break;
      case 'nativeQueue':
        _onQueue(d);
        break;
      case 'nativeStream':
        setState(() => url = d['url']?.toString());
        _viewCh?.invokeMethod('streamUrl', url).catchError((_) {});
        break;
      case 'nativeState':
        final s = (d['state'] ?? '').toString();
        if (s != 'connected') setState(() => rtc = s);
        if (s == 'connected') {
          setState(() {
            connected = true;
            queue = '';
          });
          _statsTimer ??= Timer.periodic(const Duration(seconds: 1), (_) => _pollStats());
        } else if (s == 'closed' || s == 'failed') {
          setState(() {
            ended = true;
            error = connected ? 'A conexão com o jogo foi encerrada.' : 'Falha de rede ao conectar (NAT).';
          });
        }
        break;
      case 'nativeRumble':
        _onRumble(d);
        break;
      case 'nativeError':
        setState(() => error = (d['message'] ?? 'Erro ao iniciar o jogo').toString());
        break;
    }
  }

  void _onQueue(Map<String, dynamic> d) {
    final state = (d['state'] ?? '').toString();
    final wait = (d['estimatedWaitInSeconds'] as num?)?.toInt() ?? 0;
    final pos = (d['position'] as num?)?.toInt() ?? 0;
    String t;
    if (state == 'WaitingForResources') {
      t = wait > 60
          ? 'Na fila: ~${(wait / 60).ceil()} min'
          : (wait > 0 ? 'Na fila: menos de 1 min' : 'Na fila, aguardando servidor...');
      if (pos > 0) t += '\nPosição: $pos';
    } else if (state == 'Provisioning') {
      t = 'Alocando servidor...';
    } else if (state == 'ReadyToConnect') {
      t = 'Conectando...';
    } else {
      return;
    }
    setState(() => queue = t);
  }

  Future<void> _pollStats() async {
    if (!mounted || !widget.showStats) return;
    try {
      final s = await NativeEngine.stats();
      if (mounted && s != null) setState(() => stats = s);
    } catch (_) {}
  }

  // vibração pedida pelo jogo -> controle (valores do WebRTC vêm de 0 a 1)
  void _onRumble(Map<String, dynamic> m) {
    final dur = (m['duration'] as num?)?.toInt() ?? 0;
    var mag = math.max((m['weakMagnitude'] as num?)?.toDouble() ?? 0,
        (m['strongMagnitude'] as num?)?.toDouble() ?? 0);
    if (mag > 1) mag /= 100;
    final amp = (mag * 255).round().clamp(0, 255);
    if (dur <= 0 || amp <= 0) {
      Native.rumble(0, 0);
    } else {
      Native.rumble(dur.clamp(1, 2000), amp);
    }
  }

  @override
  void didUpdateWidget(covariant NativeStreamBody old) {
    super.didUpdateWidget(old);
    if (old.nintendo != widget.nintendo) {
      _viewCh?.invokeMethod('nintendo', widget.nintendo).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _statsTimer?.cancel();
    _watchdog?.cancel();
    _pollTimer?.cancel();
    Native.rumble(0, 0);
    // encerra a sessão no servidor
    NativeEngine.stop().catchError((_) {});
    super.dispose();
  }

  String _s(dynamic v) => (v ?? '').toString();

  @override
  Widget build(BuildContext context) {
    if (error != null) return widget.errorBuilder(error!);
    final playing = connected && url != null && view != null;
    return Stack(fit: StackFit.expand, children: [
      if (playing) _video(),
      if (!playing) widget.splash(),
      if (!playing && (queue.isNotEmpty || stage.isNotEmpty))
        Positioned(
          left: 24,
          right: 24,
          bottom: 56,
          child: Text(
              [
                if (queue.isNotEmpty) queue,
                if (stage.isNotEmpty) 'Etapa: $stage${rtc.isNotEmpty ? ' · $rtc' : ''}',
              ].join('\n'),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 15)),
        ),
      if (!playing)
        Positioned(
          left: 12,
          bottom: 8,
          right: 12,
          child: Text(_log.join('\n'),
              style: const TextStyle(color: Colors.white38, fontSize: 10, height: 1.2)),
        ),
      if (playing && widget.showStats)
        Positioned(
          left: 12,
          top: 8,
          child: Text(
            '${_s(stats['resolution'])}  ${_s(stats['fps'])} fps  ${_s(stats['rtt'])}  ${_s(stats['br'])}',
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ),
    ]);
  }

  // Hybrid Composition: as views de vídeo usam SurfaceView
  Widget _video() {
    final params = <String, dynamic>{...view!, 'url': url};
    return PlatformViewLink(
      viewType: _viewType,
      surfaceFactory: (context, controller) => AndroidViewSurface(
        controller: controller as AndroidViewController,
        gestureRecognizers: const <Factory<OneSequenceGestureRecognizer>>{},
        hitTestBehavior: PlatformViewHitTestBehavior.transparent,
      ),
      onCreatePlatformView: (p) {
        return PlatformViewsService.initExpensiveAndroidView(
          id: p.id,
          viewType: _viewType,
          layoutDirection: TextDirection.ltr,
          creationParams: params,
          creationParamsCodec: const StandardMessageCodec(),
          onFocus: () => p.onFocusChanged(true),
        )
          ..addOnPlatformViewCreatedListener((id) {
            p.onPlatformViewCreated(id);
            _viewCh = MethodChannel('ryzen/native_view_$id');
            if (widget.nintendo) _viewCh!.invokeMethod('nintendo', true).catchError((_) {});
          })
          ..create();
      },
    );
  }
}
