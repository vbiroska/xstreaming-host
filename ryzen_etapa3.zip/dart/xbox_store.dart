import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'engine.dart';
import 'engine_play.dart';
import 'state.dart';
import 'ui.dart';

/// Loja própria do Ryzen: jogos do xCloud (lista da sua conta, pelo motor) + capas, descrição e
/// categoria do catálogo público da Microsoft. "Jogar" abre o jogo pelo mesmo caminho da Loja.

class _Game {
  _Game(this.pid, this.titleId, this.playable);
  final String pid;
  final String titleId;
  final bool playable;
  bool triedOk = false; // o catálogo já respondeu sobre este jogo
  String name = '';
  String desc = '';
  String dev = '';
  String cat = '';
  String? poster;
  String? hero;
  final List<String> shots = [];
}

class _Catalog {
  static List<_Game>? games; // cache enquanto o app está aberto
  static final HttpClient _client = HttpClient()..connectionTimeout = const Duration(seconds: 12);

  static Future<List<_Game>> load({bool refresh = false}) async {
    if (games != null && !refresh) return games!;
    Engine.init();
    final ok = await Engine.initSession();
    if (!ok) {
      throw 'Entre na conta Microsoft abrindo um jogo da Loja uma vez e volte aqui.';
    }
    final t = await EnginePlay.titles(refresh: refresh);
    final list = <_Game>[];
    t.forEach((pid, v) {
      list.add(_Game(pid, (v['titleId'] ?? '').toString(), v['playable'] == true));
    });
    return games = list;
  }

  static String? _img(dynamic u, int w) {
    if (u == null) return null;
    var x = u.toString();
    if (x.isEmpty) return null;
    if (x.startsWith('//')) x = 'https:$x';
    return x.contains('?') ? x : '$x?w=$w';
  }

  /// Busca nome, capa, descrição e categoria de um lote de jogos (até ~20 por chamada).
  static Future<void> fetchDetails(List<_Game> batch) async {
    final todo = batch.where((g) => !g.triedOk).toList();
    if (todo.isEmpty) return;
    try {
      final ids = todo.map((g) => g.pid).join(',');
      final uri = Uri.parse('https://displaycatalog.mp.microsoft.com/v7.0/products'
          '?bigIds=$ids&market=BR&languages=pt-BR&MS-CV=DGU1mcuYo0WMMp%2BF.1');
      final req = await _client.getUrl(uri);
      req.headers.set('Accept', 'application/json');
      final res = await req.close().timeout(const Duration(seconds: 25));
      if (res.statusCode != 200) {
        await res.drain<void>();
        return;
      }
      final body = await res.transform(utf8.decoder).join();
      final j = jsonDecode(body);
      final prods = (j is Map ? j['Products'] : null) as List? ?? const [];
      final byId = {for (final g in todo) g.pid: g};
      for (final p in prods) {
        if (p is! Map) continue;
        final g = byId[(p['ProductId'] ?? '').toString().toUpperCase()];
        if (g == null) continue;
        final lps = p['LocalizedProperties'];
        if (lps is! List || lps.isEmpty || lps.first is! Map) continue;
        final lp = lps.first as Map;
        g.name = (lp['ProductTitle'] ?? '').toString();
        final sd = (lp['ShortDescription'] ?? '').toString();
        g.desc = sd.isNotEmpty ? sd : (lp['ProductDescription'] ?? '').toString();
        g.dev = (lp['DeveloperName'] ?? lp['PublisherName'] ?? '').toString();
        final props = p['Properties'];
        g.cat = props is Map ? (props['Category'] ?? '').toString() : '';
        final imgs = lp['Images'];
        String? poster, box, hero, titled, key;
        if (imgs is List) {
          for (final im in imgs) {
            if (im is! Map) continue;
            final purpose = (im['ImagePurpose'] ?? '').toString();
            final u = im['Uri'];
            if (purpose == 'Poster') poster ??= _img(u, 480);
            if (purpose == 'BoxArt') box ??= _img(u, 480);
            if (purpose == 'SuperHeroArt') hero ??= _img(u, 1280);
            if (purpose == 'TitledHeroArt') titled ??= _img(u, 1280);
            if (purpose == 'BrandedKeyArt') key ??= _img(u, 1280);
            if (purpose == 'Screenshot' && g.shots.length < 4) {
              final sImg = _img(u, 640);
              if (sImg != null) g.shots.add(sImg);
            }
          }
        }
        g.poster = poster ?? box;
        g.hero = hero ?? titled ?? key;
        g.triedOk = true;
      }
      // quem o catálogo não devolveu não será pedido de novo
      for (final g in todo) {
        g.triedOk = true;
      }
    } catch (_) {
      // sem rede agora: tenta de novo na próxima vez
    }
  }
}

class XboxStorePage extends StatefulWidget {
  const XboxStorePage({super.key});
  @override
  State<XboxStorePage> createState() => _XboxStorePageState();
}

class _XboxStorePageState extends State<XboxStorePage> {
  static const _filters = ['Todos', 'Posso jogar', 'Sem acesso'];

  final FocusNode _fn = FocusNode();
  final ScrollController _gc = ScrollController();
  List<_Game> _all = [];
  bool _loading = true;
  String? _error;
  int _filter = 0;
  String _q = '';
  int _idx = 0;
  int _cols = 6;
  double _cellH = 300;
  _Game? _detail;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _fn.dispose();
    _gc.dispose();
    super.dispose();
  }

  Future<void> _init({bool refresh = false}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final l = await _Catalog.load(refresh: refresh);
      if (!mounted) return;
      setState(() {
        _all = [...l.where((g) => g.playable), ...l.where((g) => !g.playable)];
        _loading = false;
      });
      _background();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('PlatformException', '').trim();
        _loading = false;
      });
    }
  }

  /// Carrega as capas aos poucos (3 pedidos ao mesmo tempo), na ordem da lista.
  Future<void> _background() async {
    final all = List<_Game>.of(_all);
    const bs = 20;
    var next = 0;
    Future<void> worker() async {
      while (mounted) {
        final i = next;
        if (i >= all.length) break;
        next = i + bs;
        await _Catalog.fetchDetails(all.sublist(i, math.min(i + bs, all.length)));
        if (mounted) setState(() {});
      }
    }

    await Future.wait([worker(), worker(), worker()]);
  }

  List<_Game> get _list {
    final q = _q.toLowerCase();
    return _all.where((g) {
      if (g.triedOk && g.name.isEmpty) return false; // não está no catálogo da loja
      if (_filter == 1 && !g.playable) return false;
      if (_filter == 2 && g.playable) return false;
      if (q.isNotEmpty && !g.name.toLowerCase().contains(q)) return false;
      return true;
    }).toList();
  }

  void _follow() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      followIndex(_gc, (_idx ~/ _cols) * _cellH, _cellH);
    });
  }

  void _move(int d, int len) {
    if (len == 0) return;
    setState(() => _idx = (_idx + d).clamp(0, len - 1).toInt());
    _follow();
  }

  void _setFilter(int d) {
    setState(() {
      _filter = (_filter + d + _filters.length) % _filters.length;
      _idx = 0;
    });
    if (_gc.hasClients) _gc.jumpTo(0);
  }

  Future<void> _search() async {
    final c = TextEditingController(text: _q);
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Buscar jogo'),
        content: TextField(
          controller: c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Limpar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Buscar')),
        ],
      ),
    );
    if (r != null && mounted) {
      setState(() {
        _q = r.trim();
        _idx = 0;
      });
    }
    if (mounted) _fn.requestFocus();
  }

  void _play(_Game g) {
    final ctx = context;
    final cover = g.poster != null ? NetworkImage(g.poster!) : null;
    final banner = g.hero != null ? NetworkImage(g.hero!) : null;
    final title = g.name.isEmpty ? g.pid : g.name;
    EnginePlay.play(
      'https://play.xbox.com/stream/${g.pid}',
      title,
      cover: cover,
      banner: banner,
      onReady: (info) {
        // a tela de carregamento já se fechou; fecha também a loja e mostra o stream
        if (ctx.mounted) Navigator.of(ctx).pop();
        st.openStream(info, title: title, cover: cover, banner: banner);
      },
    );
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    if (e is KeyUpEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    final accept = k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.gameButtonA;
    final back = k == LogicalKeyboardKey.escape || k == LogicalKeyboardKey.gameButtonB;

    if (_detail != null) {
      if (back) {
        setState(() => _detail = null);
        return KeyEventResult.handled;
      }
      if (accept) {
        final g = _detail!;
        if (g.playable) _play(g);
        return KeyEventResult.handled;
      }
      return KeyEventResult.handled;
    }

    final list = _list;
    if (back) {
      Navigator.of(context).maybePop();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowLeft) {
      _move(-1, list.length);
    } else if (k == LogicalKeyboardKey.arrowRight) {
      _move(1, list.length);
    } else if (k == LogicalKeyboardKey.arrowUp) {
      _move(-_cols, list.length);
    } else if (k == LogicalKeyboardKey.arrowDown) {
      _move(_cols, list.length);
    } else if (accept) {
      if (list.isNotEmpty) setState(() => _detail = list[math.min(_idx, list.length - 1)]);
    } else if (k == LogicalKeyboardKey.gameButtonLeft1 || k == LogicalKeyboardKey.pageUp) {
      _setFilter(-1);
    } else if (k == LogicalKeyboardKey.gameButtonRight1 || k == LogicalKeyboardKey.pageDown) {
      _setFilter(1);
    } else if (k == LogicalKeyboardKey.gameButtonY || k == LogicalKeyboardKey.gameButtonSelect) {
      _search();
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Scaffold(
      backgroundColor: const Color(0xFF0B0E14),
      body: Focus(
        focusNode: _fn,
        autofocus: true,
        onKeyEvent: _key,
        child: Stack(children: [
          Padding(
            padding: EdgeInsets.fromLTRB(30 * s, 22 * s, 30 * s, 10 * s),
            child: Column(children: [
              _header(context),
              SizedBox(height: 14 * s),
              Expanded(child: _body(context)),
            ]),
          ),
          if (_detail != null) _detailView(context, _detail!),
        ]),
      ),
    );
  }

  Widget _header(BuildContext context) {
    final s = context.s;
    final n = _list.length;
    return Row(children: [
      GestureDetector(
        onTap: () => Navigator.of(context).maybePop(),
        child: Icon(Icons.arrow_back, color: st.txt, size: 30 * s),
      ),
      SizedBox(width: 14 * s),
      Text('Catálogo Xbox', style: ts(context, 30, bold: true)),
      SizedBox(width: 26 * s),
      for (int i = 0; i < _filters.length; i++)
        Padding(
          padding: EdgeInsets.only(right: 10 * s),
          child: GestureDetector(
            onTap: () {
              setState(() {
                _filter = i;
                _idx = 0;
              });
              if (_gc.hasClients) _gc.jumpTo(0);
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16 * s, vertical: 7 * s),
              decoration: BoxDecoration(
                color: i == _filter ? st.accent : Colors.white12,
                borderRadius: BorderRadius.circular(30 * s),
              ),
              child: Text(_filters[i], style: ts(context, 16, color: Colors.white)),
            ),
          ),
        ),
      const Spacer(),
      if (_q.isNotEmpty) Text('"$_q"  ', style: ts(context, 16, color: st.subTxt)),
      GestureDetector(
        onTap: _search,
        child: Icon(Icons.search, color: st.txt, size: 30 * s),
      ),
      SizedBox(width: 16 * s),
      Text('$n jogos', style: ts(context, 15, color: st.subTxt)),
    ]);
  }

  Widget _body(BuildContext context) {
    final s = context.s;
    if (_loading) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircularProgressIndicator(),
          SizedBox(height: 16 * s),
          Text('Carregando os jogos da sua conta...', style: ts(context, 16, color: st.subTxt)),
        ]),
      );
    }
    if (_error != null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(_error!, textAlign: TextAlign.center, style: ts(context, 18, color: Colors.redAccent)),
          SizedBox(height: 16 * s),
          FilledButton(onPressed: () => _init(refresh: true), child: const Text('Tentar de novo')),
        ]),
      );
    }
    final list = _list;
    if (list.isEmpty) {
      return Center(
        child: Text(_all.isEmpty ? 'Nenhum jogo encontrado.' : 'Nenhum jogo com esse filtro ou busca.',
            style: ts(context, 18, color: st.subTxt)),
      );
    }
    final sel = math.min(_idx, list.length - 1);
    return Column(children: [
      Expanded(
        child: LayoutBuilder(builder: (ctx, c) {
          _cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
          _cellH = c.maxWidth / _cols * 335 / 235;
          return GridView.builder(
            controller: _gc,
            padding: EdgeInsets.zero,
            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 235 * s,
              childAspectRatio: 235 / 335,
            ),
            itemCount: list.length,
            itemBuilder: (c2, i) {
              final g = list[i];
              final cur = i == sel;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _idx = i;
                    _detail = g;
                  });
                },
                child: FractionallySizedBox(
                  widthFactor: 205 / 235,
                  heightFactor: 300 / 335,
                  child: AnimatedScale(
                    scale: cur ? 1.05 : 1.0,
                    duration: const Duration(milliseconds: 120),
                    child: Glass(
                      radius: 14 * s,
                      frosted: false,
                      border: cur ? Colors.white : st.tileEdge,
                      borderWidth: cur ? 4 * s : 1,
                      child: Stack(children: [
                        Padding(
                          padding: EdgeInsets.all(6 * s),
                          child: Art(
                            img: g.poster != null ? NetworkImage(g.poster!) : null,
                            fit: BoxFit.cover,
                            title: g.name.isEmpty ? '...' : g.name,
                          ),
                        ),
                        Positioned(
                          top: 10 * s,
                          right: 10 * s,
                          child: Icon(
                            g.playable ? Icons.check_circle : Icons.lock,
                            size: 22 * s,
                            color: g.playable ? Colors.lightGreenAccent : Colors.white70,
                          ),
                        ),
                      ]),
                    ),
                  ),
                ),
              );
            },
          );
        }),
      ),
      Padding(
        padding: EdgeInsets.only(top: 4 * s),
        child: Text('A abrir   B voltar   LB / RB filtro   Y buscar',
            style: ts(context, 13, color: st.subTxt)),
      ),
    ]);
  }

  Widget _detailView(BuildContext context, _Game g) {
    final s = context.s;
    final name = g.name.isEmpty ? g.pid : g.name;
    final sub = [if (g.dev.isNotEmpty) g.dev, if (g.cat.isNotEmpty) g.cat].join('  ·  ');
    return Positioned.fill(
      child: GestureDetector(
        onTap: () => setState(() => _detail = null),
        child: Container(
          color: Colors.black87,
          alignment: Alignment.center,
          child: GestureDetector(
            onTap: () {},
            child: Container(
              width: 1000 * s,
              constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height - 60 * s),
              decoration: BoxDecoration(
                color: const Color(0xFF141923),
                borderRadius: BorderRadius.circular(18 * s),
              ),
              clipBehavior: Clip.antiAlias,
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  if (g.hero != null)
                    SizedBox(
                      height: 220 * s,
                      width: double.infinity,
                      child: Image(
                        image: ResizeImage(NetworkImage(g.hero!), width: 1280),
                        fit: BoxFit.cover,
                        errorBuilder: (c, e, st2) => const SizedBox.shrink(),
                      ),
                    ),
                  Padding(
                    padding: EdgeInsets.all(24 * s),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      SizedBox(
                        width: 180 * s,
                        height: 257 * s,
                        child: Glass(
                          radius: 12 * s,
                          frosted: false,
                          child: Padding(
                            padding: EdgeInsets.all(5 * s),
                            child: Art(
                              img: g.poster != null ? NetworkImage(g.poster!) : null,
                              fit: BoxFit.cover,
                              title: name,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 24 * s),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(name, style: ts(context, 30, bold: true, color: Colors.white)),
                          if (sub.isNotEmpty) ...[
                            SizedBox(height: 4 * s),
                            Text(sub, style: ts(context, 15, color: Colors.white60)),
                          ],
                          SizedBox(height: 12 * s),
                          Row(children: [
                            Icon(g.playable ? Icons.check_circle : Icons.lock,
                                size: 20 * s, color: g.playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                            SizedBox(width: 8 * s),
                            Expanded(
                              child: Text(
                                g.playable
                                    ? 'Disponível para jogar na nuvem'
                                    : 'Sua conta não tem acesso (precisa do Game Pass ou ter o jogo)',
                                style: ts(context, 16,
                                    color: g.playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                              ),
                            ),
                          ]),
                          SizedBox(height: 14 * s),
                          Text(g.desc.isEmpty ? 'Sem descrição.' : g.desc,
                              maxLines: 7,
                              overflow: TextOverflow.ellipsis,
                              style: ts(context, 16, color: Colors.white70)),
                          SizedBox(height: 20 * s),
                          Row(children: [
                            FilledButton.icon(
                              onPressed: g.playable ? () => _play(g) : null,
                              icon: const Icon(Icons.play_arrow),
                              label: const Text('Jogar na nuvem'),
                            ),
                            SizedBox(width: 12 * s),
                            TextButton(
                              onPressed: () => setState(() => _detail = null),
                              child: const Text('Fechar'),
                            ),
                          ]),
                        ]),
                      ),
                    ]),
                  ),
                  if (g.shots.isNotEmpty)
                    Padding(
                      padding: EdgeInsets.fromLTRB(24 * s, 0, 24 * s, 24 * s),
                      child: SizedBox(
                        height: 120 * s,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: g.shots.length,
                          separatorBuilder: (_, __) => SizedBox(width: 10 * s),
                          itemBuilder: (c, i) => ClipRRect(
                            borderRadius: BorderRadius.circular(8 * s),
                            child: Image(
                              image: ResizeImage(NetworkImage(g.shots[i]), width: 420),
                              fit: BoxFit.cover,
                              errorBuilder: (c2, e, st2) => const SizedBox.shrink(),
                            ),
                          ),
                        ),
                      ),
                    ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
