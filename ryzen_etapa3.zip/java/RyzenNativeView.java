package com.xstreaming;

import android.content.Context;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.ThemedReactContext;
import com.oney.WebRTCModule.RTCFrameGenVideoView;
import com.oney.WebRTCModule.RTCFrameGenVideoViewManager;
import com.oney.WebRTCModule.RTCFsrVideoView;
import com.oney.WebRTCModule.RTCFsrVideoViewManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Map;

import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.platform.PlatformView;

/**
 * Etapa 3: vídeo do render "native" (WebRTC) dentro de uma tela Flutter.
 * Usa as mesmas views do XStreaming (RTCFsrVideoView / RTCFrameGenVideoView); a sessão roda no motor JS
 * (RyzenNative.ts) e o Flutter só passa o streamURL quando a conexão sobe.
 */
public class RyzenNativeView implements PlatformView, MethodChannel.MethodCallHandler {
    private static final String TAG = "RyzenNativeView";

    // ---- controle: o MainActivity chama pad() a cada mudança (21 valores: 17 botões + 4 eixos) ----
    private static volatile RyzenNativeView active;
    private static volatile double[] rawPad = new double[21];
    private static volatile double[] lastSent = null;
    private static volatile boolean nintendo = false; // troca A<->B e X<->Y

    private final View view;
    private final RTCFsrVideoView fsrView;
    private final RTCFrameGenVideoView fgView;
    private final RTCFsrVideoViewManager fsrMgr = new RTCFsrVideoViewManager();
    private final RTCFrameGenVideoViewManager fgMgr = new RTCFrameGenVideoViewManager();
    private final MethodChannel channel;

    RyzenNativeView(Context context, BinaryMessenger messenger, int id, @Nullable Object args) {
        ReactContext rc = RyzenEngine.reactContext();
        if (!(rc instanceof ReactApplicationContext)) {
            throw new IllegalStateException("motor do XStreaming ainda não iniciou");
        }
        // as views do WebRTC pegam o WebRTCModule pelo ReactContext
        ThemedReactContext themed = new ThemedReactContext((ReactApplicationContext) rc, context);

        Map<?, ?> p = new java.util.HashMap<String, Object>();
        if (args instanceof Map) p = (Map<?, ?>) args;
        String mode = str(p.get("mode"), "fsr");
        String fit = str(p.get("objectFit"), "contain");
        String format = str(p.get("videoFormat"), "");
        boolean fsr = bool(p.get("fsr"), false);
        float sharp = (float) num(p.get("fsrSharpness"), 2);
        String url = str(p.get("url"), null);

        if ("framegen".equals(mode)) {
            fsrView = null;
            fgView = fgMgr.createViewInstance(themed);
            fgMgr.setObjectFit(fgView, fit);
            fgMgr.setVideoFormat(fgView, format);
            fgMgr.setZOrder(fgView, 9);
            fgMgr.setFsrEnabled(fgView, fsr);
            fgMgr.setFsrSharpness(fgView, sharp);
            fgMgr.setLogVerbose(fgView, bool(p.get("logVerbose"), false));
            fgMgr.setVideoFps(fgView, (int) num(p.get("videoFps"), 60));
            if (url != null) fgMgr.setStreamURL(fgView, url);
            view = fgView;
        } else {
            fgView = null;
            fsrView = fsrMgr.createViewInstance(themed);
            fsrMgr.setObjectFit(fsrView, fit);
            fsrMgr.setVideoFormat(fsrView, format);
            fsrMgr.setZOrder(fsrView, 9);
            fsrMgr.setFsrEnabled(fsrView, fsr); // false = vídeo normal, sem FSR
            fsrMgr.setFsrSharpness(fsrView, sharp);
            if (url != null) fsrMgr.setStreamURL(fsrView, url);
            view = fsrView;
        }

        channel = new MethodChannel(messenger, "ryzen/native_view_" + id);
        channel.setMethodCallHandler(this);
        active = this;
        lastSent = null;
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        try {
            switch (call.method) {
                case "streamUrl": {
                    String url = call.arguments == null ? null : String.valueOf(call.arguments);
                    if (fgView != null) fgMgr.setStreamURL(fgView, url);
                    else fsrMgr.setStreamURL(fsrView, url);
                    break;
                }
                case "fsr": {
                    boolean on = Boolean.TRUE.equals(call.arguments);
                    if (fgView != null) fgMgr.setFsrEnabled(fgView, on);
                    else fsrMgr.setFsrEnabled(fsrView, on);
                    break;
                }
                case "sharpness": {
                    float v = (float) num(call.arguments, 2);
                    if (fgView != null) fgMgr.setFsrSharpness(fgView, v);
                    else fsrMgr.setFsrSharpness(fsrView, v);
                    break;
                }
                case "nintendo":
                    nintendo = Boolean.TRUE.equals(call.arguments);
                    lastSent = null;
                    pad(rawPad);
                    break;
                default:
                    result.notImplemented();
                    return;
            }
            result.success(null);
        } catch (Exception e) {
            result.error("native", String.valueOf(e), null);
        }
    }

    /** Chamado pelo MainActivity a cada mudança do controle. Só repassa ao motor quando algo mudou. */
    public static void pad(double[] p) {
        if (p == null || p.length < 21) return;
        rawPad = p.clone();
        if (active == null) return;
        double[] q = nintendo ? swapped(p) : p;
        double[] prev = lastSent;
        if (prev != null && Arrays.equals(prev, q)) return;
        lastSent = q.clone();
        try {
            JSONArray a = new JSONArray();
            for (int i = 0; i < 21; i++) a.put(q[i]);
            JSONObject o = new JSONObject();
            o.put("v", a);
            RyzenEngine.call("nativePad", o.toString(), (ok, json) -> {});
        } catch (Throwable t) {
            Log.e(TAG, "pad", t);
        }
    }

    private static double[] swapped(double[] p) {
        double[] q = p.clone();
        q[0] = p[1]; q[1] = p[0]; // A <-> B
        q[2] = p[3]; q[3] = p[2]; // X <-> Y
        return q;
    }

    private static String str(Object o, String d) { return o == null ? d : String.valueOf(o); }
    private static boolean bool(Object o, boolean d) { return o instanceof Boolean ? (Boolean) o : d; }
    private static double num(Object o, double d) { return o instanceof Number ? ((Number) o).doubleValue() : d; }

    @Override
    public View getView() { return view; }

    @Override
    public void dispose() {
        if (active == this) active = null;
        channel.setMethodCallHandler(null);
    }
}
