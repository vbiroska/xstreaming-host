#!/usr/bin/env python3
"""Etapa 3 (lado do XStreaming): render native (WebRTC) no motor.
Rode na raiz do XStreaming, DEPOIS das etapas 1 e 2 (apply_ryzen_engine.py e apply_ryzen_host.py)."""
import pathlib, shutil

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()
JAVA = ROOT / "android/app/src/main/java/com/xstreaming"
MAIN_KT = ROOT / "android/app/src/main/kotlin/com/ryzen/ryzen/MainActivity.kt"
ENGINE_TS = ROOT / "src/ryzen/RyzenEngine.ts"
assert JAVA.is_dir(), "rode na raiz do XStreaming"
assert ENGINE_TS.exists(), "rode a etapa 1 antes (RyzenEngine.ts não existe)"
assert MAIN_KT.exists(), "rode a etapa 2 antes (MainActivity.kt do Ryzen não existe)"

# 1) motor JS: sessão native
shutil.copy(HERE / "src/ryzen/RyzenNative.ts", ROOT / "src/ryzen/RyzenNative.ts")

t = ENGINE_TS.read_text()
if "installNative" not in t:
    imp = "import {getSettings} from '../store/settingStore';"
    assert imp in t, "import do settingStore não achado no RyzenEngine.ts"
    t = t.replace(imp, imp + "\nimport {installNative} from './RyzenNative';", 1)
    hook = "DeviceEventEmitter.addListener('ryzenCmd'"
    assert hook in t, "listener ryzenCmd não achado no RyzenEngine.ts"
    t = t.replace(hook, "installNative({commands, ensureAuth, cloudToken, emit});\n\n" + hook, 1)
    ENGINE_TS.write_text(t)

# 2) view nativa (Java)
for f in (HERE / "java").glob("*.java"):
    shutil.copy(f, JAVA / f.name)

# 3) MainActivity.kt do Ryzen: registra a view e encaminha o controle também ao render native
k = MAIN_KT.read_text()
if "RyzenNativeViewFactory" not in k:
    key = 'com.xstreaming.RyzenStreamViewFactory(flutterEngine.dartExecutor.binaryMessenger))'
    assert key in k, "registro da view nano não achado no MainActivity.kt (rode a etapa 2 antes)"
    k = k.replace(key, key + '''
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "ryzen/native_view",
            com.xstreaming.RyzenNativeViewFactory(flutterEngine.dartExecutor.binaryMessenger))''', 1)
if "RyzenNativeView.pad" not in k:
    key = "try { com.xstreaming.RyzenStreamView.pad(out) } catch (_: Throwable) {}"
    assert key in k, "ponte do controle não achada no MainActivity.kt (rode a etapa 2 antes)"
    k = k.replace(key, key + "\n        try { com.xstreaming.RyzenNativeView.pad(out) } catch (_: Throwable) {}", 1)
MAIN_KT.write_text(k)

# 4) Motor RN sem tela: nunca recebia "onHostResume", então os timers do JS (setTimeout/setInterval)
#    ficavam parados e o polling da sessão xCloud morria em "Provisioning". Liga o ciclo de vida à Activity.
ENG_JAVA = JAVA / "RyzenEngine.java"
e = ENG_JAVA.read_text()
if "onHostResume" not in e:
    key = "mgr = ((ReactApplication) app).getReactNativeHost().getReactInstanceManager();"
    assert key in e, "criação do ReactInstanceManager não achada no RyzenEngine.java"
    e = e.replace(key, key + """
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(android.app.Activity a, android.os.Bundle b) {}
            @Override public void onActivityStarted(android.app.Activity a) {}
            @Override public void onActivityResumed(final android.app.Activity a) {
                try { mgr.onHostResume(a); } catch (Throwable t) {}
            }
            @Override public void onActivityPaused(android.app.Activity a) {}
            @Override public void onActivityStopped(android.app.Activity a) {}
            @Override public void onActivitySaveInstanceState(android.app.Activity a, android.os.Bundle b) {}
            @Override public void onActivityDestroyed(android.app.Activity a) {}
        });""", 1)
    ENG_JAVA.write_text(e)
print("ok")
