# Etapa 3 — render native (WebRTC) no motor

Tira o stream do render **nano** e passa a usar o render **native** do XStreaming (WebRTC), que tem
FSR 1 e frame generation (LSFG).

## O que tem
- `src/ryzen/RyzenNative.ts` — sessão sem tela (startSession → offer → SDP → ICE), keepalive, fila, rumble, estatísticas.
  Comandos: `nativeStart`, `nativeStop`, `nativePad`, `nativeStats`.
  Eventos: `nativeStage`, `nativeQueue`, `nativeStream`, `nativeState`, `nativeRumble`, `nativeError`.
- `java/RyzenNativeView*.java` — PlatformView que hospeda `RTCFsrVideoView` (FSR ou vídeo normal) ou `RTCFrameGenVideoView`.
- `dart/engine_native.dart`, `dart/native_stream.dart` — ponte e tela (carregamento, fila, vídeo, estatísticas, rumble).
- `apply_native_host.py` (raiz do XStreaming, depois das etapas 1 e 2b) e `apply_native_dart.py` (dentro do ryzen_app, depois do `apply_ryzen_dart.py`).

## Chaves (em `engine_play.dart`, depois de aplicar)
- `EnginePlay.useNative = true` → native. `false` volta para o nano.
- `EnginePlay.nativeProfile` → `fsr`, `smart_frame_generation`, `fsr_display_options.sharpness`.
  Frame generation vem desligado: precisa do `Lossless.dll` original instalado pelo XStreaming no aparelho.

## Como usar
1. Coloque `ryzen_etapa3.zip` na raiz do repositório host e troque o `build.yml` pelo novo.
2. Rode o workflow.

## Ainda NÃO tem (próximos passos)
Reconexão automática, gamepad USB/OTG, controle virtual na tela, gravação/screenshot/PiP,
microfone/chat, mapeamento de botões e gatilhos adaptativos.
