# Etapa 7 — Biblioteca com os jogos da conta + janela flutuante

## 1) Biblioteca
- Os jogos que sua conta pode jogar ("Posso jogar" na Loja) agora entram **sozinhos na Biblioteca** depois do login
  (o app carrega o catálogo ao abrir e coloca todos lá). Eles **não** são fixados na Início, para ela não lotar.
- Na Loja, o botão **Remover da Biblioteca** tira o jogo; ele não volta sozinho. **Adicionar à Biblioteca** o devolve
  (e fixa na Início). Jogos obtidos com o botão Obter continuam fixados na Início e na Biblioteca.
- As capas desses jogos vêm do catálogo da Microsoft (etapa 5).
- Imagens do card do jogo: agora em resolução maior (1280) e até 6 por jogo.

## 2) Janela flutuante
- Menu do jogo (Start): nova opção **Janela flutuante**. O jogo vira uma janelinha por cima do Ryzen e a **sessão
  continua aberta** (não reinicia). O controle passa a mexer no Ryzen.
- Na janela: arraste pela barra de cima para mover; **toque no vídeo** ou no ícone de expandir para voltar à tela cheia;
  **X** encerra o jogo.
- No controle: Start abre o painel rápido, que ganhou **Voltar ao jogo** e **Encerrar jogo** enquanto há uma janela.
- Abrir outro jogo enquanto há uma janela troca a sessão (o jogo antigo fecha).

## Arquivos
- `apply_etapa7.py` — rode dentro de `ryzen_app`, DEPOIS das etapas 2b, 3, 4, 5 e 6 (já está no `build.yml`). Pode rodar mais de uma vez.
- `dart/float_window.dart` — moldura da janela flutuante.
