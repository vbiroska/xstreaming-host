#!/usr/bin/env python3
"""Etapa 7 (Ryzen Flutter):
 1) Biblioteca: os jogos que sua conta pode jogar entram sozinhos na Biblioteca (sem lotar a Início).
 2) Janela flutuante no menu do jogo: a sessão continua aberta numa janelinha por cima do Ryzen.
 3) Imagens do card do jogo em resolução maior.
Rode dentro de ryzen_app, DEPOIS das etapas 2b, 3, 4, 5 e 6. Pode rodar mais de uma vez."""
import pathlib, re, shutil

HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"
assert "xboxHidden" in (lib / "state.dart").read_text(), "rode a etapa 6 antes"


def patch(path, edits):
    p = lib / path
    t = p.read_text()
    for old, new, what, marker in edits:
        if marker in t:
            continue  # já aplicado
        assert old in t, f"não achado em {path}: {what}"
        t = t.replace(old, new, 1)
    p.write_text(t)


# ============================================================ state.dart
OWNED = '''  /// Jogos que a conta já pode jogar entram sozinhos na Biblioteca (sem fixar na Início).
  void addXboxOwned(List<Map<String, String>> games) {
    var changed = false;
    for (final g in games) {
      final pid = g['pid'] ?? '';
      final title = g['title'] ?? '';
      if (pid.isEmpty || title.isEmpty || xboxHidden.contains(pid) || xboxTitleFor(pid) != null) continue;
      var name = title;
      final link = storeLink(name);
      if (storeTitles.contains(name) && link.isNotEmpty && !link.toUpperCase().contains(pid.toUpperCase())) {
        name = '$title (Xbox)';
      }
      final m = {'pid': pid, 'title': name, 'poster': g['poster'] ?? '', 'hero': g['hero'] ?? '', 'auto': '1'};
      xboxGames.add(m);
      _applyXboxGame(m);
      changed = true;
    }
    if (!changed) return;
    _p.setStringList('xboxGames', [for (final g in xboxGames) jsonEncode(g)]);
    _saveMap('autoLinks', autoLinks);
    _rebuild();
    notifyListeners();
  }

'''
FLOAT = '''  // ---------- janela flutuante do jogo ----------
  /// Reduz o jogo a uma janela por cima do Ryzen; a sessão continua aberta.
  void floatGame() {
    if (gameUrl == null || gameUrl == padTestUrl) return;
    gameFloat = true;
    gameMenu = false;
    Native.setMenuMode(true); // o controle passa a mexer no Ryzen
    sfx('ok');
    notifyListeners();
  }

  /// Volta o jogo para a tela cheia.
  void expandGame() {
    if (!gameFloat) return;
    gameFloat = false;
    if (layer == Layer.panel) layer = Layer.none;
    Native.setMenuMode(false);
    lastInput = DateTime.now();
    sfx('ok');
    notifyListeners();
  }

  void moveFloat(double dx, double dy) {
    if (!gameFloat) return;
    floatX += dx; // a tela limita a posição (main.dart devolve o valor já limitado)
    floatY += dy;
    notifyListeners();
  }

'''
patch("state.dart", [
    ("  Set<String> xboxHidden = {}; // pids que você tirou da Biblioteca (não voltam sozinhos)\n",
     "  Set<String> xboxHidden = {}; // pids que você tirou da Biblioteca (não voltam sozinhos)\n"
     "  bool gameFloat = false; // jogo reduzido a uma janela flutuante\n"
     "  double floatX = -1, floatY = -1; // posição da janela (-1 = canto inferior direito)\n"
     "  /// Jogo em tela cheia (com o controle e o menu do jogo).\n"
     "  bool get inGame => gameUrl != null && !gameFloat;\n",
     "campos xboxHidden", "bool gameFloat = false;"),
    # --- Biblioteca: jogos da conta entram sozinhos
    ("    return t != null && pinned.contains(t);", "    return t != null;", "xboxInLib", "    return t != null;\n"),
    ("      if (t.isEmpty || xboxHidden.contains(g['pid'])) continue;",
     "      if (t.isEmpty || xboxHidden.contains(g['pid']) || g['auto'] == '1') continue;",
     "_pinXboxGames", "|| g['auto'] == '1') continue;"),
    ("        if (t.isEmpty || pid.isEmpty) continue;\n",
     "        if (t.isEmpty || pid.isEmpty || g['auto'] == '1') continue; // as capas deles vêm do catálogo (etapa 5)\n",
     "_fetchXboxArt", "|| g['auto'] == '1') continue; // as capas"),
    ("    final known = xboxTitleFor(pid);\n    var name = known ?? title;\n",
     "    final known = xboxTitleFor(pid);\n    var name = known ?? title;\n"
     "    for (final g in xboxGames) {\n"
     "      if (g['pid'] == pid && g['auto'] == '1') {\n"
     "        g['auto'] = '0'; // adicionado por você: vale como fixado\n"
     "        _p.setStringList('xboxGames', [for (final x in xboxGames) jsonEncode(x)]);\n"
     "      }\n"
     "    }\n",
     "addXboxGame", "g['auto'] = '0'"),
    ("  /// Leva um jogo recém-obtido para a Biblioteca", OWNED + "  /// Leva um jogo recém-obtido para a Biblioteca", "marcador addXboxGame", "void addXboxOwned("),
    ("        l = [...all.where(isFav), ...all.where((e) => !isFav(e))];\n",
     "        final xo = {for (final g in xboxGames) if (g['auto'] == '1') g['title'] ?? ''};\n"
     "        final xextra = <HomeItem>[\n"
     "          for (var i = 0; i < storeTitles.length; i++)\n"
     "            if (xo.contains(storeTitles[i]) && !pinned.contains(storeTitles[i])) HomeItem.store(i)\n"
     "        ];\n"
     "        l = [...all.where(isFav), ...all.where((e) => !isFav(e)), ...xextra];\n",
     "_rebuildLib default", "final xo = {for"),
    # --- janela flutuante
    ("  /// Fecha o jogo/link em tela cheia e volta ao Ryzen.\n  void closeGame() {",
     FLOAT + "  /// Fecha o jogo/link em tela cheia e volta ao Ryzen.\n  void closeGame() {",
     "closeGame", "void floatGame()"),
    ("    gameMenu = false;\n    lastInput = DateTime.now();\n    notifyListeners();\n  }\n\n  /// Abre um link de jogo",
     "    gameMenu = false;\n    if (gameFloat) {\n      gameFloat = false;\n      Native.setMenuMode(false);\n    }\n"
     "    lastInput = DateTime.now();\n    notifyListeners();\n  }\n\n  /// Abre um link de jogo",
     "fim do closeGame", "    if (gameFloat) {\n      gameFloat = false;\n      Native.setMenuMode(false);\n    }\n    lastInput = DateTime.now();\n    notifyListeners();\n  }\n\n  /// Abre um link"),
    ("    gameUrl = u;\n    gameMenu = false;\n",
     "    gameUrl = u;\n    gameMenu = false;\n    if (gameFloat) {\n      gameFloat = false;\n      Native.setMenuMode(false);\n    }\n",
     "openLink", "    gameUrl = u;\n    gameMenu = false;\n    if (gameFloat)"),
    ("    gameUrl = 'ryzen://stream';\n    gameMenu = false;\n",
     "    gameUrl = 'ryzen://stream';\n    gameMenu = false;\n    if (gameFloat) {\n      gameFloat = false;\n      Native.setMenuMode(false);\n    }\n",
     "openStream", "    gameUrl = 'ryzen://stream';\n    gameMenu = false;\n    if (gameFloat)"),
    ("      if (gameUrl != null && !gameMenu) openQuick();", "      if (inGame && !gameMenu) openQuick();", "onGameMenu", "if (inGame && !gameMenu) openQuick();"),
    ("  int get quickIdx => gameUrl != null ? menuIdx : panelIdx;\n  set quickIdx(int v) {\n    if (gameUrl != null) {",
     "  int get quickIdx => inGame ? menuIdx : panelIdx;\n  set quickIdx(int v) {\n    if (inGame) {", "quickIdx", "int get quickIdx => inGame"),
    ("    if (gameUrl != null) {\n      return [\n        QRow(tr('Continuar jogando'), 'play', 'btn', () => '', closeQuick, (_) {}),\n",
     "    if (inGame) {\n      return [\n        QRow(tr('Continuar jogando'), 'play', 'btn', () => '', closeQuick, (_) {}),\n"
     "        QRow(tr('Janela flutuante'), 'brightness', 'btn', () => '', () {\n"
     "          closeQuick();\n          floatGame();\n        }, (_) {}),\n",
     "quickRows (jogo)", "QRow(tr('Janela flutuante')"),
    ("    return [\n      vol,\n      bri,\n      QRow(tr('Tema')",
     "    return [\n"
     "      if (gameFloat)\n        QRow(tr('Voltar ao jogo'), 'play', 'btn', () => '', () {\n          closeQuick();\n          expandGame();\n        }, (_) {}),\n"
     "      if (gameFloat)\n        QRow(tr('Encerrar jogo'), 'close', 'btn', () => '', () {\n          closeQuick();\n          closeGame();\n        }, (_) {}),\n"
     "      vol,\n      bri,\n      QRow(tr('Tema')",
     "quickRows (painel)", "QRow(tr('Voltar ao jogo')"),
    ("    if (!ready) return;\n    if (gameUrl != null) {\n      gameMenu = true;", "    if (!ready) return;\n    if (inGame) {\n      gameMenu = true;", "openQuick", "if (inGame) {\n      gameMenu = true;"),
    ("  void closeQuick() {\n    if (gameUrl != null) {", "  void closeQuick() {\n    if (inGame) {", "closeQuick", "void closeQuick() {\n    if (inGame)"),
    ("    lastInput = DateTime.now();\n    if (gameUrl != null) {\n      if (gameMenu) {", "    lastInput = DateTime.now();\n    if (inGame) {\n      if (gameMenu) {", "act()", "if (inGame) {\n      if (gameMenu) {"),
])

# ============================================================ quick.dart
patch("quick.dart", [("    final inGame = st.gameUrl != null;", "    final inGame = st.inGame;", "inGame", "final inGame = st.inGame;")])

# ============================================================ xbox_store.dart
patch("xbox_store.dart", [
    ("  bool _bg = false;\n", "  bool _bg = false;\n  bool _ownedSynced = false;\n", "campo _bg", "bool _ownedSynced"),
    ("    loading = true;\n    error = null;\n    notifyListeners();\n    try {\n      final l = await _Catalog.load",
     "    loading = true;\n    error = null;\n    _ownedSynced = false;\n    notifyListeners();\n    try {\n      final l = await _Catalog.load",
     "load()", "_ownedSynced = false;"),
    ("  /// Carrega as capas aos poucos",
     """  /// Quando os nomes dos jogos liberados chegam, todos eles entram na Biblioteca (sem fixar na Início).
  void _syncOwned() {
    if (_ownedSynced) return;
    final ps = all.where((g) => g.playable).toList();
    if (ps.isEmpty || !ps.every((g) => g.triedOk)) return;
    _ownedSynced = true;
    st.addXboxOwned([
      for (final g in ps)
        if (g.name.isNotEmpty) {'pid': g.pid, 'title': g.name, 'poster': g.poster ?? '', 'hero': g.hero ?? ''}
    ]);
  }

  /// Carrega as capas aos poucos""", "marcador _background", "void _syncOwned()"),
    ("        await _Catalog.fetchDetails(src.sublist(i, math.min(i + bs, src.length)));\n        notifyListeners();\n",
     "        await _Catalog.fetchDetails(src.sublist(i, math.min(i + bs, src.length)));\n        notifyListeners();\n        _syncOwned();\n",
     "worker", "        _syncOwned();\n"),
    ("            if (purpose == 'Screenshot' && g.shots.length < 4) {\n              final sImg = _img(u, 640);",
     "            if (purpose == 'Screenshot' && g.shots.length < 6) {\n              final sImg = _img(u, 1280);",
     "capturas de tela", "g.shots.length < 6"),
])

# ============================================================ float_window.dart + main.dart
shutil.copy(HERE / "dart" / "float_window.dart", lib / "float_window.dart")

GAME_OLD = """                if (st.gameUrl != null)
                  Positioned.fill(
                      child: st.streamInfo != null
                          ? StreamView(key: ValueKey(st.streamInfo), info: st.streamInfo!, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)
                          : GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),
"""
GAME_LAYER = """  /// O jogo em tela cheia ou, na janela flutuante, numa janelinha (a mesma vista: a sessão não reinicia).
  Widget _gameLayer(BuildContext context, double s) {
    final Widget game = st.streamInfo != null
        ? StreamView(key: ValueKey(st.streamInfo), info: st.streamInfo!, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)
        : GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner);
    final size = MediaQuery.sizeOf(context);
    final fl = st.gameFloat;
    final w = 560 * s < size.width * 0.6 ? 560 * s : size.width * 0.6;
    final h = w * 9 / 16;
    final x = (st.floatX < 0 ? size.width - w - 24 * s : st.floatX).clamp(0.0, size.width - w).toDouble();
    final y = (st.floatY < 0 ? size.height - h - 96 * s : st.floatY).clamp(0.0, size.height - h).toDouble();
    if (fl) {
      st.floatX = x; // guarda a posição já limitada à tela (sem redesenhar)
      st.floatY = y;
    }
    return Positioned(
      key: const ValueKey('gamelayer'),
      left: fl ? x : 0,
      top: fl ? y : 0,
      right: fl ? null : 0,
      bottom: fl ? null : 0,
      width: fl ? w : null,
      height: fl ? h : null,
      child: Stack(children: [
        Positioned.fill(
          child: ClipRRect(
            clipBehavior: fl ? Clip.antiAlias : Clip.none,
            borderRadius: BorderRadius.circular(fl ? 14 * s : 0),
            child: game,
          ),
        ),
        if (fl) const Positioned.fill(child: FloatChrome()),
      ]),
    );
  }

"""
BUILD_ANCHOR = "  @override\n  Widget build(BuildContext context) {\n    return ListenableBuilder(\n      listenable: st,\n      builder: (context, _) {\n        if (!st.ready)"
patch("main.dart", [
    ("import 'engine_play.dart';", "import 'engine_play.dart';\nimport 'float_window.dart';", "import", "import 'float_window.dart';"),
    (BUILD_ANCHOR, GAME_LAYER + BUILD_ANCHOR, "build do app", "Widget _gameLayer("),
    ("  bool _xcKick = false;\n", "  bool _xcKick = false;\n  bool _wasFloat = false;\n", "campo _xcKick", "bool _wasFloat"),
    ("        _hadGame = hasGame;\n",
     "        _hadGame = hasGame;\n"
     "        if (_wasFloat != st.gameFloat) {\n"
     "          // entrou/saiu da janela flutuante: o foco volta para o Ryzen (ou para o jogo)\n"
     "          _wasFloat = st.gameFloat;\n"
     "          WidgetsBinding.instance.addPostFrameCallback((_) {\n"
     "            if (mounted) fn.requestFocus();\n"
     "          });\n"
     "        }\n",
     "foco da janela", "if (_wasFloat != st.gameFloat)"),
    ("        final tabs = <Widget>[HomeTab(), LibraryTab(), StoreTab(), SettingsTab()];\n",
     "        final tabs = <Widget>[HomeTab(), LibraryTab(), StoreTab(), SettingsTab()];\n"
     "        final Widget? gameLayer = st.gameUrl == null ? null : _gameLayer(context, s);\n",
     "tabs", "final Widget? gameLayer"),
    (GAME_OLD, "                if (gameLayer != null && !st.gameFloat) gameLayer,\n", "camada do jogo", "if (gameLayer != null && !st.gameFloat) gameLayer,"),
    ("                if (st.layer != Layer.none) Positioned.fill(child: LayerView()),\n",
     "                if (gameLayer != null && st.gameFloat) gameLayer, // janela flutuante fica sob os painéis do Ryzen\n"
     "                if (st.layer != Layer.none) Positioned.fill(child: LayerView()),\n",
     "camada flutuante", "if (gameLayer != null && st.gameFloat) gameLayer,"),
    ("VideoBg(path: video, paused: st.gameUrl != null)", "VideoBg(path: video, paused: st.inGame)", "vídeo de fundo", "paused: st.inGame"),
])
print("ok")
