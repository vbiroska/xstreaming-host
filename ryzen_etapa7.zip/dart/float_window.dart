import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';

/// Moldura da janela flutuante do jogo: barra de título (arrastar, expandir, encerrar)
/// e toque no vídeo para voltar à tela cheia. A sessão continua rodando por baixo.
class FloatChrome extends StatelessWidget {
  const FloatChrome({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Stack(children: [
      Positioned.fill(
        child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: st.expandGame),
      ),
      Positioned(
        top: 0,
        left: 0,
        right: 0,
        height: 40 * s,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanUpdate: (d) => st.moveFloat(d.delta.dx, d.delta.dy),
          child: Container(
            padding: EdgeInsets.only(left: 14 * s),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xCC000000), Color(0x00000000)],
              ),
            ),
            child: Row(children: [
              Expanded(
                child: Text(
                  st.gameTitle ?? 'Jogo em andamento',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: ts(context, 15, color: Colors.white, bold: true),
                ),
              ),
              IconButton(
                tooltip: 'Tela cheia',
                visualDensity: VisualDensity.compact,
                onPressed: st.expandGame,
                icon: Icon(Icons.open_in_full, size: 20 * s, color: Colors.white),
              ),
              IconButton(
                tooltip: 'Encerrar jogo',
                visualDensity: VisualDensity.compact,
                onPressed: st.closeGame,
                icon: Icon(Icons.close, size: 22 * s, color: Colors.white),
              ),
            ]),
          ),
        ),
      ),
      Positioned.fill(
        child: IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14 * s),
              border: Border.all(color: Colors.white38, width: 2 * s),
            ),
          ),
        ),
      ),
    ]);
  }
}
