#!/usr/bin/env python3
"""Etapa 2a: põe o Ryzen (Flutter, via AAR) dentro do projeto XStreaming.
Rode na raiz do XStreaming. Env: RYZEN_APP (pasta do app Flutter), RYZEN_REPO (repo maven do AAR)."""
import os, re, pathlib, shutil

ROOT = pathlib.Path.cwd()
APP = pathlib.Path(os.environ["RYZEN_APP"])
REPO = os.environ["RYZEN_REPO"]
A = ROOT / "android"
M = A / "app/src/main"

def edit(path, fn):
    s = path.read_text()
    n = fn(s)
    if n == s:
        print("AVISO: nada mudou em", path)
    path.write_text(n)

# 1) MainActivity do Ryzen (Kotlin) + ligação com o motor
dst = M / "kotlin/com/ryzen/ryzen"
dst.mkdir(parents=True, exist_ok=True)
src = (APP / "android_patch/MainActivity.kt").read_text()
if "RyzenEngine" not in src:
    src = src.replace("import io.flutter.plugin.common.MethodChannel",
                      "import io.flutter.plugin.common.MethodChannel\nimport com.xstreaming.RyzenEngine", 1)
    hook = '''
        // --- motor do XStreaming ---
        val eng = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/engine")
        RyzenEngine.start(application)
        RyzenEngine.setEvents { name, json ->
            runOnUiThread { eng.invokeMethod("event", mapOf("name" to name, "json" to json)) }
        }
        eng.setMethodCallHandler { call, result ->
            if (call.method == "call") {
                RyzenEngine.call(call.argument<String>("cmd")!!, call.argument<String>("args")) { ok, json ->
                    runOnUiThread {
                        if (ok) result.success(json) else result.error("engine", json, null)
                    }
                }
            } else result.notImplemented()
        }
'''
    key = 'channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/native")'
    assert key in src, "ponto de ligação não achado no MainActivity.kt"
    src = src.replace(key, key + hook, 1)
(dst / "MainActivity.kt").write_text(src)

# 2) estilos usados pelo manifest do Ryzen
(M / "res/values/ryzen_styles.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="RyzenLaunchTheme" parent="@android:style/Theme.Black.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
    </style>
    <style name="RyzenNormalTheme" parent="@android:style/Theme.Black.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
    </style>
</resources>
''')

# 3) AndroidManifest
def manifest(s):
    if "com.ryzen.ryzen.MainActivity" in s:
        return s
    perms = {
      "android.permission.QUERY_ALL_PACKAGES": "",
      "android.permission.ACCESS_FINE_LOCATION": "",
      "android.permission.BLUETOOTH_SCAN": ' android:usesPermissionFlags="neverForLocation"',
    }
    extra = ""
    for p, attr in perms.items():
        if p not in s:
            extra += f'    <uses-permission android:name="{p}"{attr}/>\n'
    s = s.replace("    <application", extra + "\n    <application", 1)
    # XStreaming deixa de ser o ícone da tela inicial
    s = re.sub(r"\s*<intent-filter>(?:(?!</intent-filter>).)*LEANBACK_LAUNCHER(?:(?!</intent-filter>).)*</intent-filter>",
               "", s, count=1, flags=re.S)
    act = '''
      <meta-data android:name="flutterEmbedding" android:value="2" />
      <activity
        android:name="com.ryzen.ryzen.MainActivity"
        android:exported="true"
        android:launchMode="singleTask"
        android:theme="@style/RyzenLaunchTheme"
        android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
        android:hardwareAccelerated="true"
        android:windowSoftInputMode="adjustResize"
        android:screenOrientation="sensorLandscape">
        <meta-data android:name="io.flutter.embedding.android.NormalTheme" android:resource="@style/RyzenNormalTheme" />
        <intent-filter>
          <action android:name="android.intent.action.MAIN" />
          <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
        <intent-filter>
          <action android:name="android.intent.action.MAIN" />
          <category android:name="android.intent.category.HOME" />
          <category android:name="android.intent.category.DEFAULT" />
        </intent-filter>
      </activity>
'''
    s = s.replace("</application>", act + "    </application>", 1)
    s = s.replace("</manifest>", '''    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
        </intent>
    </queries>
</manifest>''', 1)
    return s
edit(M / "AndroidManifest.xml", manifest)

# 4) build.gradle da raiz: Kotlin + repositórios do Flutter/AAR
def root_gradle(s):
    if "kotlin-gradle-plugin" in s:
        return s
    s = s.replace('classpath("com.facebook.react:react-native-gradle-plugin")',
                  'classpath("com.facebook.react:react-native-gradle-plugin")\n        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24")', 1)
    s += f'''
allprojects {{
    repositories {{
        maven {{ url "file://{REPO}" }}
        maven {{ url "https://storage.googleapis.com/download.flutter.io" }}
    }}
}}
'''
    return s
edit(A / "build.gradle", root_gradle)

# 5) build.gradle do app
def app_gradle(s):
    if "kotlin-android" in s:
        return s
    s = s.replace('apply plugin: "com.facebook.react"', 'apply plugin: "com.facebook.react"\napply plugin: "kotlin-android"', 1)
    s = s.replace('namespace "com.xstreaming"', '''namespace "com.xstreaming"
    kotlinOptions {
        jvmTarget = "1.8"
        freeCompilerArgs += ["-Xskip-metadata-version-check"]
    }
    packagingOptions {
        pickFirst "**/libc++_shared.so"
    }''', 1)
    s = s.replace('implementation("com.facebook.react:react-android")',
                  'implementation("com.facebook.react:react-android")\n    releaseImplementation "com.ryzen.ryzen:flutter_release:1.0"', 1)
    s += '''
// o Flutter novo exige AGP/compileSdk maiores do que o React Native 0.72 usa: desliga só a checagem.
tasks.configureEach { t ->
    if (t.name.endsWith("CheckAarMetadata")) { t.enabled = false }
}
'''
    return s
edit(A / "app/build.gradle", app_gradle)
print("ok")
