import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';

/// Tela de teste da etapa 2a: login Microsoft (WebView) + lista de jogos + streamInfo.
class EngineTest extends StatefulWidget {
  const EngineTest({super.key});
  @override
  State<EngineTest> createState() => _EngineTestState();
}

class _EngineTestState extends State<EngineTest> {
  String log = 'Iniciando o motor...';
  WebViewController? web;
  List<String> ids = [];
  bool busy = false;

  void say(String s) {
    if (mounted) setState(() => log = s);
  }

  @override
  void initState() {
    super.initState();
    Engine.init();
    Engine.onEvent = (n, d) => say('evento: $n $d');
    _start();
  }

  Future<void> _run(Future<void> Function() f) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await f();
    } catch (e) {
      say('ERRO: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _start() => _run(() async {
        final ok = await Engine.initSession();
        if (ok) {
          await _list();
        } else {
          say('Motor OK. Sem login salvo: toque em "Entrar com Microsoft".');
        }
      });

  Future<void> _login() => _run(() async {
        final r = await Engine.loginStart();
        final scheme = r['scheme'] as String;
        final c = WebViewController()
          ..setJavaScriptMode(JavaScriptMode.unrestricted)
          ..setUserAgent(
              'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36')
          ..setNavigationDelegate(NavigationDelegate(
            onNavigationRequest: (req) {
              if (req.url.startsWith(scheme)) {
                _finish(req.url);
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ))
          ..loadRequest(Uri.parse(r['authUrl'] as String));
        setState(() => web = c);
      });

  Future<void> _finish(String url) async {
    setState(() => web = null);
    await _run(() async {
      say('Concluindo o login...');
      await Engine.loginFinish(url);
      await _list();
    });
  }

  Future<void> _list() async {
    say('Buscando jogos...');
    final t = await Engine.titles();
    final res = (t is Map ? t['results'] : null) as List? ?? [];
    ids = res
        .map((e) => (e is Map ? (e['titleId'] ?? e['XCloudTitleId'] ?? '') : '').toString())
        .where((e) => e.isNotEmpty)
        .toList();
    say('Login OK. ${ids.length} jogos no Game Pass (nuvem).');
  }

  Future<void> _prepare() => _run(() async {
        if (ids.isEmpty) {
          say('Liste os jogos primeiro.');
          return;
        }
        final s = await Engine.prepareStream(ids.first);
        final auth = Map.from(s['auth'] as Map);
        say('streamInfo OK para ${ids.first}\n'
            'baseUri: ${s['baseUri']}\n'
            'connectUserToken: ${(auth['connectUserToken'] ?? '').toString().length} chars\n'
            'gsToken: ${(s['gsToken'] ?? '').toString().length} chars');
      });

  @override
  Widget build(BuildContext context) {
    if (web != null) {
      return Scaffold(
        body: SafeArea(child: WebViewWidget(controller: web!)),
        floatingActionButton: FloatingActionButton.small(
          onPressed: () => setState(() => web = null),
          child: const Icon(Icons.close),
        ),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              flex: 3,
              child: SingleChildScrollView(
                child: Text(log, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
            const SizedBox(width: 16),
            Column(mainAxisSize: MainAxisSize.min, children: [
              FilledButton(onPressed: busy ? null : _login, child: const Text('Entrar com Microsoft')),
              const SizedBox(height: 8),
              FilledButton(onPressed: busy ? null : () => _run(_list), child: const Text('Listar jogos')),
              const SizedBox(height: 8),
              FilledButton(onPressed: busy ? null : _prepare, child: const Text('Preparar 1º jogo')),
              if (busy) const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()),
            ]),
          ]),
        ),
      ),
    );
  }
}
