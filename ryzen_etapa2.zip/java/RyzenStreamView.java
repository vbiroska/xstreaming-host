package com.xstreaming;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.ThemedReactContext;
import com.xstreaming.nano.NanoStreamView;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.platform.PlatformView;

/** Coloca o NanoStreamView (vídeo + Rust) dentro de uma tela Flutter. */
public class RyzenStreamView implements PlatformView, MethodChannel.MethodCallHandler {
    private static final String TAG = "RyzenStreamView";

    private final NanoStreamView view;
    private final MethodChannel channel;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Map<String, Object> lastState = new HashMap<>();

    RyzenStreamView(Context context, BinaryMessenger messenger, int id, @Nullable String streamInfoJson) {
        ReactContext rc = RyzenEngine.reactContext();
        if (rc == null) throw new IllegalStateException("motor do XStreaming ainda não iniciou");

        view = new NanoStreamView(new ThemedReactContext(rc, context));
        view.setShowStatus(false);

        channel = new MethodChannel(messenger, "ryzen/nano_view_" + id);
        channel.setMethodCallHandler(this);

        view.setEventSink((name, data) -> {
            if ("state".equals(name)) lastState = data;
            main.post(() -> channel.invokeMethod(name, data));
        });

        if (streamInfoJson != null) applyStreamInfo(streamInfoJson);
    }

    private void applyStreamInfo(String json) {
        try {
            view.setStreamInfo(JsonRn.map(new JSONObject(json)));
        } catch (Exception e) {
            Log.e(TAG, "streamInfo inválido", e);
        }
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        try {
            switch (call.method) {
                case "state":
                    result.success(lastState);
                    return;
                case "streamInfo":
                    applyStreamInfo(String.valueOf(call.arguments));
                    break;
                case "start":
                    view.startSession();
                    break;
                case "stop":
                    view.stopSession();
                    break;
                case "focus":
                    view.requestNanoFocus();
                    break;
                case "statusText":
                    view.setStatusText(call.arguments == null ? "" : String.valueOf(call.arguments));
                    break;
                case "showStatus":
                    view.setShowStatus(Boolean.TRUE.equals(call.arguments));
                    break;
                case "gamepad":
                    view.sendGamepadState(JsonRn.map(new JSONObject((Map<?, ?>) call.arguments)));
                    break;
                default:
                    result.notImplemented();
                    return;
            }
            result.success(null);
        } catch (Exception e) {
            result.error("nano", String.valueOf(e), null);
        }
    }

    @Override
    public View getView() { return view; }

    @Override
    public void dispose() {
        channel.setMethodCallHandler(null);
        try { view.stopSession(); } catch (Throwable ignored) {}
    }
}
