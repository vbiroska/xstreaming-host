#!/usr/bin/env python3
"""Roda na pasta do app Flutter (ryzen_app): vira módulo (AAR) e mostra a tela de teste do motor."""
import re, shutil, pathlib
HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"

for f in ("engine.dart", "engine_test.dart"):
    shutil.copy(HERE / "dart" / f, lib / f)

m = lib / "main.dart"
s = m.read_text()
if "engine_test.dart" not in s:
    s = s.replace("import 'game.dart';", "import 'engine_test.dart';\nimport 'game.dart';", 1)
    s = s.replace("home: const Shell(),",
                  "home: (const bool.fromEnvironment('ENGINE_TEST', defaultValue: true)) ? const EngineTest() : const Shell(),", 1)
    assert "EngineTest()" in s
    m.write_text(s)

p = pathlib.Path("pubspec.yaml")
t = p.read_text()
if "module:" not in t:
    t = re.sub(r"^flutter:\n", "flutter:\n  module:\n    androidX: true\n    androidPackage: com.ryzen.ryzen\n    iosBundleIdentifier: com.ryzen.ryzen\n", t, count=1, flags=re.M)
    assert "module:" in t
    p.write_text(t)
print("ok")
