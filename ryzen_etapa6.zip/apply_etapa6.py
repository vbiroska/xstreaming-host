#!/usr/bin/env python3
"""Etapa 6 (Ryzen Flutter): card do jogo em tela cheia, imagens maiores,
Adicionar/Remover da Biblioteca e jogos obtidos reaplicados na Biblioteca depois do login.
Rode dentro de ryzen_app, DEPOIS das etapas 2b, 3, 4 e 5. Pode rodar mais de uma vez."""
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"


def patch(path, edits):
    p = lib / path
    t = p.read_text()
    for old, new, what, marker in edits:
        if marker in t:
            continue  # já aplicado
        assert old in t, f"não achado em {path}: {what}"
        t = t.replace(old, new, 1)
    p.write_text(t)


# ------------------------------------------------------------------ state.dart
STATE_METHODS = '''  // ---------- adicionar / remover jogos obtidos da Biblioteca ----------
  /// O jogo (productId) está na Biblioteca por causa do Catálogo Xbox?
  bool xboxInLib(String pid) {
    final t = xboxTitleFor(pid);
    return t != null && pinned.contains(t);
  }

  /// Garante que os jogos obtidos (e não removidos por você) estão fixados na Biblioteca e na Início.
  void _pinXboxGames() {
    var changed = false;
    for (final g in xboxGames) {
      final t = g['title'] ?? '';
      if (t.isEmpty || xboxHidden.contains(g['pid'])) continue;
      if (!pinned.contains(t)) {
        pinned.add(t);
        changed = true;
      }
    }
    if (changed) _p.setStringList('pinnedStore', pinned);
  }

  /// Depois do login (catálogo carregado): reaplica os jogos obtidos na Biblioteca.
  void syncXboxLibrary() {
    for (final g in xboxGames) {
      if (!xboxHidden.contains(g['pid'])) _applyXboxGame(g);
    }
    _pinXboxGames();
    _rebuild();
    notifyListeners();
    if (xboxGames.isNotEmpty) _fetchXboxArt();
  }

  /// Tira o jogo da Biblioteca e da Início (a conta continua com o jogo; ele só não volta sozinho).
  Future<void> removeXboxGame(String pid) async {
    final name = xboxTitleFor(pid);
    if (name == null) return;
    xboxGames.removeWhere((g) => g['pid'] == pid);
    _p.setStringList('xboxGames', [for (final g in xboxGames) jsonEncode(g)]);
    xboxHidden.add(pid);
    _p.setStringList('xboxHidden', xboxHidden.toList());
    pinned.remove(name);
    _p.setStringList('pinnedStore', pinned);
    if (!_allStoreTitles.contains(name)) {
      storeTitles.remove(name);
      autoLinks.remove(name);
      _saveMap('autoLinks', autoLinks);
    }
    _rebuild();
    notifyListeners();
  }

'''
ADD_MARK = "  /// Leva um jogo recém-obtido para a Biblioteca"
patch("state.dart", [
    ("  List<Map<String, String>> xboxGames = []; // obtidos no Catálogo Xbox: pid, title, poster, hero\n",
     "  List<Map<String, String>> xboxGames = []; // obtidos no Catálogo Xbox: pid, title, poster, hero\n"
     "  Set<String> xboxHidden = {}; // pids que você tirou da Biblioteca (não voltam sozinhos)\n",
     "campo xboxGames", "xboxHidden = {}"),
    ("    xboxGames = [];\n    for (final j in _p.getStringList('xboxGames')",
     "    xboxGames = [];\n    xboxHidden = (_p.getStringList('xboxHidden') ?? const <String>[]).toSet();\n"
     "    for (final j in _p.getStringList('xboxGames')",
     "_restoreXboxGames", "xboxHidden = (_p"),
    ("    if (xboxGames.isNotEmpty) _fetchXboxArt();\n  }\n",
     "    _pinXboxGames();\n    if (xboxGames.isNotEmpty) _fetchXboxArt();\n  }\n",
     "fim do _restoreXboxGames", "    _pinXboxGames();\n    if (xboxGames.isNotEmpty)"),
    ("    final known = xboxTitleFor(pid);\n",
     "    if (xboxHidden.remove(pid)) _p.setStringList('xboxHidden', xboxHidden.toList());\n"
     "    final known = xboxTitleFor(pid);\n",
     "addXboxGame", "if (xboxHidden.remove(pid))"),
    (ADD_MARK, STATE_METHODS + ADD_MARK, "marcador do addXboxGame", "bool xboxInLib(String pid)"),
])

# ------------------------------------------------------------------ xbox_store.dart
xp = lib / "xbox_store.dart"
t = xp.read_text()
if "class XboxDetailOverlay" not in t:
    # 1) o card antigo (pequeno) sai da aba; entra o de tela cheia
    old_call = "          if (xc.detail != null) _detailView(context, xc.detail!),\n"
    assert old_call in t, "chamada do _detailView não achada"
    t = t.replace(old_call, "", 1)
    i = t.index("  Widget _detailView(BuildContext context, XboxGame g) {")
    j = t.index("class _SearchDialog extends StatefulWidget")
    new_widget = (HERE / "dart" / "detail_full.dart").read_text()
    t = t[:i].rstrip() + "\n}\n\n" + new_widget + "\n\n" + t[j:]

    # 2) catálogo: rolagem do card, adicionar/remover, sincronização
    old = "  XboxGame? detail;\n"
    assert old in t, "campo detail não achado"
    t = t.replace(old, old + "  final ScrollController dc = ScrollController(); // rolagem do card em tela cheia\n", 1)

    old = "      loaded = true;\n      loading = false;\n      notifyListeners();\n      _background();\n"
    assert old in t, "fim do load() não achado"
    t = t.replace(old, old + "      st.syncXboxLibrary(); // jogos obtidos voltam para a Biblioteca depois do login\n", 1)

    old = """      if (a == Act.cancel) {
        closeDetail();
      } else if (a == Act.accept) {
        primary(d);
      }
      return true;"""
    assert old in t, "act() do card não achado"
    t = t.replace(old, """      if (a == Act.cancel) {
        closeDetail();
      } else if (a == Act.accept) {
        primary(d);
      } else if (a == Act.details || a == Act.favorite) {
        toggleLibrary(d);
      } else if ((a == Act.up || a == Act.down) && dc.hasClients) {
        final to = (dc.offset + (a == Act.down ? 320 : -320)).clamp(0.0, dc.position.maxScrollExtent).toDouble();
        dc.animateTo(to, duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
      }
      return true;""", 1)

    old = "  /// Botão principal do card: jogar (se liberado) ou obter (se bloqueado).\n"
    assert old in t, "marcador do primary() não achado"
    t = t.replace(old, """  /// Adiciona o jogo à Biblioteca (e Início) ou tira de lá. Só para jogos que a conta pode jogar.
  Future<void> toggleLibrary(XboxGame g) async {
    if (busy != null) return;
    if (!g.playable) {
      note = 'Primeiro obtenha o jogo para poder colocá-lo na Biblioteca.';
      noteOk = false;
      notifyListeners();
      return;
    }
    if (st.xboxInLib(g.pid)) {
      await st.removeXboxGame(g.pid);
      note = 'Removido da Biblioteca.';
    } else {
      await st.addXboxGame(g.title, g.pid, posterUrl: g.poster, heroUrl: g.hero);
      note = 'Adicionado à Biblioteca.';
    }
    noteOk = true;
    st.sfx('ok');
    notifyListeners();
  }

""" + old, 1)
    xp.write_text(t)

# ------------------------------------------------------------------ main.dart
mp = lib / "main.dart"
m = mp.read_text()
if "XboxDetailOverlay" not in m:
    k = "import 'tabs.dart';"
    assert k in m, "import tabs.dart não achado"
    m = m.replace(k, k + "\nimport 'xbox_store.dart';", 1)
    old = "                Positioned(bottom: 0, left: 0, right: 0, height: 80 * s, child: Footer()),\n"
    assert old in m, "Footer não achado no main.dart"
    m = m.replace(old, old + "                if (st.tab == 2) const Positioned.fill(child: XboxDetailOverlay()),\n", 1)
    old = "        _hadGame = hasGame;\n"
    assert old in m, "_hadGame não achado"
    m = m.replace(old, old + """        if (!_xcKick) {
          // logado: já carrega o catálogo para reaplicar os jogos obtidos na Biblioteca
          _xcKick = true;
          WidgetsBinding.instance.addPostFrameCallback((_) => xc.ensureLoaded());
        }
""", 1)
    import re
    mm = re.search(r"^(\s*)bool _hadGame\b.*$", m, re.M)
    assert mm, "campo _hadGame não achado"
    m = m[:mm.end()] + "\n" + mm.group(1) + "bool _xcKick = false;" + m[mm.end():]
    mp.write_text(m)
print("ok")
