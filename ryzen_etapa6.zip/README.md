# Etapa 6 — card do jogo em tela cheia + Adicionar/Remover da Biblioteca

## O que muda (aba Loja, ao abrir um jogo)
- O card agora ocupa a **tela inteira** (por cima da barra de cima e do rodapé): banner grande no topo, capa maior,
  título/descrição maiores e as **imagens do jogo bem maiores** (516×290, em carrossel horizontal).
- Controle: **A** jogar/obter · **Y** adicionar/remover da Biblioteca · **B** voltar · **↑ ↓** rolar o card.
- Novo botão **Adicionar à Biblioteca / Remover da Biblioteca** (aparece nos jogos que sua conta pode jogar).
  Adicionar = fixa na Biblioteca e na Início, com capa e banner. Remover = tira de lá (a conta continua com o jogo).
- **Depois do login** o app já carrega o catálogo e reaplica na Biblioteca todos os jogos obtidos/adicionados
  (antes eles só voltavam se a aba Loja fosse aberta, e a lista de fixados podia ser limpa na atualização).
  Jogos que você removeu de propósito não voltam sozinhos; adicionar de novo desfaz isso.

## Arquivos
- `apply_etapa6.py` — rode dentro de `ryzen_app`, DEPOIS das etapas 2b, 3, 4 e 5 (já está no `build.yml`). Pode rodar mais de uma vez.
- `dart/detail_full.dart` — o card em tela cheia.

## Limite
O app não tem como saber quais jogos você "comprou" versus os do Game Pass: ele reaplica os que você obteve pelo botão
Obter ou adicionou aqui. Não adiciona todos os "Posso jogar" sozinho (seriam centenas na Início).
