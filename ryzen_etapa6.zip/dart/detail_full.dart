// ============================ CARD DO JOGO EM TELA CHEIA ============================
/// Fica por cima de tudo (barra de cima e rodapé inclusos) quando um jogo é aberto na aba Loja.
class XboxDetailOverlay extends StatelessWidget {
  const XboxDetailOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([xc, st]),
      builder: (context, _) {
        final g = xc.detail;
        if (g == null) return const SizedBox.shrink();
        final s = context.s;
        return Stack(children: [
          Positioned.fill(child: _fullDetail(context, g)),
          if (xc.busy != null)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black54,
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const CircularProgressIndicator(),
                    SizedBox(height: 14 * s),
                    Text(xc.busy!, style: ts(context, 20, color: Colors.white)),
                  ]),
                ),
              ),
            ),
        ]);
      },
    );
  }
}

Widget _fullDetail(BuildContext context, XboxGame g) {
  final s = context.s;
  final name = g.title;
  final sub = [if (g.dev.isNotEmpty) g.dev, if (g.cat.isNotEmpty) g.cat].join('  ·  ');
  final playable = g.playable;
  final inLib = st.xboxInLib(g.pid);
  final heroH = 340 * s;
  const bg = Color(0xFF0E121B);
  final btnPad = EdgeInsets.symmetric(horizontal: 30 * s, vertical: 18 * s);
  final btnText = TextStyle(fontSize: 20 * s, fontWeight: FontWeight.w600);
  return Material(
    color: bg,
    child: SingleChildScrollView(
      controller: xc.dc,
      child: Stack(children: [
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: heroH,
          child: Stack(fit: StackFit.expand, children: [
            if (g.hero != null)
              Image(
                image: ResizeImage(NetworkImage(g.hero!), width: 1920),
                fit: BoxFit.cover,
                errorBuilder: (c, e, st2) => const SizedBox.shrink(),
              ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x80000000), Color(0x000E121B), bg],
                  stops: [0.0, 0.4, 1.0],
                ),
              ),
            ),
          ]),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(56 * s, 0, 56 * s, 44 * s),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(height: heroH - 90 * s),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                width: 210 * s,
                height: 300 * s,
                child: Glass(
                  radius: 14 * s,
                  frosted: false,
                  child: Padding(
                    padding: EdgeInsets.all(6 * s),
                    child: Art(
                      img: g.poster != null ? NetworkImage(g.poster!) : null,
                      fit: BoxFit.cover,
                      title: name,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 36 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(height: 70 * s),
                  Text(name, style: ts(context, 38, bold: true, color: Colors.white)),
                  if (sub.isNotEmpty) ...[
                    SizedBox(height: 4 * s),
                    Text(sub, style: ts(context, 18, color: Colors.white60)),
                  ],
                  SizedBox(height: 10 * s),
                  Row(children: [
                    Icon(playable ? Icons.check_circle : Icons.lock,
                        size: 24 * s, color: playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                    SizedBox(width: 10 * s),
                    Expanded(
                      child: Text(
                        playable
                            ? 'Disponível para jogar na nuvem'
                            : 'Sua conta não tem este jogo ainda. Toque em Obter para adicioná-lo.',
                        style: ts(context, 18, color: playable ? Colors.lightGreenAccent : Colors.orangeAccent),
                      ),
                    ),
                  ]),
                  if (xc.note != null) ...[
                    SizedBox(height: 8 * s),
                    Text(xc.note!, style: ts(context, 17, color: xc.noteOk ? Colors.lightGreenAccent : Colors.white70)),
                  ],
                  SizedBox(height: 12 * s),
                  Text(
                    g.desc.isEmpty ? 'Sem descrição.' : g.desc,
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                    style: ts(context, 18, color: Colors.white70).copyWith(height: 1.35),
                  ),
                ]),
              ),
            ]),
            SizedBox(height: 22 * s),
            Wrap(spacing: 16 * s, runSpacing: 12 * s, crossAxisAlignment: WrapCrossAlignment.center, children: [
              FilledButton.icon(
                onPressed: () => xc.primary(g),
                style: FilledButton.styleFrom(padding: btnPad, textStyle: btnText),
                icon: Icon(playable ? Icons.play_arrow : Icons.add_shopping_cart, size: 26 * s),
                label: Text(playable ? 'Jogar na nuvem' : 'Obter'),
              ),
              if (playable)
                OutlinedButton.icon(
                  onPressed: () => xc.toggleLibrary(g),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Colors.white54),
                    padding: btnPad,
                    textStyle: btnText,
                  ),
                  icon: Icon(inLib ? Icons.bookmark_remove : Icons.bookmark_add, size: 26 * s),
                  label: Text(inLib ? 'Remover da Biblioteca' : 'Adicionar à Biblioteca'),
                ),
              if (!playable && g.priceText.isNotEmpty)
                Text(g.priceText, style: ts(context, 22, bold: true, color: Colors.white)),
              TextButton(
                onPressed: xc.closeDetail,
                style: TextButton.styleFrom(padding: btnPad, textStyle: btnText),
                child: const Text('Fechar'),
              ),
            ]),
            if (g.shots.isNotEmpty) ...[
              SizedBox(height: 30 * s),
              Text('Imagens', style: ts(context, 22, bold: true, color: Colors.white)),
              SizedBox(height: 12 * s),
              SizedBox(
                height: 290 * s,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: g.shots.length,
                  separatorBuilder: (_, __) => SizedBox(width: 14 * s),
                  itemBuilder: (c, i) => ClipRRect(
                    borderRadius: BorderRadius.circular(12 * s),
                    child: SizedBox(
                      width: 516 * s,
                      child: Image(
                        image: ResizeImage(NetworkImage(g.shots[i]), width: 1100),
                        fit: BoxFit.cover,
                        errorBuilder: (c2, e, st2) => const SizedBox.shrink(),
                      ),
                    ),
                  ),
                ),
              ),
            ],
            SizedBox(height: 14 * s),
            Text('A  jogar / obter     Y  Biblioteca     B  voltar     ↑ ↓  rolar',
                style: ts(context, 14, color: Colors.white38)),
          ]),
        ),
        Positioned(
          top: 16 * s,
          left: 24 * s,
          child: TextButton.icon(
            onPressed: xc.closeDetail,
            style: TextButton.styleFrom(foregroundColor: Colors.white, backgroundColor: Colors.black45),
            icon: Icon(Icons.arrow_back, size: 22 * s),
            label: Text('Voltar', style: TextStyle(fontSize: 18 * s)),
          ),
        ),
      ]),
    ),
  );
}
