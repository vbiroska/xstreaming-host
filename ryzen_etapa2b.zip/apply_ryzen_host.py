#!/usr/bin/env python3
"""Etapa 2a: põe o Ryzen (Flutter, via AAR) dentro do projeto XStreaming.
Rode na raiz do XStreaming. Env: RYZEN_APP (pasta do app Flutter), RYZEN_REPO (repo maven do AAR)."""
import os, re, pathlib, shutil
HERE = pathlib.Path(__file__).resolve().parent

ROOT = pathlib.Path.cwd()
APP = pathlib.Path(os.environ["RYZEN_APP"])
REPO = os.environ["RYZEN_REPO"]
A = ROOT / "android"
M = A / "app/src/main"

def edit(path, fn):
    s = path.read_text()
    n = fn(s)
    if n == s:
        print("AVISO: nada mudou em", path)
    path.write_text(n)

# 1) MainActivity do Ryzen (Kotlin) + ligação com o motor
dst = M / "kotlin/com/ryzen/ryzen"
dst.mkdir(parents=True, exist_ok=True)
src = (APP / "android_patch/MainActivity.kt").read_text()
if "RyzenEngine" not in src:
    src = src.replace("import io.flutter.plugin.common.MethodChannel",
                      "import io.flutter.plugin.common.MethodChannel\nimport com.xstreaming.RyzenEngine", 1)
    hook = '''
        // --- motor do XStreaming ---
        val eng = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/engine")
        RyzenEngine.start(application)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "ryzen/nano_view",
            com.xstreaming.RyzenStreamViewFactory(flutterEngine.dartExecutor.binaryMessenger))
        RyzenEngine.setEvents { name, json ->
            runOnUiThread { eng.invokeMethod("event", mapOf("name" to name, "json" to json)) }
        }
        eng.setMethodCallHandler { call, result ->
            if (call.method == "call") {
                RyzenEngine.call(call.argument<String>("cmd")!!, call.argument<String>("args")) { ok, json ->
                    runOnUiThread {
                        if (ok) result.success(json) else result.error("engine", json, null)
                    }
                }
            } else result.notImplemented()
        }
'''
    key = 'channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/native")'
    assert key in src, "ponto de ligação não achado no MainActivity.kt"
    src = src.replace(key, key + hook, 1)
(dst / "MainActivity.kt").write_text(src)

# 2) estilos usados pelo manifest do Ryzen
(M / "res/values/ryzen_styles.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="RyzenLaunchTheme" parent="@android:style/Theme.Black.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
    </style>
    <style name="RyzenNormalTheme" parent="@android:style/Theme.Black.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
    </style>
</resources>
''')

# 3) AndroidManifest
def manifest(s):
    if "com.ryzen.ryzen.MainActivity" in s:
        return s
    perms = {
      "android.permission.QUERY_ALL_PACKAGES": "",
      "android.permission.ACCESS_FINE_LOCATION": "",
      "android.permission.BLUETOOTH_SCAN": ' android:usesPermissionFlags="neverForLocation"',
    }
    extra = ""
    for p, attr in perms.items():
        if p not in s:
            extra += f'    <uses-permission android:name="{p}"{attr}/>\n'
    s = s.replace("    <application", extra + "\n    <application", 1)
    # XStreaming deixa de ser o ícone da tela inicial
    s = re.sub(r"\s*<intent-filter>(?:(?!</intent-filter>).)*LEANBACK_LAUNCHER(?:(?!</intent-filter>).)*</intent-filter>",
               "", s, count=1, flags=re.S)
    act = '''
      <meta-data android:name="flutterEmbedding" android:value="2" />
      <activity
        android:name="com.ryzen.ryzen.MainActivity"
        android:exported="true"
        android:launchMode="singleTask"
        android:theme="@style/RyzenLaunchTheme"
        android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
        android:hardwareAccelerated="true"
        android:windowSoftInputMode="adjustResize"
        android:screenOrientation="sensorLandscape">
        <meta-data android:name="io.flutter.embedding.android.NormalTheme" android:resource="@style/RyzenNormalTheme" />
        <intent-filter>
          <action android:name="android.intent.action.MAIN" />
          <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
        <intent-filter>
          <action android:name="android.intent.action.MAIN" />
          <category android:name="android.intent.category.HOME" />
          <category android:name="android.intent.category.DEFAULT" />
        </intent-filter>
      </activity>
'''
    s = s.replace("</application>", act + "    </application>", 1)
    s = s.replace("</manifest>", '''    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
        </intent>
    </queries>
</manifest>''', 1)
    return s
edit(M / "AndroidManifest.xml", manifest)

# 4) build.gradle da raiz: Kotlin + repositórios do Flutter/AAR
def root_gradle(s):
    if "kotlin-gradle-plugin" in s:
        return s
    # repositórios oficiais primeiro: o espelho da Aliyun às vezes não entrega o AGP no GitHub Actions
    s = s.replace("    repositories {\n", "    repositories {\n        google()\n        mavenCentral()\n", 1)
    s = s.replace("dependencies {", 'dependencies {\n        classpath("com.android.tools:r8:8.9.35")', 1)
    s = s.replace('classpath("com.facebook.react:react-native-gradle-plugin")',
                  'classpath("com.facebook.react:react-native-gradle-plugin")\n        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24")', 1)
    s += f'''
allprojects {{
    repositories {{
        maven {{ url "file://{REPO}" }}
        maven {{ url "https://storage.googleapis.com/download.flutter.io" }}
    }}
}}
'''
    return s
edit(A / "build.gradle", root_gradle)

# 5) build.gradle do app
def app_gradle(s):
    if "kotlin-android" in s:
        return s
    s = s.replace('apply plugin: "com.facebook.react"', 'apply plugin: "com.facebook.react"\napply plugin: "kotlin-android"', 1)
    s = s.replace('namespace "com.xstreaming"', '''namespace "com.xstreaming"
    kotlinOptions {
        jvmTarget = "1.8"
        freeCompilerArgs += ["-Xskip-metadata-version-check"]
    }
    packagingOptions {
        pickFirst "**/libc++_shared.so"
    }''', 1)
    s = s.replace('implementation("com.facebook.react:react-android")',
                  'implementation("com.facebook.react:react-android")\n    releaseImplementation "com.ryzen.ryzen:flutter_release:1.0"', 1)
    s += '''
// o Flutter novo exige AGP/compileSdk maiores do que o React Native 0.72 usa: desliga só a checagem.
tasks.configureEach { t ->
    if (t.name.startsWith("check") && t.name.endsWith("AarMetadata")) { t.enabled = false }
}
'''
    return s
edit(A / "app/build.gradle", app_gradle)

# 6) classes Java da etapa 2b
JAVA = M / "java/com/xstreaming"
for f in (HERE / "java").glob("*.java"):
    shutil.copy(f, JAVA / f.name)

# 7) RyzenEngine: expor o ReactContext
p = JAVA / "RyzenEngine.java"
t = p.read_text()
if "reactContext()" not in t:
    t = t.replace("    static void onReply", "    public static ReactContext reactContext() { return ctx; }\n\n    static void onReply", 1)
    assert "reactContext()" in t
    p.write_text(t)

# 8) NanoStreamView: enviar eventos para o Flutter quando houver um "sink"
p = JAVA / "nano/NanoStreamView.java"
t = p.read_text()
if "eventSink" not in t:
    t = t.replace("    private final ReactContext reactContext;",
        "    private final ReactContext reactContext;\n"
        "    public interface EventSink { void onEvent(String name, java.util.Map<String, Object> data); }\n"
        "    private EventSink eventSink;\n"
        "    public void setEventSink(EventSink s) { eventSink = s; }", 1)
    t, n = re.subn(r"if \(getId\(\) == -1\) \{", "if (getId() == -1 && eventSink == null) {", t)
    assert n == 2, n
    def sink(m):
        name = "state" if m.group(2) == "topNativeStateChange" else "rumble"
        return (m.group(1) + "if (eventSink != null) { eventSink.onEvent(\"" + name + "\", event.toHashMap()); return; }"
                + m.group(0))
    t, n = re.subn(r'(\n\s*)reactContext\s*\.getJSModule\(RCTEventEmitter\.class\)\s*\.receiveEvent\(getId\(\), "(topNativeStateChange|topNanoRumble)", event\);', sink, t)
    assert n == 2, n
    p.write_text(t)

# 9) gradle.properties: Java 11 x Kotlin 17
gp = A / "gradle.properties"
g = gp.read_text()
if "kotlin.jvm.target.validation.mode" not in g:
    gp.write_text(g.rstrip("\n") + "\nkotlin.jvm.target.validation.mode=warning\n")
# 10) comando "cleanup": encerra sessões antigas abertas no servidor (evita ProvisionedLaunchDeferred)
CLEANUP = """  // Encerra sessões antigas que ficaram abertas no servidor xCloud.
  async cleanup() {
    const t = cloudToken();
    const host = t.getDefaultRegion().baseUri;
    const probe: any = new XcloudApi(host, t.data.gsToken, 'cloud');
    const res: any = await probe.getActiveSessions();
    const list: any[] = Array.isArray(res) ? res : res?.results ?? [];
    let stopped = 0;
    for (const s of list) {
      if (!s?.sessionId) continue;
      const api: any = new XcloudApi(host, t.data.gsToken, 'cloud');
      api.sessionId = s.sessionId;
      try {
        await api.stopStream();
        stopped++;
      } catch (e) {}
    }
    return {found: list.length, stopped};
  },

"""
p = ROOT / "src/ryzen/RyzenEngine.ts"
t = p.read_text()
if "async cleanup()" not in t:
    marker = "  // Monta o streamInfo"
    assert marker in t, "marcador não achado no RyzenEngine.ts"
    p.write_text(t.replace(marker, CLEANUP + marker, 1))
# 11) controle: o MainActivity do Ryzen passa também o estado do gamepad ao stream Nano
mk = dst / "MainActivity.kt"
k = mk.read_text()
if "RyzenStreamView.pad" not in k:
    key = 'channel?.invokeMethod("pad", out)'
    assert key in k, "flushRunnable não encontrado no MainActivity.kt"
    k = k.replace(key, key + "\n        try { com.xstreaming.RyzenStreamView.pad(out) } catch (_: Throwable) {}", 1)
    mk.write_text(k)

# 12) Rust (nano-rs): o servidor do xCloud pode ficar em estados que o motor ignorava em silêncio
#     (fila de jogo grátis com anúncios, ProvisionedLaunchDeferred...) e o stream parecia "travado".
#     Agora cada mudança de estado vira status visível (sessionStage) e o app sabe quando é fila e quando é travamento.
rs = ROOT / "nano-rs/src/backend.rs"
t = rs.read_text()
if "last_state" not in t:
    old_call = "wait_for_provisioned_state(&signaling, &mut session, &mut stop_rx).await?;"
    assert old_call in t, "chamada de wait_for_provisioned_state não achada"
    t = t.replace(old_call, "wait_for_provisioned_state(&signaling, &mut session, &mut stop_rx, config.event_sink.as_ref()).await?;", 1)
    old_sig = "    stop_rx: &mut watch::Receiver<bool>,\n) -> Result<bool, NanoError> {\n    let mut connect_sent = false;\n"
    assert old_sig in t, "assinatura de wait_for_provisioned_state não achada"
    t = t.replace(old_sig,
        "    stop_rx: &mut watch::Receiver<bool>,\n    event_sink: Option<&Arc<dyn SessionEventSink + Send + Sync>>,\n) -> Result<bool, NanoError> {\n"
        "    let mut connect_sent = false;\n    let mut last_state = String::new();\n", 1)
    old_poll = "        crate::nano_log!(\"state poll state={}\", state.state);\n"
    assert old_poll in t, "log do state poll não achado"
    t = t.replace(old_poll, old_poll +
        "        if state.state != last_state {\n"
        "            last_state = state.state.clone();\n"
        "            let (stage, msg) = match state.state.as_str() {\n"
        "                \"WaitingForResources\" | \"Provisioning\" => (\"queue\", format!(\"Na fila do servidor ({})\", state.state)),\n"
        "                \"Provisioned\" | \"ReadyToConnect\" | \"Failed\" => (\"provision\", format!(\"Servidor: {}\", state.state)),\n"
        "                other => (\"server-state\", format!(\"Servidor: {other}\")),\n"
        "            };\n"
        "            emit_status(event_sink, stage, &msg, false);\n"
        "        }\n", 1)
    rs.write_text(t)
print("ok")
