package com.xstreaming;

import com.facebook.react.bridge.JavaOnlyArray;
import com.facebook.react.bridge.JavaOnlyMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

/** JSON -> ReadableMap/ReadableArray sem precisar do JS (para o NanoStreamView dentro do Flutter). */
final class JsonRn {
    private JsonRn() {}

    static JavaOnlyMap map(JSONObject o) throws JSONException {
        JavaOnlyMap m = new JavaOnlyMap();
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            Object v = o.get(k);
            if (v == null || v == JSONObject.NULL) m.putNull(k);
            else if (v instanceof Boolean) m.putBoolean(k, (Boolean) v);
            else if (v instanceof Integer) m.putInt(k, (Integer) v);
            else if (v instanceof Long) {
                long l = (Long) v;
                if (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) m.putInt(k, (int) l);
                else m.putDouble(k, (double) l);
            } else if (v instanceof Number) m.putDouble(k, ((Number) v).doubleValue());
            else if (v instanceof String) m.putString(k, (String) v);
            else if (v instanceof JSONObject) m.putMap(k, map((JSONObject) v));
            else if (v instanceof JSONArray) m.putArray(k, array((JSONArray) v));
            else m.putString(k, String.valueOf(v));
        }
        return m;
    }

    static JavaOnlyArray array(JSONArray a) throws JSONException {
        JavaOnlyArray r = new JavaOnlyArray();
        for (int i = 0; i < a.length(); i++) {
            Object v = a.get(i);
            if (v == null || v == JSONObject.NULL) r.pushNull();
            else if (v instanceof Boolean) r.pushBoolean((Boolean) v);
            else if (v instanceof Integer) r.pushInt((Integer) v);
            else if (v instanceof Long) {
                long l = (Long) v;
                if (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) r.pushInt((int) l);
                else r.pushDouble((double) l);
            } else if (v instanceof Number) r.pushDouble(((Number) v).doubleValue());
            else if (v instanceof String) r.pushString((String) v);
            else if (v instanceof JSONObject) r.pushMap(map((JSONObject) v));
            else if (v instanceof JSONArray) r.pushArray(array((JSONArray) v));
            else r.pushString(String.valueOf(v));
        }
        return r;
    }
}
