package com.xstreaming;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.JavaOnlyMap;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.ThemedReactContext;
import com.xstreaming.nano.NanoStreamView;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.platform.PlatformView;

/** Coloca o NanoStreamView (vídeo + Rust) dentro de uma tela Flutter. */
public class RyzenStreamView implements PlatformView, MethodChannel.MethodCallHandler {
    private static final String TAG = "RyzenStreamView";

    private final NanoStreamView view;
    private final MethodChannel channel;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Map<String, Object> lastState = new HashMap<>();

    // ---- controle: estado vindo do MainActivity do Ryzen (21 valores: 17 botões + 4 eixos) ----
    private static volatile RyzenStreamView active;
    private static final String[] PAD_KEYS = {
        "A", "B", "X", "Y", "LeftShoulder", "RightShoulder", "LeftTrigger", "RightTrigger",
        "View", "Menu", "LeftThumb", "RightThumb", "DPadUp", "DPadDown", "DPadLeft", "DPadRight",
        "Nexus", "LeftThumbXAxis", "LeftThumbYAxis", "RightThumbXAxis", "RightThumbYAxis"
    };
    private volatile double[] lastPad = new double[21];
    private boolean pumping = false;
    // o Xbox espera quadros de entrada continuamente (o XStreaming reenvia ~125x/s)
    private final Runnable pump = new Runnable() {
        @Override public void run() {
            if (!pumping) return;
            try { view.sendGamepadState(padMap(lastPad)); } catch (Throwable t) { Log.e(TAG, "pad", t); }
            main.postDelayed(this, 8);
        }
    };

    /** Chamado pelo MainActivity a cada mudança do controle. */
    public static void pad(double[] p) {
        RyzenStreamView v = active;
        if (v != null && p != null && p.length >= 21) v.lastPad = p.clone();
    }

    private static JavaOnlyMap padMap(double[] p) {
        JavaOnlyMap m = new JavaOnlyMap();
        m.putInt("GamepadIndex", 0);
        for (int i = 0; i < PAD_KEYS.length && i < p.length; i++) m.putDouble(PAD_KEYS[i], p[i]);
        return m;
    }

    private void startPump() {
        if (pumping) return;
        pumping = true;
        main.post(pump);
    }

    private void stopPump() {
        pumping = false;
        main.removeCallbacks(pump);
    }

    RyzenStreamView(Context context, BinaryMessenger messenger, int id, @Nullable String streamInfoJson) {
        ReactContext rc = RyzenEngine.reactContext();
        if (rc == null) throw new IllegalStateException("motor do XStreaming ainda não iniciou");

        if (!(rc instanceof ReactApplicationContext)) {
            throw new IllegalStateException("contexto React inesperado: " + rc.getClass().getName());
        }
        view = new NanoStreamView(new ThemedReactContext((ReactApplicationContext) rc, context));
        view.setShowStatus(false);

        channel = new MethodChannel(messenger, "ryzen/nano_view_" + id);
        channel.setMethodCallHandler(this);

        view.setEventSink((name, data) -> {
            if ("state".equals(name)) lastState = data;
            main.post(() -> channel.invokeMethod(name, data));
        });

        if (streamInfoJson != null) applyStreamInfo(streamInfoJson);
        active = this;
    }

    private void applyStreamInfo(String json) {
        try {
            view.setStreamInfo(JsonRn.map(new JSONObject(json)));
        } catch (Exception e) {
            Log.e(TAG, "streamInfo inválido", e);
        }
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        try {
            switch (call.method) {
                case "state":
                    result.success(lastState);
                    return;
                case "streamInfo":
                    applyStreamInfo(String.valueOf(call.arguments));
                    break;
                case "start":
                    view.startSession();
                    startPump();
                    break;
                case "stop":
                    stopPump();
                    view.stopSession();
                    break;
                case "focus":
                    view.requestNanoFocus();
                    break;
                case "statusText":
                    view.setStatusText(call.arguments == null ? "" : String.valueOf(call.arguments));
                    break;
                case "showStatus":
                    view.setShowStatus(Boolean.TRUE.equals(call.arguments));
                    break;
                case "gamepad":
                    view.sendGamepadState(JsonRn.map(new JSONObject((Map<?, ?>) call.arguments)));
                    break;
                default:
                    result.notImplemented();
                    return;
            }
            result.success(null);
        } catch (Exception e) {
            result.error("nano", String.valueOf(e), null);
        }
    }

    @Override
    public View getView() { return view; }

    @Override
    public void dispose() {
        stopPump();
        if (active == this) active = null;
        channel.setMethodCallHandler(null);
        try { view.stopSession(); } catch (Throwable ignored) {}
    }
}
