import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'engine.dart';
import 'i18n.dart';
import 'state.dart';
import 'ui.dart';

/// Amigos do Xbox (lista + presença), atualizados a cada 60 s enquanto o card está na tela.
class Friends extends ChangeNotifier {
  Friends._();
  static final i = Friends._();

  List<Map<String, dynamic>> list = [];
  bool loaded = false;
  String? error;
  Timer? _t;
  int _users = 0;

  int get onlineCount => list.where((f) => f['online'] == true).length;

  void attach() {
    if (_users++ == 0) {
      refresh();
      _t = Timer.periodic(const Duration(seconds: 60), (_) => refresh());
    }
  }

  void detach() {
    if (--_users <= 0) {
      _users = 0;
      _t?.cancel();
      _t = null;
    }
  }

  Future<void> refresh() async {
    try {
      final r = await Engine.friends();
      final l = (r is List ? r : const [])
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      // online primeiro, depois ordem alfabética
      l.sort((a, b) {
        final o = ((b['online'] == true) ? 1 : 0) - ((a['online'] == true) ? 1 : 0);
        if (o != 0) return o;
        return (a['name'] ?? '').toString().toLowerCase().compareTo((b['name'] ?? '').toString().toLowerCase());
      });
      list = l;
      error = null;
    } catch (e) {
      error = e.toString().replaceFirst('PlatformException', '').trim();
    }
    loaded = true;
    notifyListeners();
  }
}

/// Card "Ryzen Friends" da tela Início.
class FriendsCard extends StatefulWidget {
  const FriendsCard({super.key});

  @override
  State<FriendsCard> createState() => _FriendsCardState();
}

class _FriendsCardState extends State<FriendsCard> {
  static const _green = Color(0xFF2ECC71);
  static const _rowH = 59.0; // 5 linhas cabem inteiras no card (altura total 360)
  final f = Friends.i;

  @override
  void initState() {
    super.initState();
    f.addListener(_u);
    f.attach();
  }

  @override
  void dispose() {
    f.removeListener(_u);
    f.detach();
    super.dispose();
  }

  void _u() {
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final gt = await showGeneralDialog<String>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'fechar',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 180),
      pageBuilder: (c, _, __) => const _AddFriendDialog(),
      transitionBuilder: (c, a, _, child) => FadeTransition(
        opacity: a,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.96, end: 1).animate(CurvedAnimation(parent: a, curve: Curves.easeOut)),
          child: child,
        ),
      ),
    );
    if (gt == null || gt.isEmpty || !mounted) return;
    final msg = ScaffoldMessenger.maybeOf(context);
    try {
      await Engine.addFriend(gt);
      msg?.showSnackBar(SnackBar(content: Text('${tr('Pedido enviado para')} $gt')));
      f.refresh();
    } catch (e) {
      msg?.showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('PlatformException', '').trim())));
    }
  }

  Widget _avatar(BuildContext context, Map<String, dynamic> p, double size) {
    final s = context.s;
    final name = (p['name'] ?? '?').toString();
    final pic = (p['pic'] ?? '').toString();
    final fallback = Container(
      width: size * s,
      height: size * s,
      alignment: Alignment.center,
      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF4A63D6)),
      child: Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: ts(context, size * 0.45, color: Colors.white, bold: true)),
    );
    if (pic.isEmpty) return fallback;
    return ClipOval(
      child: Image.network(pic,
          width: size * s, height: size * s, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
    );
  }

  Widget _row(BuildContext context, Map<String, dynamic> p) {
    final s = context.s;
    final on = p['online'] == true;
    var text = (p['text'] ?? '').toString();
    if (!on) {
      text = '';
    } else if (text.isEmpty || text.toLowerCase() == 'online') {
      text = tr('Disponível');
    }
    return SizedBox(
      height: _rowH * s,
      child: Row(children: [
        SizedBox(width: 20 * s),
        _avatar(context, p, 42),
        SizedBox(width: 16 * s),
        Expanded(
          flex: 5,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text((p['name'] ?? '').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 22, bold: true)),
            SizedBox(height: 1 * s),
            Row(children: [
              Container(
                  width: 10 * s,
                  height: 10 * s,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: on ? _green : st.subTxt)),
              SizedBox(width: 6 * s),
              Text(on ? 'Online' : 'Offline', style: ts(context, 15, color: on ? _green : st.subTxt)),
            ]),
          ]),
        ),
        Expanded(
          flex: 5,
          child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: ts(context, 19, color: st.subTxt)),
        ),
        SizedBox(width: 20 * s),
      ]),
    );
  }

  Widget _body(BuildContext context) {
    final s = context.s;
    Widget msg(String t, {VoidCallback? onTap}) => GestureDetector(
          onTap: onTap,
          behavior: HitTestBehavior.opaque,
          child: Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 30 * s),
              child: Text(t, textAlign: TextAlign.center, style: ts(context, 20, color: st.subTxt)),
            ),
          ),
        );
    if (!f.loaded) return msg(tr('Carregando...'));
    if (f.error != null && f.list.isEmpty) return msg('${tr('Não foi possível carregar os amigos.')}\n${tr('Toque para tentar de novo')}', onTap: f.refresh);
    if (f.list.isEmpty) return msg(tr('Nenhum amigo ainda. Toque em + para adicionar.'));
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemExtent: _rowH * s,
      itemCount: f.list.length,
      itemBuilder: (c, i) => _row(c, f.list[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Glass(
      radius: 22 * s,
      border: st.accent.withOpacity(0.8),
      borderWidth: 2,
      child: Column(children: [
        SizedBox(
          height: 64 * s,
          child: Row(children: [
            SizedBox(width: 22 * s),
            SysIcon('user', 38),
            SizedBox(width: 14 * s),
            Text('RYZEN FRIENDS', style: ts(context, 24, bold: true)),
            SizedBox(width: 16 * s),
            Container(width: 12 * s, height: 12 * s, decoration: const BoxDecoration(shape: BoxShape.circle, color: _green)),
            SizedBox(width: 7 * s),
            Text('${f.onlineCount} online', style: ts(context, 19, color: _green)),
            const Spacer(),
            GestureDetector(
              onTap: _add,
              behavior: HitTestBehavior.opaque,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 22 * s, vertical: 10 * s),
                child: Icon(Icons.person_add_alt_1, size: 34 * s, color: st.txt),
              ),
            ),
          ]),
        ),
        Container(height: 1, color: st.tileEdge),
        Expanded(child: _body(context)),
      ]),
    );
  }
}

/// Janela "Adicionar amigo" (fundo desfocado, campo de gamertag e botões Cancelar/Adicionar).
class _AddFriendDialog extends StatefulWidget {
  const _AddFriendDialog();

  @override
  State<_AddFriendDialog> createState() => _AddFriendDialogState();
}

class _AddFriendDialogState extends State<_AddFriendDialog> {
  static const _violet = Color(0xFF6C5CE7);
  final _ctl = TextEditingController();

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _ok() => Navigator.pop(context, _ctl.text.trim());
  void _close() => Navigator.pop(context);

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Material(
      type: MaterialType.transparency,
      child: Stack(children: [
        // fundo desfocado e escurecido; tocar fora fecha
        Positioned.fill(
          child: GestureDetector(
            onTap: _close,
            behavior: HitTestBehavior.opaque,
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 9, sigmaY: 9),
              child: Container(color: const Color(0x8C05060F)),
            ),
          ),
        ),
        Center(
          child: GestureDetector(
            onTap: () {},
            child: Container(
              width: 783 * s,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40 * s),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1D1B3A), Color(0xFF14142B)],
                ),
                border: Border.all(color: _violet, width: 2),
                boxShadow: [BoxShadow(color: _violet.withOpacity(0.35), blurRadius: 40 * s)],
              ),
              child: Stack(children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(39 * s, 42 * s, 39 * s, 31 * s),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Row(children: [
                      SizedBox(width: 16 * s),
                      Container(
                        width: 96 * s,
                        height: 96 * s,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(26 * s),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFF4B43B8), Color(0xFF2E2A6E)],
                          ),
                          border: Border.all(color: _violet.withOpacity(0.7), width: 1.5),
                        ),
                        child: Icon(Icons.person_add_alt_1, size: 52 * s, color: const Color(0xFFE6E2FF)),
                      ),
                      SizedBox(width: 30 * s),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(right: 70 * s),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(tr('Adicionar amigo'), style: ts(context, 36, bold: true)),
                            SizedBox(height: 8 * s),
                            Text(tr('Digite o nome de usuário da pessoa que deseja adicionar.'),
                                style: ts(context, 20, color: st.subTxt)),
                          ]),
                        ),
                      ),
                    ]),
                    SizedBox(height: 59 * s),
                    Container(
                      height: 85 * s,
                      padding: EdgeInsets.symmetric(horizontal: 30 * s),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A1B33),
                        borderRadius: BorderRadius.circular(43 * s),
                        border: Border.all(color: _violet.withOpacity(0.85), width: 2),
                      ),
                      child: Row(children: [
                        Icon(Icons.search, size: 38 * s, color: const Color(0xFFD8D4F5)),
                        SizedBox(width: 20 * s),
                        Expanded(
                          child: TextField(
                            controller: _ctl,
                            autofocus: true,
                            textInputAction: TextInputAction.done,
                            onSubmitted: (_) => _ok(),
                            cursorColor: _violet,
                            style: ts(context, 26),
                            decoration: InputDecoration(
                              isCollapsed: true,
                              border: InputBorder.none,
                              hintText: tr('Gamertag do Xbox'),
                              hintStyle: ts(context, 26, color: st.subTxt),
                            ),
                          ),
                        ),
                      ]),
                    ),
                    SizedBox(height: 42 * s),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      GestureDetector(
                        onTap: _close,
                        child: Container(
                          width: 288 * s,
                          height: 74 * s,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(color: const Color(0xFF24253F), borderRadius: BorderRadius.circular(37 * s)),
                          child: Text(tr('Cancelar'), style: ts(context, 25, bold: true)),
                        ),
                      ),
                      SizedBox(width: 24 * s),
                      GestureDetector(
                        onTap: _ok,
                        child: Container(
                          width: 322 * s,
                          height: 74 * s,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(37 * s),
                            gradient: const LinearGradient(colors: [Color(0xFF4F46E5), Color(0xFF7C6BF0)]),
                            boxShadow: [BoxShadow(color: _violet.withOpacity(0.45), blurRadius: 22 * s)],
                          ),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.person_add_alt_1, size: 32 * s, color: Colors.white),
                            SizedBox(width: 12 * s),
                            Text(tr('Adicionar'), style: ts(context, 25, bold: true, color: Colors.white)),
                          ]),
                        ),
                      ),
                    ]),
                  ]),
                ),
                // botão X
                Positioned(
                  top: 21 * s,
                  right: 21 * s,
                  child: GestureDetector(
                    onTap: _close,
                    child: Container(
                      width: 64 * s,
                      height: 64 * s,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF2A2B45)),
                      child: Icon(Icons.close, size: 34 * s, color: Colors.white),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}
