import 'dart:async';

import 'package:flutter/material.dart';

import 'engine.dart';
import 'i18n.dart';
import 'state.dart';
import 'ui.dart';

/// Amigos do Xbox (lista + presença), atualizados a cada 60 s enquanto o card está na tela.
class Friends extends ChangeNotifier {
  Friends._();
  static final i = Friends._();

  List<Map<String, dynamic>> list = [];
  bool loaded = false;
  String? error;
  Timer? _t;
  int _users = 0;

  int get onlineCount => list.where((f) => f['online'] == true).length;

  void attach() {
    if (_users++ == 0) {
      refresh();
      _t = Timer.periodic(const Duration(seconds: 60), (_) => refresh());
    }
  }

  void detach() {
    if (--_users <= 0) {
      _users = 0;
      _t?.cancel();
      _t = null;
    }
  }

  Future<void> refresh() async {
    try {
      final r = await Engine.friends();
      final l = (r is List ? r : const [])
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      // online primeiro, depois ordem alfabética
      l.sort((a, b) {
        final o = ((b['online'] == true) ? 1 : 0) - ((a['online'] == true) ? 1 : 0);
        if (o != 0) return o;
        return (a['name'] ?? '').toString().toLowerCase().compareTo((b['name'] ?? '').toString().toLowerCase());
      });
      list = l;
      error = null;
    } catch (e) {
      error = e.toString().replaceFirst('PlatformException', '').trim();
    }
    loaded = true;
    notifyListeners();
  }
}

/// Card "Ryzen Friends" da tela Início.
class FriendsCard extends StatefulWidget {
  const FriendsCard({super.key});

  @override
  State<FriendsCard> createState() => _FriendsCardState();
}

class _FriendsCardState extends State<FriendsCard> {
  static const _green = Color(0xFF2ECC71);
  final f = Friends.i;

  @override
  void initState() {
    super.initState();
    f.addListener(_u);
    f.attach();
  }

  @override
  void dispose() {
    f.removeListener(_u);
    f.detach();
    super.dispose();
  }

  void _u() {
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final ctl = TextEditingController();
    final gt = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Adicionar amigo')),
        content: TextField(
          controller: ctl,
          autofocus: true,
          decoration: InputDecoration(hintText: tr('Gamertag do Xbox')),
          onSubmitted: (v) => Navigator.pop(c, v.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(tr('Cancelar'))),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: Text(tr('Adicionar'))),
        ],
      ),
    );
    if (gt == null || gt.isEmpty || !mounted) return;
    final msg = ScaffoldMessenger.maybeOf(context);
    try {
      await Engine.addFriend(gt);
      msg?.showSnackBar(SnackBar(content: Text('${tr('Pedido enviado para')} $gt')));
      f.refresh();
    } catch (e) {
      msg?.showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('PlatformException', '').trim())));
    }
  }

  Widget _avatar(BuildContext context, Map<String, dynamic> p, double size) {
    final s = context.s;
    final name = (p['name'] ?? '?').toString();
    final pic = (p['pic'] ?? '').toString();
    final fallback = Container(
      width: size * s,
      height: size * s,
      alignment: Alignment.center,
      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF4A63D6)),
      child: Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: ts(context, size * 0.45, color: Colors.white, bold: true)),
    );
    if (pic.isEmpty) return fallback;
    return ClipOval(
      child: Image.network(pic,
          width: size * s, height: size * s, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
    );
  }

  Widget _row(BuildContext context, Map<String, dynamic> p) {
    final s = context.s;
    final on = p['online'] == true;
    var text = (p['text'] ?? '').toString();
    if (!on) {
      text = '';
    } else if (text.isEmpty || text.toLowerCase() == 'online') {
      text = tr('Disponível');
    }
    return SizedBox(
      height: 62 * s,
      child: Row(children: [
        SizedBox(width: 22 * s),
        _avatar(context, p, 44),
        SizedBox(width: 16 * s),
        Expanded(
          flex: 5,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text((p['name'] ?? '').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 23, bold: true)),
            SizedBox(height: 2 * s),
            Row(children: [
              Container(
                  width: 10 * s,
                  height: 10 * s,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: on ? _green : st.subTxt)),
              SizedBox(width: 6 * s),
              Text(on ? 'Online' : 'Offline', style: ts(context, 16, color: on ? _green : st.subTxt)),
            ]),
          ]),
        ),
        Expanded(
          flex: 5,
          child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: ts(context, 20, color: st.subTxt)),
        ),
        SizedBox(width: 22 * s),
      ]),
    );
  }

  Widget _body(BuildContext context) {
    final s = context.s;
    Widget msg(String t, {VoidCallback? onTap}) => GestureDetector(
          onTap: onTap,
          behavior: HitTestBehavior.opaque,
          child: Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 30 * s),
              child: Text(t, textAlign: TextAlign.center, style: ts(context, 20, color: st.subTxt)),
            ),
          ),
        );
    if (!f.loaded) return msg(tr('Carregando...'));
    if (f.error != null && f.list.isEmpty) return msg('${tr('Não foi possível carregar os amigos.')}\n${tr('Toque para tentar de novo')}', onTap: f.refresh);
    if (f.list.isEmpty) return msg(tr('Nenhum amigo ainda. Toque em + para adicionar.'));
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemExtent: 62 * s,
      itemCount: f.list.length,
      itemBuilder: (c, i) => _row(c, f.list[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Glass(
      radius: 22 * s,
      border: st.accent.withOpacity(0.8),
      borderWidth: 2,
      child: Column(children: [
        SizedBox(
          height: 76 * s,
          child: Row(children: [
            SizedBox(width: 24 * s),
            SysIcon('user', 42),
            SizedBox(width: 16 * s),
            Text('RYZEN FRIENDS', style: ts(context, 27, bold: true)),
            SizedBox(width: 20 * s),
            Container(width: 14 * s, height: 14 * s, decoration: const BoxDecoration(shape: BoxShape.circle, color: _green)),
            SizedBox(width: 8 * s),
            Text('${f.onlineCount} online', style: ts(context, 21, color: _green)),
            const Spacer(),
            GestureDetector(
              onTap: _add,
              behavior: HitTestBehavior.opaque,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 24 * s, vertical: 12 * s),
                child: Icon(Icons.person_add_alt_1, size: 36 * s, color: st.txt),
              ),
            ),
          ]),
        ),
        Container(height: 1, color: st.tileEdge),
        Expanded(child: _body(context)),
      ]),
    );
  }
}
