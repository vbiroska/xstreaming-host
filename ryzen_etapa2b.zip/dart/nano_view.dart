import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

const _viewType = 'ryzen/nano_view';

/// Controle de um NanoStreamView nativo (um canal por vista).
class NanoController {
  NanoController(int id) : _ch = MethodChannel('ryzen/nano_view_$id') {
    _ch.setMethodCallHandler((c) async {
      if (c.arguments is! Map) return;
      final m = Map<String, dynamic>.from(c.arguments as Map);
      if (c.method == 'state') {
        state.value = m;
      } else if (c.method == 'rumble') {
        if (!_rumble.isClosed) _rumble.add(m);
      }
    });
    // eventos que chegaram antes do canal existir no Dart
    _ch.invokeMethod('state').then((v) {
      if (v is Map && state.value.isEmpty) state.value = Map<String, dynamic>.from(v);
    }).catchError((_) {});
  }

  final MethodChannel _ch;
  final ValueNotifier<Map<String, dynamic>> state = ValueNotifier({});
  final _rumble = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get rumble => _rumble.stream;

  Future<void> start() => _ch.invokeMethod('start');
  Future<void> stop() => _ch.invokeMethod('stop');
  Future<void> focus() => _ch.invokeMethod('focus');
  Future<void> showStatus(bool v) => _ch.invokeMethod('showStatus', v);
  Future<void> gamepad(Map<String, dynamic> s) => _ch.invokeMethod('gamepad', s);

  void dispose() {
    _ch.setMethodCallHandler(null);
    _rumble.close();
    state.dispose();
  }
}

/// Vídeo do stream (Hybrid Composition, porque o Nano usa SurfaceView).
class NanoStreamWidget extends StatelessWidget {
  const NanoStreamWidget({super.key, required this.streamInfo, required this.onCreated});

  final Map<dynamic, dynamic> streamInfo;
  final void Function(NanoController) onCreated;

  @override
  Widget build(BuildContext context) {
    final params = jsonEncode(streamInfo);
    return PlatformViewLink(
      viewType: _viewType,
      surfaceFactory: (context, controller) => AndroidViewSurface(
        controller: controller as AndroidViewController,
        gestureRecognizers: const <Factory<OneSequenceGestureRecognizer>>{},
        hitTestBehavior: PlatformViewHitTestBehavior.transparent,
      ),
      onCreatePlatformView: (p) {
        return PlatformViewsService.initExpensiveAndroidView(
          id: p.id,
          viewType: _viewType,
          layoutDirection: TextDirection.ltr,
          creationParams: params,
          creationParamsCodec: const StandardMessageCodec(),
          onFocus: () => p.onFocusChanged(true),
        )
          ..addOnPlatformViewCreatedListener((id) {
            p.onPlatformViewCreated(id);
            onCreated(NanoController(id));
          })
          ..create();
      },
    );
  }
}
