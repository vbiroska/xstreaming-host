import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'nano_view.dart';

/// Tela de stream do Ryzen: vídeo nativo + loading e estatísticas em Flutter.
class StreamScreen extends StatefulWidget {
  const StreamScreen({super.key, required this.streamInfo, this.title = ''});
  final Map<dynamic, dynamic> streamInfo;
  final String title;

  @override
  State<StreamScreen> createState() => _StreamScreenState();
}

class _StreamScreenState extends State<StreamScreen> {
  NanoController? c;
  bool started = false;
  bool closing = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  void _onCreated(NanoController ctrl) {
    c = ctrl;
    ctrl.state.addListener(_maybeStart);
    setState(() {});
    _maybeStart();
  }

  // começa a sessão quando a superfície de vídeo estiver pronta
  void _maybeStart() {
    final s = c?.state.value ?? const {};
    if (!started && s['surfaceReady'] == true) {
      started = true;
      c!.start();
      c!.focus();
    }
  }

  Future<void> _close() async {
    if (closing) return;
    closing = true;
    try {
      await c?.stop();
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    c?.dispose();
    super.dispose();
  }

  String _fmt(dynamic v, [int d = 0]) => v is num ? v.toStringAsFixed(d) : '-';

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _close();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(fit: StackFit.expand, children: [
          NanoStreamWidget(streamInfo: widget.streamInfo, onCreated: _onCreated),
          if (c != null)
            ValueListenableBuilder<Map<String, dynamic>>(
              valueListenable: c!.state,
              builder: (_, s, __) {
                final playing = ((s['renderedVideoFrames'] ?? 0) as num) > 0;
                final error = s['terminalSessionError'] == true;
                final status = (s['sessionStatusText'] ?? '').toString();
                final stage = (s['sessionStage'] ?? '').toString();
                return Stack(fit: StackFit.expand, children: [
                  if (!playing)
                    Container(
                      color: const Color(0xFF101418),
                      alignment: Alignment.center,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        if (!error) const CircularProgressIndicator(),
                        const SizedBox(height: 20),
                        Text(widget.title.isEmpty ? 'Carregando jogo' : widget.title,
                            style: const TextStyle(color: Colors.white, fontSize: 22)),
                        const SizedBox(height: 8),
                        Text(error ? 'Erro: $status' : (status.isEmpty ? stage : status),
                            style: TextStyle(color: error ? Colors.redAccent : Colors.white70)),
                        if (error)
                          Padding(
                            padding: const EdgeInsets.only(top: 16),
                            child: FilledButton(onPressed: _close, child: const Text('Voltar')),
                          ),
                      ]),
                    ),
                  if (playing)
                    Positioned(
                      left: 12,
                      top: 8,
                      child: Text(
                        '${_fmt(s['videoWidth'])}x${_fmt(s['videoHeight'])}  '
                        '${_fmt(s['webRtcFps'])} fps  ${_fmt(s['webRtcRttMs'])} ms  '
                        '${_fmt(s['webRtcBitrateMbps'], 1)} Mbps  '
                        '${_fmt(s['renderedVideoFrames'])} quadros',
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ),
                ]);
              },
            ),
          Positioned(
            right: 8,
            top: 8,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white70),
              onPressed: _close,
            ),
          ),
        ]),
      ),
    );
  }
}
