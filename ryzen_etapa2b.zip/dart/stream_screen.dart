import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'nano_view.dart';
import 'native.dart';

/// Tela de stream do Ryzen: vídeo nativo + loading, estatísticas, menu e controle em Flutter.
class StreamScreen extends StatefulWidget {
  const StreamScreen({super.key, required this.streamInfo, this.title = ''});
  final Map<dynamic, dynamic> streamInfo;
  final String title;

  @override
  State<StreamScreen> createState() => _StreamScreenState();
}

class _StreamScreenState extends State<StreamScreen> {
  NanoController? c;
  StreamSubscription<Map<String, dynamic>>? _rumbleSub;
  bool started = false;
  bool closing = false;
  bool menuOpen = false;
  bool showStats = true;
  int menuIndex = 0;
  void Function()? _prevMenu, _prevBack;
  void Function(String)? _prevKey;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    // o MainActivity passa a capturar o controle e encaminha ao stream
    _prevMenu = Native.onGameMenu;
    _prevBack = Native.onGameBack;
    _prevKey = Native.onMenuKey;
    Native.setGameMode(true);
    Native.onGameMenu = _openMenu; // botão Guia ou SELECT+START
    Native.onGameBack = _openMenu; // tecla Voltar
  }

  void _onCreated(NanoController ctrl) {
    c = ctrl;
    ctrl.state.addListener(_maybeStart);
    _rumbleSub = ctrl.rumble.listen(_onRumble);
    setState(() {});
    _maybeStart();
  }

  // começa a sessão quando a superfície de vídeo estiver pronta
  void _maybeStart() {
    final s = c?.state.value ?? const {};
    if (!started && s['surfaceReady'] == true) {
      started = true;
      c!.start();
      c!.focus();
    }
  }

  // vibração pedida pelo jogo -> controle
  void _onRumble(Map<String, dynamic> m) {
    final dur = (m['duration'] as num?)?.toInt() ?? 0;
    var mag = math.max((m['weakMagnitude'] as num?)?.toDouble() ?? 0,
        (m['strongMagnitude'] as num?)?.toDouble() ?? 0);
    if (mag > 1) mag /= 100;
    final amp = (mag * 255).round().clamp(0, 255);
    if (dur <= 0 || amp <= 0) {
      Native.rumble(0, 0);
    } else {
      Native.rumble(dur.clamp(1, 2000), amp);
    }
  }

  // ---------- menu ----------
  List<String> get _items =>
      ['Continuar', showStats ? 'Ocultar estatísticas' : 'Mostrar estatísticas', 'Sair do jogo'];

  void _openMenu() {
    if (menuOpen || closing || !mounted) return;
    setState(() {
      menuOpen = true;
      menuIndex = 0;
    });
    Native.setMenuMode(true);
    Native.onMenuKey = _menuKey;
  }

  void _closeMenu() {
    Native.setMenuMode(false);
    Native.onMenuKey = _prevKey;
    if (mounted) setState(() => menuOpen = false);
  }

  void _menuKey(String k) {
    if (!menuOpen) return;
    switch (k) {
      case 'up':
        setState(() => menuIndex = (menuIndex - 1 + _items.length) % _items.length);
        break;
      case 'down':
        setState(() => menuIndex = (menuIndex + 1) % _items.length);
        break;
      case 'accept':
        _runItem(menuIndex);
        break;
      case 'cancel':
        _closeMenu();
        break;
    }
  }

  void _runItem(int i) {
    if (i == 0) {
      _closeMenu();
    } else if (i == 1) {
      setState(() => showStats = !showStats);
    } else {
      _close();
    }
  }

  Future<void> _close() async {
    if (closing) return;
    closing = true;
    Native.setMenuMode(false);
    try {
      await c?.stop();
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _rumbleSub?.cancel();
    Native.rumble(0, 0);
    Native.setMenuMode(false);
    Native.setGameMode(false);
    Native.onGameMenu = _prevMenu;
    Native.onGameBack = _prevBack;
    Native.onMenuKey = _prevKey;
    c?.dispose();
    super.dispose();
  }

  String _fmt(dynamic v, [int d = 0]) => v is num ? v.toStringAsFixed(d) : '-';

  Widget _menu() {
    return Positioned.fill(
      child: Container(
        color: Colors.black54,
        alignment: Alignment.center,
        child: Container(
          width: 320,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F26),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < _items.length; i++)
              InkWell(
                onTap: () => _runItem(i),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  color: i == menuIndex ? const Color(0xFF3B2F63) : Colors.transparent,
                  child: Text(_items[i],
                      style: TextStyle(
                          color: i == 2 ? Colors.redAccent : Colors.white, fontSize: 17)),
                ),
              ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _openMenu();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(fit: StackFit.expand, children: [
          NanoStreamWidget(streamInfo: widget.streamInfo, onCreated: _onCreated),
          if (c != null)
            ValueListenableBuilder<Map<String, dynamic>>(
              valueListenable: c!.state,
              builder: (_, s, __) {
                final playing = ((s['renderedVideoFrames'] ?? 0) as num) > 0;
                final error = s['terminalSessionError'] == true;
                final status = (s['sessionStatusText'] ?? '').toString();
                final stage = (s['sessionStage'] ?? '').toString();
                return Stack(fit: StackFit.expand, children: [
                  if (!playing)
                    Container(
                      color: const Color(0xFF101418),
                      alignment: Alignment.center,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        if (!error) const CircularProgressIndicator(),
                        const SizedBox(height: 20),
                        Text(widget.title.isEmpty ? 'Carregando jogo' : widget.title,
                            style: const TextStyle(color: Colors.white, fontSize: 22)),
                        const SizedBox(height: 8),
                        Text(error ? 'Erro: $status' : (status.isEmpty ? stage : status),
                            style: TextStyle(color: error ? Colors.redAccent : Colors.white70)),
                        if (error)
                          Padding(
                            padding: const EdgeInsets.only(top: 16),
                            child: FilledButton(onPressed: _close, child: const Text('Voltar')),
                          ),
                      ]),
                    ),
                  if (playing && showStats)
                    Positioned(
                      left: 12,
                      top: 8,
                      child: Text(
                        '${_fmt(s['videoWidth'])}x${_fmt(s['videoHeight'])}  '
                        '${_fmt(s['webRtcFps'])} fps  ${_fmt(s['webRtcRttMs'])} ms  '
                        '${_fmt(s['webRtcBitrateMbps'], 1)} Mbps  '
                        '${_fmt(s['renderedVideoFrames'])} quadros',
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ),
                ]);
              },
            ),
          Positioned(
            right: 8,
            top: 8,
            child: IconButton(
              icon: const Icon(Icons.menu, color: Colors.white70),
              onPressed: _openMenu,
            ),
          ),
          if (menuOpen) _menu(),
        ]),
      ),
    );
  }
}
