import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';
import 'game.dart' show LoadingSplash;

/// Abre jogos do xCloud pelo motor do XStreaming (em vez do navegador).
class EnginePlay {
  static final navKey = GlobalKey<NavigatorState>();
  static final _re = RegExp(r'play\.xbox\.com/stream/([A-Za-z0-9]+)', caseSensitive: false);


  /// Ajustes de stream por jogo (productId -> ajustes só dele).
  /// Fortnite (BT5P2X999VH2): resolution 1080 faz o servidor tratar o cliente como PC (osName 'windows'),
  /// em vez de celular (720p = 'android').
  static const profiles = <String, Map<String, dynamic>>{
    'BT5P2X999VH2': {'resolution': 1080},
  };

  /// productId (ex.: BT5P2X999VH2) de um link da Loja, ou null se não for de jogo xCloud.
  static String? productId(String link) => _re.firstMatch(link)?.group(1)?.toUpperCase();

  /// Abre o jogo pelo motor. false = link que o motor não trata (segue o caminho antigo).
  static bool play(String link, String title,
      {ImageProvider? cover,
      ImageProvider? banner,
      required void Function(Map info) onReady}) {
    final pid = productId(link);
    final nav = navKey.currentState;
    if (pid == null || nav == null) return false;
    nav.push(MaterialPageRoute(
      builder: (_) => _PreparePage(
        pid: pid,
        title: title,
        cover: cover,
        banner: banner,
        onReady: onReady,
      ),
    ));
    return true;
  }

  // cache: productId -> {titleId, playable}
  static Map<String, Map<String, dynamic>>? _titles;

  static Future<Map<String, Map<String, dynamic>>> titles({bool refresh = false}) async {
    if (_titles != null && !refresh) return _titles!;
    final t = await Engine.titles();
    final res = (t is Map ? t['results'] : null) as List? ?? [];
    final out = <String, Map<String, dynamic>>{};
    for (final e in res) {
      if (e is! Map) continue;
      final d = e['details'] is Map ? e['details'] as Map : const {};
      final pid = (d['productId'] ?? '').toString().toUpperCase();
      final id = (e['titleId'] ?? e['XCloudTitleId'] ?? '').toString();
      if (pid.isEmpty || id.isEmpty) continue;
      out[pid] = {
        'titleId': id,
        'playable': d['hasEntitlement'] == true || d['isFreeInStore'] == true,
      };
    }
    return _titles = out;
  }
}

/// Tela de "carregando" do Ryzen: login (se preciso), escolha do título e preparo da sessão.
class _PreparePage extends StatefulWidget {
  const _PreparePage(
      {required this.pid,
      required this.title,
      this.cover,
      this.banner,
      required this.onReady});
  final String pid;
  final String title;
  final ImageProvider? cover, banner;
  final void Function(Map info) onReady;

  @override
  State<_PreparePage> createState() => _PreparePageState();
}

class _PreparePageState extends State<_PreparePage> {
  String status = 'Iniciando...';
  String? error;
  WebViewController? web;
  bool gone = false;
  final _clock = Stopwatch()..start();
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    // cronômetro da tela de carregamento (a mesma do Ryzen); os textos de etapa ficam ocultos
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && !gone) setState(() {});
    });
    Engine.init();
    _run();
  }

  @override
  void dispose() {
    gone = true;
    _tick?.cancel();
    super.dispose();
  }

  void _say(String s) {
    if (mounted && !gone) setState(() => status = s);
  }

  void _fail(Object e) {
    if (mounted && !gone) setState(() => error = e.toString().replaceFirst('PlatformException', '').trim());
  }

  Future<void> _run() async {
    try {
      setState(() => error = null);
      _say('Conectando ao Xbox...');
      final ok = await Engine.initSession();
      if (!ok) {
        await _startLogin();
        return; // continua em _afterLogin
      }
      await _go();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _startLogin() async {
    _say('É preciso entrar na conta Microsoft.');
    final r = await Engine.loginStart();
    final scheme = r['scheme'] as String;
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36')
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          if (req.url.startsWith(scheme)) {
            _afterLogin(req.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(r['authUrl'] as String));
    if (mounted) setState(() => web = c);
  }

  Future<void> _afterLogin(String url) async {
    if (mounted) setState(() => web = null);
    try {
      _say('Concluindo o login...');
      await Engine.loginFinish(url);
      await _go();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _go() async {
    _say('Procurando o jogo na sua conta...');
    var map = await EnginePlay.titles();
    var item = map[widget.pid];
    if (item == null) {
      map = await EnginePlay.titles(refresh: true);
      item = map[widget.pid];
    }
    if (item == null) {
      _fail('Este jogo não está disponível no xCloud para a sua conta.');
      return;
    }
    if (item['playable'] != true) {
      _fail('Sua conta não tem direito de jogar este título (precisa do Game Pass ou ter o jogo).');
      return;
    }
    _say('Liberando sessões antigas...');
    try {
      await Engine.cleanup();
    } catch (_) {}
    _say('Preparando o stream...');
    final info = await Engine.prepareStream(item['titleId'] as String, EnginePlay.profiles[widget.pid]);
    if (!mounted || gone) return;
    // volta ao Ryzen, que mostra o stream como um jogo (com o painel rápido por cima)
    Navigator.of(context).pop();
    widget.onReady(info);
  }

  @override
  Widget build(BuildContext context) {
    if (web != null) {
      return Scaffold(
        body: SafeArea(child: WebViewWidget(controller: web!)),
        floatingActionButton: FloatingActionButton.small(
          onPressed: () => Navigator.of(context).pop(),
          child: const Icon(Icons.close),
        ),
      );
    }
    if (error == null) {
      // carregando: só a tela de carregamento do Ryzen (banner, capa e barra), sem textos de etapa
      return LoadingSplash(
        title: widget.title,
        cover: widget.cover,
        banner: widget.banner,
        secs: _clock.elapsed.inSeconds,
        onBack: () => Navigator.of(context).pop(),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 20),
          Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 22)),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(error ?? status,
                textAlign: TextAlign.center,
                style: TextStyle(color: error == null ? Colors.white70 : Colors.redAccent)),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Wrap(spacing: 12, children: [
                FilledButton(onPressed: _run, child: const Text('Tentar de novo')),
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Voltar')),
              ]),
            ),
        ]),
      ),
    );
  }
}
