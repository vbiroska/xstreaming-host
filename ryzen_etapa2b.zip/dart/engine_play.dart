import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';
import 'stream_screen.dart';

/// Abre jogos do xCloud pelo motor do XStreaming (em vez do navegador).
class EnginePlay {
  static final navKey = GlobalKey<NavigatorState>();
  static final _re = RegExp(r'play\.xbox\.com/stream/([A-Za-z0-9]+)', caseSensitive: false);

  /// productId (ex.: BT5P2X999VH2) de um link da Loja, ou null se não for de jogo xCloud.
  static String? productId(String link) => _re.firstMatch(link)?.group(1)?.toUpperCase();

  /// Abre o jogo pelo motor. false = link que o motor não trata (segue o caminho antigo).
  static bool play(String link, String title, {required VoidCallback onFallback}) {
    final pid = productId(link);
    final nav = navKey.currentState;
    if (pid == null || nav == null) return false;
    nav.push(MaterialPageRoute(
      builder: (_) => _PreparePage(
        pid: pid,
        title: title,
        onFallback: () {
          nav.pop();
          onFallback();
        },
      ),
    ));
    return true;
  }

  // cache: productId -> {titleId, playable}
  static Map<String, Map<String, dynamic>>? _titles;

  static Future<Map<String, Map<String, dynamic>>> titles({bool refresh = false}) async {
    if (_titles != null && !refresh) return _titles!;
    final t = await Engine.titles();
    final res = (t is Map ? t['results'] : null) as List? ?? [];
    final out = <String, Map<String, dynamic>>{};
    for (final e in res) {
      if (e is! Map) continue;
      final d = e['details'] is Map ? e['details'] as Map : const {};
      final pid = (d['productId'] ?? '').toString().toUpperCase();
      final id = (e['titleId'] ?? e['XCloudTitleId'] ?? '').toString();
      if (pid.isEmpty || id.isEmpty) continue;
      out[pid] = {
        'titleId': id,
        'playable': d['hasEntitlement'] == true || d['isFreeInStore'] == true,
      };
    }
    return _titles = out;
  }
}

/// Tela de "carregando" do Ryzen: login (se preciso), escolha do título e preparo da sessão.
class _PreparePage extends StatefulWidget {
  const _PreparePage({required this.pid, required this.title, required this.onFallback});
  final String pid;
  final String title;
  final VoidCallback onFallback;

  @override
  State<_PreparePage> createState() => _PreparePageState();
}

class _PreparePageState extends State<_PreparePage> {
  String status = 'Iniciando...';
  String? error;
  WebViewController? web;
  bool gone = false;

  @override
  void initState() {
    super.initState();
    Engine.init();
    _run();
  }

  @override
  void dispose() {
    gone = true;
    super.dispose();
  }

  void _say(String s) {
    if (mounted && !gone) setState(() => status = s);
  }

  void _fail(Object e) {
    if (mounted && !gone) setState(() => error = e.toString().replaceFirst('PlatformException', '').trim());
  }

  Future<void> _run() async {
    try {
      setState(() => error = null);
      _say('Conectando ao Xbox...');
      final ok = await Engine.initSession();
      if (!ok) {
        await _startLogin();
        return; // continua em _afterLogin
      }
      await _go();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _startLogin() async {
    _say('É preciso entrar na conta Microsoft.');
    final r = await Engine.loginStart();
    final scheme = r['scheme'] as String;
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36')
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          if (req.url.startsWith(scheme)) {
            _afterLogin(req.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(r['authUrl'] as String));
    if (mounted) setState(() => web = c);
  }

  Future<void> _afterLogin(String url) async {
    if (mounted) setState(() => web = null);
    try {
      _say('Concluindo o login...');
      await Engine.loginFinish(url);
      await _go();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _go() async {
    _say('Procurando o jogo na sua conta...');
    var map = await EnginePlay.titles();
    var item = map[widget.pid];
    if (item == null) {
      map = await EnginePlay.titles(refresh: true);
      item = map[widget.pid];
    }
    if (item == null) {
      _fail('Este jogo não está disponível no xCloud para a sua conta.');
      return;
    }
    if (item['playable'] != true) {
      _fail('Sua conta não tem direito de jogar este título (precisa do Game Pass ou ter o jogo).');
      return;
    }
    _say('Liberando sessões antigas...');
    try {
      await Engine.cleanup();
    } catch (_) {}
    _say('Preparando o stream...');
    final info = await Engine.prepareStream(item['titleId'] as String);
    if (!mounted || gone) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => StreamScreen(streamInfo: info, title: widget.title),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (web != null) {
      return Scaffold(
        body: SafeArea(child: WebViewWidget(controller: web!)),
        floatingActionButton: FloatingActionButton.small(
          onPressed: () => Navigator.of(context).pop(),
          child: const Icon(Icons.close),
        ),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (error == null) const CircularProgressIndicator(),
          const SizedBox(height: 20),
          Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 22)),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(error ?? status,
                textAlign: TextAlign.center,
                style: TextStyle(color: error == null ? Colors.white70 : Colors.redAccent)),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Wrap(spacing: 12, children: [
                FilledButton(onPressed: _run, child: const Text('Tentar de novo')),
                OutlinedButton(onPressed: widget.onFallback, child: const Text('Abrir no navegador')),
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Voltar')),
              ]),
            ),
        ]),
      ),
    );
  }
}
