import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';
import 'engine_play.dart';
import 'state.dart';

/// Login único do Ryzen: a mesma entrada Microsoft (XAL) usada pelo motor do XStreaming
/// libera o app e também os jogos, sem pedir login duas vezes.
class EngineLoginGate extends StatefulWidget {
  const EngineLoginGate({super.key});

  @override
  State<EngineLoginGate> createState() => _EngineLoginGateState();
}

class _EngineLoginGateState extends State<EngineLoginGate> {
  WebViewController? web;
  String status = 'Verificando a conta...';
  String? error;

  @override
  void initState() {
    super.initState();
    Engine.init();
    _start();
  }

  void _say(String s) {
    if (mounted) setState(() => status = s);
  }

  void _fail(Object e) {
    if (mounted) {
      setState(() => error = e.toString().replaceFirst('PlatformException', '').trim());
    }
  }

  void _done() {
    // adianta a lista de jogos para o primeiro "Jogar" ser mais rápido
    EnginePlay.titles().then((_) {}).catchError((_) {});
    st.setMsLogged();
  }

  Future<void> _start() async {
    try {
      if (mounted) setState(() => error = null);
      _say('Verificando a conta...');
      if (await Engine.initSession()) {
        _done();
        return;
      }
      await _login();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _login() async {
    _say('Abrindo o login da Microsoft...');
    final r = await Engine.loginStart();
    final scheme = r['scheme'] as String;
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36')
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          if (req.url.startsWith(scheme)) {
            _finish(req.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(r['authUrl'] as String));
    if (mounted) setState(() => web = c);
  }

  Future<void> _finish(String url) async {
    if (mounted) setState(() => web = null);
    try {
      _say('Concluindo o login...');
      await Engine.loginFinish(url);
      _done();
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (web != null) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(child: WebViewWidget(controller: web!)),
      );
    }
    // verificando/abrindo/concluindo o login: tela sem textos (só aparecem o formulário da Microsoft e os erros)
    if (error == null) return const Scaffold(backgroundColor: Color(0xFF101418));
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 20),
          const Text('Ryzen', style: TextStyle(color: Colors.white, fontSize: 26)),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(error ?? status,
                textAlign: TextAlign.center,
                style: TextStyle(color: error == null ? Colors.white70 : Colors.redAccent)),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Wrap(spacing: 12, children: [
                FilledButton(onPressed: _start, child: const Text('Tentar de novo')),
                // saída de emergência: o login será pedido de novo ao abrir um jogo
                TextButton(onPressed: st.setMsLogged, child: const Text('Pular por agora')),
              ]),
            ),
        ]),
      ),
    );
  }
}
