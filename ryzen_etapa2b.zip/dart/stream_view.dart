import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'game.dart' show LoadingSplash;
import 'nano_view.dart';
import 'native.dart';
import 'state.dart';

/// Stream do xCloud dentro do Ryzen: ocupa o lugar do navegador, e o painel rápido do Ryzen
/// (volume, brilho, layout Nintendo, voltar ao Ryzen...) aparece por cima, como nos outros jogos.
class StreamView extends StatefulWidget {
  const StreamView({super.key, required this.info, this.title, this.cover, this.banner});
  final Map<dynamic, dynamic> info;
  final String? title;
  final ImageProvider? cover;
  final ImageProvider? banner;

  @override
  State<StreamView> createState() => _StreamViewState();
}

class _StreamViewState extends State<StreamView> {
  NanoController? c;
  StreamSubscription<Map<String, dynamic>>? _rumbleSub;
  late final void Function(List<double>) _padMark;
  bool started = false;
  bool nintendo = false;
  Timer? _clock;
  int _secs = 0;
  final DateTime _t0 = DateTime.now();

  @override
  void initState() {
    super.initState();
    // o controle vai direto do MainActivity ao stream; este marcador só diz "sou eu o dono"
    _padMark = (_) {};
    Native.onPad = _padMark;
    Native.setGameMode(true);
    st.addListener(_onState);
    // "Tempo decorrido" da tela de carregamento
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      final n = DateTime.now().difference(_t0).inSeconds;
      if (mounted && n != _secs) setState(() => _secs = n);
    });
  }

  void _onState() {
    if (c != null && st.nintendo != nintendo) {
      nintendo = st.nintendo;
      c!.setNintendo(nintendo).catchError((_) {});
    }
    if (mounted) setState(() {}); // estatísticas ligadas/desligadas
  }

  void _onCreated(NanoController ctrl) {
    c = ctrl;
    nintendo = st.nintendo;
    ctrl.setNintendo(nintendo).catchError((_) {});
    ctrl.state.addListener(_maybeStart);
    _rumbleSub = ctrl.rumble.listen(_onRumble);
    setState(() {});
    _maybeStart();
  }

  void _maybeStart() {
    final s = c?.state.value ?? const {};
    if (!started && s['surfaceReady'] == true) {
      started = true;
      c!.start();
      c!.focus();
    }
  }

  void _onRumble(Map<String, dynamic> m) {
    final dur = (m['duration'] as num?)?.toInt() ?? 0;
    var mag = math.max((m['weakMagnitude'] as num?)?.toDouble() ?? 0,
        (m['strongMagnitude'] as num?)?.toDouble() ?? 0);
    if (mag > 1) mag /= 100;
    final amp = (mag * 255).round().clamp(0, 255);
    if (dur <= 0 || amp <= 0) {
      Native.rumble(0, 0);
    } else {
      Native.rumble(dur.clamp(1, 2000), amp);
    }
  }

  @override
  void dispose() {
    _clock?.cancel();
    st.removeListener(_onState);
    _rumbleSub?.cancel();
    Native.rumble(0, 0);
    final ctrl = c;
    if (ctrl != null) {
      // encerra a sessão no servidor antes de soltar a vista
      ctrl.stop().catchError((_) {}).whenComplete(ctrl.dispose);
    }
    // se outro jogo já assumiu o controle, não desliga a captura dele
    if (identical(Native.onPad, _padMark)) {
      Native.onPad = null;
      Native.setGameMode(false);
    }
    super.dispose();
  }

  String _fmt(dynamic v, [int d = 0]) => v is num ? v.toStringAsFixed(d) : '-';

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.black,
      child: Stack(fit: StackFit.expand, children: [
        NanoStreamWidget(streamInfo: widget.info, onCreated: _onCreated),
        if (c != null)
          ValueListenableBuilder<Map<String, dynamic>>(
            valueListenable: c!.state,
            builder: (_, s, __) {
              final playing = ((s['renderedVideoFrames'] ?? 0) as num) > 0;
              final error = s['terminalSessionError'] == true;
              final status = (s['sessionStatusText'] ?? '').toString();
              final stage = (s['sessionStage'] ?? '').toString();
              return Stack(fit: StackFit.expand, children: [
                if (!playing)
                  (error ? _loading(true, status.isEmpty ? stage : status) : _splash()),
                if (playing && st.streamStats)
                  Positioned(
                    left: 12,
                    top: 8,
                    child: Text(
                      '${_fmt(s['videoWidth'])}x${_fmt(s['videoHeight'])}  '
                      '${_fmt(s['webRtcFps'])} fps  ${_fmt(s['webRtcRttMs'])} ms  '
                      '${_fmt(s['webRtcBitrateMbps'], 1)} Mbps  '
                      '${_fmt(s['renderedVideoFrames'])} quadros  $stage',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ),
              ]);
            },
          )
        else
          _splash(),
      ]),
    );
  }

  // mesma tela de carregamento dos outros jogos do Ryzen
  Widget _splash() => LoadingSplash(
        title: widget.title ?? 'Ryzen',
        cover: widget.cover,
        banner: widget.banner,
        secs: _secs,
        onBack: () => st.closeGame(),
      );

  // tela de carregamento do Ryzen: capa do jogo ao fundo, título e etapa da sessão
  Widget _loading(bool error, String text) {
    final bg = widget.banner ?? widget.cover;
    return Container(
      color: const Color(0xFF101418),
      child: Stack(fit: StackFit.expand, children: [
        if (bg != null) Opacity(opacity: 0.35, child: Image(image: bg, fit: BoxFit.cover)),
        Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (!error) const CircularProgressIndicator(),
            const SizedBox(height: 22),
            Text(widget.title ?? 'Carregando jogo',
                style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(error ? 'Erro: $text' : text,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: error ? Colors.redAccent : Colors.white70, fontSize: 15)),
            ),
            if (error)
              Padding(
                padding: const EdgeInsets.only(top: 18),
                child: FilledButton(onPressed: st.closeGame, child: const Text('Voltar ao Ryzen')),
              ),
          ]),
        ),
      ]),
    );
  }
}
