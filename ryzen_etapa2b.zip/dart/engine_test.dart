import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'engine.dart';
import 'stream_screen.dart';

class _Game {
  _Game(this.id, this.name, this.playable);
  final String id;
  final String name;
  final bool playable;
}

/// Tela de teste: login Microsoft + lista de jogos jogáveis + abrir o stream.
class EngineTest extends StatefulWidget {
  const EngineTest({super.key});
  @override
  State<EngineTest> createState() => _EngineTestState();
}

class _EngineTestState extends State<EngineTest> {
  String log = 'Iniciando o motor...';
  WebViewController? web;
  List<_Game> games = [];
  int total = 0;
  bool busy = false;
  bool showAll = false;

  void say(String s) {
    if (mounted) setState(() => log = s);
  }

  @override
  void initState() {
    super.initState();
    Engine.init();
    Engine.onEvent = (n, d) => say('evento: $n $d');
    _start();
  }

  Future<void> _run(Future<void> Function() f) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await f();
    } catch (e) {
      say('ERRO: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _start() => _run(() async {
        final ok = await Engine.initSession();
        if (ok) {
          await _list();
        } else {
          say('Motor OK. Sem login salvo: toque em "Entrar com Microsoft".');
        }
      });

  Future<void> _login() => _run(() async {
        final r = await Engine.loginStart();
        final scheme = r['scheme'] as String;
        final c = WebViewController()
          ..setJavaScriptMode(JavaScriptMode.unrestricted)
          ..setUserAgent(
              'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36')
          ..setNavigationDelegate(NavigationDelegate(
            onNavigationRequest: (req) {
              if (req.url.startsWith(scheme)) {
                _finish(req.url);
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ))
          ..loadRequest(Uri.parse(r['authUrl'] as String));
        setState(() => web = c);
      });

  Future<void> _finish(String url) async {
    setState(() => web = null);
    await _run(() async {
      say('Concluindo o login...');
      await Engine.loginFinish(url);
      await _list();
    });
  }

  Future<void> _list() async {
    say('Buscando jogos...');
    final t = await Engine.titles();
    final res = (t is Map ? t['results'] : null) as List? ?? [];
    final out = <_Game>[];
    for (final e in res) {
      if (e is! Map) continue;
      final id = (e['titleId'] ?? e['XCloudTitleId'] ?? '').toString();
      if (id.isEmpty) continue;
      final d = e['details'] is Map ? e['details'] as Map : const {};
      final playable = d['hasEntitlement'] == true || d['isFreeInStore'] == true;
      final name = (d['name'] ?? d['ProductTitle'] ?? e['ProductTitle'] ?? id).toString();
      out.add(_Game(id, name, playable));
    }
    out.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    total = out.length;
    games = out;
    final n = out.where((g) => g.playable).length;
    say('Login OK. $n jogáveis de $total. Toque num jogo para abrir.');
  }

  Future<void> _play(_Game g) => _run(() async {
        say('Preparando ${g.name}...');
        final info = await Engine.prepareStream(g.id);
        if (!mounted) return;
        say('Abrindo ${g.name}');
        await Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => StreamScreen(streamInfo: info, title: g.name)));
        say('Stream encerrado. Escolha outro jogo.');
      });

  @override
  Widget build(BuildContext context) {
    if (web != null) {
      return Scaffold(
        body: SafeArea(child: WebViewWidget(controller: web!)),
        floatingActionButton: FloatingActionButton.small(
          onPressed: () => setState(() => web = null),
          child: const Icon(Icons.close),
        ),
      );
    }
    final shown = showAll ? games : games.where((g) => g.playable).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              flex: 3,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(log, style: const TextStyle(color: Colors.white, fontSize: 15)),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: shown.length,
                    itemBuilder: (_, i) {
                      final g = shown[i];
                      return ListTile(
                        dense: true,
                        enabled: !busy,
                        title: Text(g.name,
                            style: TextStyle(color: g.playable ? Colors.white : Colors.white38)),
                        subtitle: Text(g.id + (g.playable ? '' : '  (sem direito)'),
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        onTap: () => _play(g),
                      );
                    },
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 16),
            Column(mainAxisSize: MainAxisSize.min, children: [
              FilledButton(onPressed: busy ? null : _login, child: const Text('Entrar com Microsoft')),
              const SizedBox(height: 8),
              FilledButton(onPressed: busy ? null : () => _run(_list), child: const Text('Listar jogos')),
              const SizedBox(height: 8),
              FilterChip(
                label: const Text('Mostrar todos'),
                selected: showAll,
                onSelected: (v) => setState(() => showAll = v),
              ),
              if (busy) const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()),
            ]),
          ]),
        ),
      ),
    );
  }
}
