import 'dart:convert';
import 'package:flutter/services.dart';

/// Ponte do Flutter para o motor do XStreaming (React Native sem tela).
class Engine {
  static const _ch = MethodChannel('ryzen/engine');
  static void Function(String name, Map<String, dynamic> data)? onEvent;

  static void init() {
    _ch.setMethodCallHandler((c) async {
      if (c.method == 'event') {
        final a = Map<String, dynamic>.from(c.arguments as Map);
        onEvent?.call(a['name'] as String, jsonDecode((a['json'] as String?) ?? '{}'));
      }
    });
  }

  static Future<dynamic> call(String cmd, [Map<String, dynamic>? args]) async {
    final s = await _ch.invokeMethod<String>('call', {'cmd': cmd, 'args': jsonEncode(args ?? {})});
    return s == null ? null : jsonDecode(s);
  }

  static Future<bool> initSession() async => (await call('init'))['loggedIn'] == true;
  static Future<Map> loginStart() async => Map.from(await call('loginStart'));
  static Future<bool> loginFinish(String url) async => (await call('loginFinish', {'url': url}))['loggedIn'] == true;
  static Future<dynamic> titles() => call('titles');
  static Future<dynamic> cleanup() => call('cleanup');
  static Future<Map> prepareStream(String titleId) async => Map.from(await call('prepareStream', {'titleId': titleId}));
}
