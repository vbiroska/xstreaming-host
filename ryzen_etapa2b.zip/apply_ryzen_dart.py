#!/usr/bin/env python3
"""Roda na pasta do app Flutter (ryzen_app): vira módulo (AAR), liga o motor e abre a Loja pelo motor."""
import re, shutil, pathlib
HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"

for f in ("engine.dart", "engine_test.dart", "engine_play.dart", "nano_view.dart", "stream_screen.dart"):
    shutil.copy(HERE / "dart" / f, lib / f)

# main.dart: navigatorKey (para abrir telas de fora da árvore) e tela de teste só se pedida
m = lib / "main.dart"
s = m.read_text()
if "engine_play.dart" not in s:
    s = s.replace("import 'game.dart';", "import 'engine_play.dart';\nimport 'engine_test.dart';\nimport 'game.dart';", 1)
    assert "MaterialApp(" in s
    s = s.replace("MaterialApp(", "MaterialApp(\n      navigatorKey: EnginePlay.navKey,", 1)
    s = s.replace("home: const Shell(),",
                  "home: (const bool.fromEnvironment('ENGINE_TEST', defaultValue: false)) ? const EngineTest() : const Shell(),", 1)
    assert "EngineTest()" in s and "navigatorKey" in s
    m.write_text(s)

# state.dart: jogos da Loja com link xCloud abrem pelo motor
st = lib / "state.dart"
t = st.read_text()
if "EnginePlay" not in t:
    anchor = "    if (link.isNotEmpty) {\n      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }"
    assert anchor in t, "trecho do playStore não encontrado"
    new = ("    if (link.isNotEmpty) {\n"
           "      if (EnginePlay.play(link, title,\n"
           "          onFallback: () => openLink(link, key: key, title: title, cover: cover, banner: banner))) {\n"
           "        return;\n      }\n"
           "      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }")
    t = t.replace(anchor, new, 1)
    # import: logo após o primeiro import
    i = t.index("import ")
    t = t[:i] + "import 'engine_play.dart';\n" + t[i:]
    st.write_text(t)

p = pathlib.Path("pubspec.yaml")
t = p.read_text()
if "module:" not in t:
    t = re.sub(r"^flutter:\n", "flutter:\n  module:\n    androidX: true\n    androidPackage: com.ryzen.ryzen\n    iosBundleIdentifier: com.ryzen.ryzen\n", t, count=1, flags=re.M)
    assert "module:" in t
    p.write_text(t)
print("ok")
