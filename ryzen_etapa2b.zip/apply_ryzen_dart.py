#!/usr/bin/env python3
"""Roda na pasta do app Flutter (ryzen_app): vira módulo (AAR), liga o motor e abre a Loja pelo motor."""
import re, shutil, pathlib
HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"

for f in ("engine.dart", "engine_test.dart", "engine_play.dart", "engine_login.dart", "nano_view.dart", "stream_screen.dart", "stream_view.dart"):
    shutil.copy(HERE / "dart" / f, lib / f)

# main.dart: navigatorKey (para abrir telas de fora da árvore) e tela de teste só se pedida
m = lib / "main.dart"
s = m.read_text()
if "engine_play.dart" not in s:
    s = s.replace("import 'game.dart';", "import 'engine_play.dart';\nimport 'engine_test.dart';\nimport 'game.dart';", 1)
    assert "MaterialApp(" in s
    s = s.replace("MaterialApp(", "MaterialApp(\n      navigatorKey: EnginePlay.navKey,", 1)
    s = s.replace("home: const Shell(),",
                  "home: (const bool.fromEnvironment('ENGINE_TEST', defaultValue: false)) ? const EngineTest() : const Shell(),", 1)
    assert "EngineTest()" in s and "navigatorKey" in s
    m.write_text(s)

# stream do motor no lugar do navegador
s = m.read_text()
if "StreamView(" not in s:
    anchor = "child: GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),"
    assert anchor in s, "GameView não encontrado no main.dart"
    s = s.replace(anchor,
        "child: st.streamInfo != null\n"
        "                          ? StreamView(key: ValueKey(st.streamInfo), info: st.streamInfo!, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)\n"
        "                          : GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),", 1)
    s = s.replace("import 'engine_play.dart';", "import 'engine_play.dart';\nimport 'stream_view.dart';", 1)
    m.write_text(s)

# game.dart: a tela de carregamento (banner, capa, tempo e barra de LED) vira pública para o stream usar
g = lib / "game.dart"
gt = g.read_text()
if "class LoadingSplash " not in gt:
    assert "class _LoadingSplash " in gt, "tela de carregamento não encontrada no game.dart"
    g.write_text(gt.replace("_LoadingSplash", "LoadingSplash"))

# login único: o login do motor (XAL) substitui a tela de login do navegador
s = m.read_text()
if "EngineLoginGate" not in s:
    anchor = "if (!st.msLogged) return const MsLoginGate();"
    assert anchor in s, "porta de login não encontrada no main.dart"
    s = s.replace(anchor, "if (!st.msLogged) return const EngineLoginGate();", 1)
    s = s.replace("import 'engine_play.dart';", "import 'engine_login.dart';\nimport 'engine_play.dart';", 1)
    m.write_text(s)

# state.dart: jogos da Loja com link xCloud abrem pelo motor, e o stream vira um "jogo" do Ryzen
st = lib / "state.dart"
t = st.read_text()
if "EnginePlay" not in t:
    def sub(old, new):
        global t
        assert t.count(old) >= 1, "trecho não encontrado em state.dart: " + old[:60]
        t = t.replace(old, new, 1)

    # 1) campos
    sub("  String? gameUrl;", "  String? gameUrl;\n  Map? streamInfo; // stream do xCloud aberto pelo motor (gameUrl vira 'ryzen://stream')\n  bool streamStats = true;")

    # 2) abrir / alternar estatísticas
    sub("  void openPadTest() {", """  /// Abre o stream do motor como um jogo: reaproveita menu rápido, tempo de jogo e foco do Ryzen.
  void openStream(Map info, {String? key, String? title, ImageProvider? cover, ImageProvider? banner}) {
    _webKey = key;
    _webAt = key == null ? null : DateTime.now();
    gameTitle = title;
    gameCover = cover;
    gameBanner = banner;
    streamInfo = info;
    gameUrl = 'ryzen://stream';
    gameMenu = false;
    lastInput = DateTime.now();
    notifyListeners();
  }

  void toggleStreamStats() {
    streamStats = !streamStats;
    notifyListeners();
  }

  void openPadTest() {""")

    # 3) fechar o jogo também fecha o stream
    sub("    gameUrl = null;\n    gameTitle = null;", "    gameUrl = null;\n    streamInfo = null;\n    gameTitle = null;")

    # 4) menu rápido: sem "ajuste da tela"/"recarregar" no stream, com "estatísticas"
    sub("        QRow(tr('Ajuste da tela'),", "        if (streamInfo == null) QRow(tr('Ajuste da tela'),")
    sub("        QRow(tr('Recarregar página'),", "        if (streamInfo == null) QRow(tr('Recarregar página'),")
    sub("        QRow(tr('Voltar ao Ryzen'),", """        if (streamInfo != null)
          QRow(tr('Estatísticas'), 'brightness', 'btn', () => streamStats ? tr('Ligado') : tr('Desligado'),
              toggleStreamStats, (_) => toggleStreamStats()),
        QRow(tr('Voltar ao Ryzen'),""")

    # 5) Loja: link xCloud -> motor
    sub("    if (link.isNotEmpty) {\n      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }",
        "    if (link.isNotEmpty) {\n"
        "      if (EnginePlay.play(link, title, cover: cover, banner: banner,\n"
        "          onReady: (info) => openStream(info, key: key, title: title, cover: cover, banner: banner))) {\n"
        "        return;\n      }\n"
        "      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }")
    i0 = t.index("import ")
    t = t[:i0] + "import 'engine_play.dart';\n" + t[i0:]
    st.write_text(t)

p = pathlib.Path("pubspec.yaml")
t = p.read_text()
if "module:" not in t:
    t = re.sub(r"^flutter:\n", "flutter:\n  module:\n    androidX: true\n    androidPackage: com.ryzen.ryzen\n    iosBundleIdentifier: com.ryzen.ryzen\n", t, count=1, flags=re.M)
    assert "module:" in t
    p.write_text(t)
print("ok")
