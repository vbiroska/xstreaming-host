#!/usr/bin/env python3
"""Roda na pasta do app Flutter (ryzen_app): vira módulo (AAR), liga o motor e abre a Loja pelo motor."""
import re, shutil, pathlib
HERE = pathlib.Path(__file__).resolve().parent
lib = pathlib.Path("lib")
assert lib.is_dir(), "rode dentro de ryzen_app"

for f in ("engine.dart", "engine_test.dart", "engine_play.dart", "engine_login.dart", "nano_view.dart", "stream_screen.dart", "stream_view.dart", "friends.dart"):
    shutil.copy(HERE / "dart" / f, lib / f)

# main.dart: navigatorKey (para abrir telas de fora da árvore) e tela de teste só se pedida
m = lib / "main.dart"
s = m.read_text()
if "engine_play.dart" not in s:
    s = s.replace("import 'game.dart';", "import 'engine_play.dart';\nimport 'engine_test.dart';\nimport 'game.dart';", 1)
    assert "MaterialApp(" in s
    s = s.replace("MaterialApp(", "MaterialApp(\n      navigatorKey: EnginePlay.navKey,", 1)
    s = s.replace("home: const Shell(),",
                  "home: (const bool.fromEnvironment('ENGINE_TEST', defaultValue: false)) ? const EngineTest() : const Shell(),", 1)
    assert "EngineTest()" in s and "navigatorKey" in s
    m.write_text(s)

# stream do motor no lugar do navegador
s = m.read_text()
if "StreamView(" not in s:
    anchor = "child: GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),"
    assert anchor in s, "GameView não encontrado no main.dart"
    s = s.replace(anchor,
        "child: st.streamInfo != null\n"
        "                          ? StreamView(key: ValueKey(st.streamInfo), info: st.streamInfo!, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)\n"
        "                          : GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),", 1)
    s = s.replace("import 'engine_play.dart';", "import 'engine_play.dart';\nimport 'stream_view.dart';", 1)
    m.write_text(s)

# game.dart: a tela de carregamento (banner, capa, tempo e barra de LED) vira pública para o stream usar
g = lib / "game.dart"
gt = g.read_text()
if "class LoadingSplash " not in gt:
    assert "class _LoadingSplash " in gt, "tela de carregamento não encontrada no game.dart"
    g.write_text(gt.replace("_LoadingSplash", "LoadingSplash"))

# game.dart: Fortnite roda no WebView sempre com user-agent de PC (Edge) = 1080p, independente da qualidade escolhida
gt = g.read_text()
if "__fortnitePc" not in gt:
    old_ua = "..setUserAgent(st.streamQ >= 2 ? _tizenUa : (st.streamQ >= 1 ? _desktopUa : null))"
    assert old_ua in gt, "setUserAgent não encontrado no game.dart"
    new_ua = ("..setUserAgent(/*__fortnitePc*/ (widget.url.toUpperCase().contains('BT5P2X999VH2') || widget.url.toLowerCase().contains('/fortnite'))\n"
              "          ? _desktopUa\n"
              "          : (st.streamQ >= 2 ? _tizenUa : (st.streamQ >= 1 ? _desktopUa : null)))")
    g.write_text(gt.replace(old_ua, new_ua, 1))

# game.dart (Fortnite): além do user-agent, a página recebe identidade de PC completa e o pedido da sessão
# sai como cliente Windows 1920x1080 (como o motor faz com resolution 1080)
gt = g.read_text()
if "_pcJs" not in gt:
    PCJS = r'''(function(){
  if (window.__rzPc) return; window.__rzPc = 1;
  function def(o, k, v){ try { Object.defineProperty(o, k, { get: function(){ return v; }, configurable: true }); } catch (e) {} }
  // 1) o navegador se apresenta como Edge no Windows por inteiro (o user-agent sozinho deixa platform/Client Hints de Android)
  var nav = Object.getPrototypeOf(navigator);
  def(nav, 'platform', 'Win32');
  var brands = [{ brand: 'Chromium', version: '140' }, { brand: 'Microsoft Edge', version: '140' }, { brand: 'Not=A?Brand', version: '24' }];
  def(nav, 'userAgentData', {
    brands: brands, mobile: false, platform: 'Windows',
    getHighEntropyValues: function(){ return Promise.resolve({ brands: brands, mobile: false, platform: 'Windows', platformVersion: '10.0.0', architecture: 'x86', bitness: '64', model: '', uaFullVersion: '140.0.0.0', fullVersionList: brands }); },
    toJSON: function(){ return { brands: brands, mobile: false, platform: 'Windows' }; }
  });
  var sp = Object.getPrototypeOf(screen);
  def(sp, 'width', 1920); def(sp, 'height', 1080); def(sp, 'availWidth', 1920); def(sp, 'availHeight', 1080);
  // 2) o pedido de início da sessão (sessions/cloud/play) vai como cliente PC 1920x1080, igual ao motor
  function fixDev(v){
    try {
      var j = JSON.parse(v); j.dev = j.dev || {};
      j.dev.os = Object.assign({}, j.dev.os, { name: 'Windows', ver: '10.0.19041.0', platform: 'desktop' });
      j.dev.displayInfo = { dimensions: { widthInPixels: 1920, heightInPixels: 1080 }, pixelDensity: { dpiX: 1, dpiY: 1 } };
      return JSON.stringify(j);
    } catch (e) { return v; }
  }
  function fixBody(b){
    if (typeof b !== 'string') return b;
    try { var j = JSON.parse(b); if (j && j.settings) { j.settings.osName = 'windows'; return JSON.stringify(j); } } catch (e) {}
    return b;
  }
  function isPlay(u){ return /\/sessions\/cloud\/play/i.test(String(u)); }
  var of = window.fetch;
  window.fetch = function(input, init){
    try {
      var url = (typeof input === 'string' || input instanceof URL) ? String(input) : ((input && input.url) || '');
      if (isPlay(url)) {
        if (input instanceof Request) {
          return input.clone().text().then(function(t){
            var h = new Headers(input.headers);
            if (h.has('x-ms-device-info')) h.set('x-ms-device-info', fixDev(h.get('x-ms-device-info')));
            return of.call(window, new Request(input.url, { method: input.method, headers: h, body: fixBody(t), mode: input.mode, credentials: input.credentials, cache: input.cache, redirect: input.redirect, referrer: input.referrer, signal: input.signal }));
          });
        }
        init = Object.assign({}, init || {});
        var hh = new Headers(init.headers || {});
        if (hh.has('x-ms-device-info')) hh.set('x-ms-device-info', fixDev(hh.get('x-ms-device-info')));
        init.headers = hh; init.body = fixBody(init.body);
      }
    } catch (e) {}
    return of.call(this, input, init);
  };
  var xo = XMLHttpRequest.prototype.open, xs = XMLHttpRequest.prototype.setRequestHeader, xd = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, u){ this.__rzPlay = isPlay(u); return xo.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(k, v){
    if (this.__rzPlay && String(k).toLowerCase() === 'x-ms-device-info') v = fixDev(v);
    return xs.call(this, k, v);
  };
  XMLHttpRequest.prototype.send = function(b){ return xd.call(this, this.__rzPlay ? fixBody(b) : b); };
})();
'''
    a1 = "/// Navegador de PC (Edge)"
    assert a1 in gt, "âncora do user-agent não encontrada no game.dart"
    gt = gt.replace(a1, "/// Fortnite: identidade de PC (Edge/Windows) + sessão pedida em 1080p.\nconst _pcJs = r'''\n" + PCJS + "\n''';\n\n" + a1, 1)
    a2 = "Native.docScript('window.__rzDoc=1;' + _padJs + ((st.jbLevel > 0 || st.showStats || st.h264) ? _rtcJs(st.jbLevel, st.showStats, st.h264) : ''))"
    assert a2 in gt, "docScript não encontrado no game.dart"
    gt = gt.replace(a2, a2[:-1] + " + (_isFortnite ? _pcJs : ''))", 1)
    a3 = "  bool _sharpOn = false;\n"
    assert a3 in gt, "_sharpOn não encontrado no game.dart"
    gt = gt.replace(a3, a3 + "  bool get _isFortnite => widget.url.toUpperCase().contains('BT5P2X999VH2') || widget.url.toLowerCase().contains('/fortnite');\n", 1)
    a4 = "    if (st.streamQ >= 1) c.runJavaScript(_fastNetJs).catchError((_) {});\n"
    assert a4 in gt, "_fastNetJs não encontrado no game.dart"
    gt = gt.replace(a4, a4 + "    if (_isFortnite) c.runJavaScript(_pcJs).catchError((_) {});\n", 1)
    g.write_text(gt)

# login único: o login do motor (XAL) substitui a tela de login do navegador
s = m.read_text()
if "EngineLoginGate" not in s:
    anchor = "if (!st.msLogged) return const MsLoginGate();"
    assert anchor in s, "porta de login não encontrada no main.dart"
    s = s.replace(anchor, "if (!st.msLogged) return const EngineLoginGate();", 1)
    s = s.replace("import 'engine_play.dart';", "import 'engine_login.dart';\nimport 'engine_play.dart';", 1)
    m.write_text(s)

# state.dart: jogos da Loja com link xCloud abrem pelo motor, e o stream vira um "jogo" do Ryzen
st = lib / "state.dart"
t = st.read_text()
if "EnginePlay" not in t:
    def sub(old, new):
        global t
        assert t.count(old) >= 1, "trecho não encontrado em state.dart: " + old[:60]
        t = t.replace(old, new, 1)

    # 1) campos
    sub("  String? gameUrl;", "  String? gameUrl;\n  Map? streamInfo; // stream do xCloud aberto pelo motor (gameUrl vira 'ryzen://stream')\n  bool streamStats = true;")

    # 2) abrir / alternar estatísticas
    sub("  void openPadTest() {", """  /// Abre o stream do motor como um jogo: reaproveita menu rápido, tempo de jogo e foco do Ryzen.
  void openStream(Map info, {String? key, String? title, ImageProvider? cover, ImageProvider? banner}) {
    _webKey = key;
    _webAt = key == null ? null : DateTime.now();
    gameTitle = title;
    gameCover = cover;
    gameBanner = banner;
    streamInfo = info;
    gameUrl = 'ryzen://stream';
    gameMenu = false;
    lastInput = DateTime.now();
    notifyListeners();
  }

  void toggleStreamStats() {
    streamStats = !streamStats;
    notifyListeners();
  }

  void openPadTest() {""")

    # 3) fechar o jogo também fecha o stream
    sub("    gameUrl = null;\n    gameTitle = null;", "    gameUrl = null;\n    streamInfo = null;\n    gameTitle = null;")

    # 4) menu rápido: sem "ajuste da tela"/"recarregar" no stream, com "estatísticas"
    sub("        QRow(tr('Ajuste da tela'),", "        if (streamInfo == null) QRow(tr('Ajuste da tela'),")
    sub("        QRow(tr('Recarregar página'),", "        if (streamInfo == null) QRow(tr('Recarregar página'),")
    sub("        QRow(tr('Voltar ao Ryzen'),", """        if (streamInfo != null)
          QRow(tr('Estatísticas'), 'brightness', 'btn', () => streamStats ? tr('Ligado') : tr('Desligado'),
              toggleStreamStats, (_) => toggleStreamStats()),
        QRow(tr('Voltar ao Ryzen'),""")

    # 5) Loja: link xCloud -> motor
    sub("    if (link.isNotEmpty) {\n      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }",
        "    if (link.isNotEmpty) {\n"
        "      if (EnginePlay.play(link, title, cover: cover, banner: banner,\n"
        "          onReady: (info) => openStream(info, key: key, title: title, cover: cover, banner: banner))) {\n"
        "        return;\n      }\n"
        "      openLink(link, key: key, title: title, cover: cover, banner: banner);\n      return;\n    }")
    i0 = t.index("import ")
    t = t[:i0] + "import 'engine_play.dart';\n" + t[i0:]
    st.write_text(t)

# Início: card "Ryzen Friends" (amigos do Xbox) no canto inferior direito
tb = lib / "tabs.dart"
tt = tb.read_text()
if "FriendsCard" not in tt:
    old = "        top: 384 * s,\n        right: 20 * s,"
    assert old in tt, "lista de últimos jogos não encontrada no tabs.dart"
    tt = tt.replace(old, "        top: 384 * s,\n        right: 635 * s,", 1)
    mk = "      // Destaques\n"
    assert mk in tt, "marcador 'Destaques' não encontrado no tabs.dart"
    tt = tt.replace(mk, "      Positioned(right: 25 * s, top: 366 * s, width: 590 * s, height: 360 * s, child: const FriendsCard()),\n" + mk, 1)
    tt = tt.replace("import 'covers.dart';", "import 'covers.dart';\nimport 'friends.dart';", 1)
    assert "friends.dart" in tt
    tb.write_text(tt)

p = pathlib.Path("pubspec.yaml")
t = p.read_text()
if "module:" not in t:
    t = re.sub(r"^flutter:\n", "flutter:\n  module:\n    androidX: true\n    androidPackage: com.ryzen.ryzen\n    iosBundleIdentifier: com.ryzen.ryzen\n", t, count=1, flags=re.M)
    assert "module:" in t
    p.write_text(t)
print("ok")
