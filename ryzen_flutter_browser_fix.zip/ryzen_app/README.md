# Ryzen (Flutter)

Port do tema **Ryzen v2.0** (Pegasus Frontend / QML) para um app Android próprio, em Flutter.

## Como gerar o APK

### Opção A — sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e suba **todo o conteúdo desta pasta** (inclusive `.github/`).
2. Aba **Actions → Build APK → Run workflow**.
3. Quando terminar, baixe o artefato **ryzen-apk** (dentro dele está o `app-release.apk`).

### Opção B — no seu PC (Flutter + Android SDK instalados)
```bash
flutter create --platforms=android --org com.ryzen --project-name ryzen .
mkdir -p android/app/src/main/kotlin/com/ryzen/ryzen
cp android_patch/MainActivity.kt android/app/src/main/kotlin/com/ryzen/ryzen/MainActivity.kt
cp android_patch/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
```
O APK sai em `build/app/outputs/flutter-apk/app-release.apk`.

## O que mudou em relação ao tema do Pegasus
- **Jogos** = apps instalados no aparelho (o Pegasus lia coleções/gamelists). Escolha quais aparecem em Config › Meus jogos.
- **Horas jogadas** = tempo em que você ficou fora do Ryzen depois de abrir o jogo por ele (estimativa).
- **Último jogo** = o último aberto pelo Ryzen.
- **Imagens** (wallpaper, ícones, capas) são escolhidas pela galeria; não há mais as pastas `Pictures/Ryzen/...`.
- **Barra de status real:** hora, bateria, Wi-Fi (conectado ou não), Bluetooth (ligado ou não) e volume/mudo vêm do Android (atualiza a cada 5 s e ao voltar das configurações). Em Config › Wi-Fi/Bluetooth o botão abre os ajustes do sistema (o Android recente não deixa o app ligar/desligar direto); Config › Volume ajusta o volume de mídia e o mudo.
- **Listas de Wi-Fi e Bluetooth:** em Config › Wi-Fi / Bluetooth, o botão abre uma lista dentro do app (Y atualiza). Wi-Fi mostra sinal, protegida/aberta e a rede conectada; Bluetooth mostra pareados e disponíveis, e A em um disponível inicia o pareamento. O app pede permissão de Localização (Wi-Fi) ou Dispositivos próximos (Bluetooth, Android 12+). O Android não deixa um app conectar a Wi-Fi nem ligar fones já pareados por conta própria: nesses casos o A abre os ajustes do sistema.
- **Loja / nuvem:** A (ou toque) abre o jogo; Y (ou toque longo) fixa na tela inicial e permite colar um link próprio do jogo. Sem link, abre o serviço escolhido em Config › Serviço de nuvem (GeForce NOW, Moonlight, Steam Link ou Xbox Cloud Gaming); se o app não estiver instalado, abre a Play Store.\n- **Não portado:** troca dos ícones do sistema (ICONES.txt) e varredura de pasta de wallpapers.
- **Links / jogos na nuvem:** os links da Loja (link próprio do jogo ou Xbox Cloud Gaming) abrem em tela cheia dentro do Ryzen, sem aba de navegador. Dentro do link, o controle inteiro (A, B, X, Y, L1/R1, L2/R2 analógicos, analógicos esquerdo/direito, L3/R3, direcional, Start/Select) é lido pelo lado nativo e entregue à página como um gamepad padrão (`navigator.getGamepads`), então todos os botões funcionam no jogo. Para abrir o **menu do jogo** (continuar, volume, brilho, recarregar, voltar ao Ryzen): segure **SELECT + START** por ~0,8 s ou aperte o botão **Guia** (o voltar do Android também sai do link). Uma dica aparece por 5 s ao abrir. Links de apps (market://, intent://) vão para o Android.
- **Capas da Microsoft:** o app procura sozinho a capa de cada jogo da biblioteca no catálogo da Microsoft Store (precisa de internet), baixa uma vez e guarda no aparelho. Capa que você escolheu em Config › Ícones dos aplicativos sempre tem prioridade; quando não acha, usa o ícone do app. Dá para desligar em Config › Capas da Microsoft (ao religar, tenta de novo os jogos sem capa).
- **Últimos Jogos:** a fileira da Início mostra os cards da Biblioteca, com os jogados mais recentemente primeiro (depois os fixados da Loja e os ainda não jogados).
- Controle: direcional, A (selecionar), B (voltar), L1/R1 (trocar aba), Y (detalhes). Toque também funciona.
- O manifest inclui o filtro de **tela inicial (HOME)**: dá para definir o Ryzen como launcher. Apague esse bloco se não quiser.

## Novidades da v3.0
- **Menu rápido no jogo** (Guia ou SELECT+START): Continuar, Volume, Brilho, Layout Nintendo, Recarregar página, Voltar ao Ryzen. Navega com direcional/analógico, A confirma, B fecha.
- **Painel rápido no launcher** (botão **Start**): volume, brilho, tema, Wi-Fi, Bluetooth, busca e configurações.
- **Vibração real** nos jogos da nuvem (o jogo manda o pedido; o app vibra o controle ou, se ele não vibrar, o aparelho).
- **Tela sempre ligada** durante o jogo, **autoplay** de som/vídeo e **microfone** liberado (chat de voz do Xbox Cloud; o app pede a permissão na primeira vez).
- **Layout Nintendo** (A↔B, X↔Y) em Config ou no menu do jogo.
- **Busca com teclado na tela** (botão **Select**): apps e jogos da nuvem.
- **Favoritos** (botão **X**, coração no card) e **coleções** na Biblioteca (L2/R2): Todos, Favoritos, Nuvem, Apps.
- **Tela de descanso** após 3 min parado na tela inicial (relógio que se move devagar).
- **Animações**: transição entre abas, brilho e zoom no card selecionado; o fundo e o brilho acompanham a **cor da capa** selecionada.
- **Vídeo de fundo** (Config › Vídeo de fundo): vídeo da galeria em loop, sem som; pausa durante os jogos.
- **Controle conectado** + bateria dele na barra superior (bateria só em Android 12+ e controles que informam).
- **Idioma**: Português ou English (Config › Idioma / Language). Menus e telas principais estão traduzidos; mensagens de erro de Wi-Fi/Bluetooth e alguns textos secundários continuam em português.
- Novas permissões no manifest: VIBRATE, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS. Novas dependências: `video_player`, `webview_flutter_android`.

## Config em tela cheia
A aba Config agora ocupa a tela toda: menu de categorias à esquerda (Aparência, Jogos, Controles, Áudio, Rede, Sistema) e as opções da categoria à direita. Direcional ↑/↓ troca de categoria; A ou → entra nas opções; B (ou ← em itens sem ajuste lateral) volta ao menu; B no menu volta à Início. Toque também funciona.

## Ajuste da tela nos links (xCloud)
Config › Jogos › **Ajuste da tela do jogo** (e no menu do jogo, SELECT+START): **Padrão**, **Preencher** (o vídeo cobre a tela inteira, cortando um pouco as bordas) ou **Esticar** (preenche sem cortar, mas distorce a imagem). O app também passa a usar a área do recorte da câmera (notch), sem faixa preta nas laterais.

## Qualidade do streaming
Config › Jogos › **Qualidade do streaming**: *Padrão* ou *Alta*. Em *Alta* o WebView se identifica como Edge de PC (o xCloud libera 1080p), informa conexão rápida à página e, com qualquer jogo aberto, o app mantém o Wi-Fi em modo de baixa latência. A qualidade final continua sendo decidida pelo serviço conforme a sua internet (no xCloud, há também a escolha de resolução nos ajustes do próprio serviço, em testes).

## Perfil e login com Google
- Na primeira abertura aparece **Bem-vindo ao Ryzen**: dá para escolher foto (galeria), nome e, opcionalmente, entrar com o Google. B/Continuar pula.
- O perfil aparece na **Início** (canto do banner; toque para abrir) e em **Config › Perfil**.
- O login com o Google só funciona depois de configurar (uma vez):
  1. Google Cloud Console › novo projeto › *Tela de consentimento OAuth* (externo, adicione seu e-mail como testador).
  2. *Credenciais* › criar **ID do cliente OAuth** tipo **Android**: pacote `com.ryzen.ryzen` + impressão digital **SHA-1** (o workflow imprime o SHA-1 no passo "Keystore").
  3. Criar outro **ID do cliente OAuth** tipo **Aplicativo da Web** e copiar o ID (`xxxx.apps.googleusercontent.com`).
  4. No GitHub: Settings › Secrets and variables › Actions › New secret: `GOOGLE_CLIENT_ID` = o ID do tipo Web.
  5. O SHA-1 precisa ser sempre o mesmo: deixe o arquivo `debug.keystore` (gerado pelo workflow na 1ª vez, baixe do artefato `ryzen-debug-keystore`) na raiz do repositório.

## Destaque da Início (banners da Loja)
- O card grande da Início agora passa os jogos da Loja (fixados primeiro, até 6), trocando sozinho a cada 7 s; deslize ou toque nos pontinhos para trocar. **Jogar agora** abre o jogo; **•••** vai para a Loja.
- Os banners são buscados **só no site uhdpaper.com** (feed do Blogger e, se preciso, a busca em HTML), baixados uma vez e guardados no aparelho. Se não achar, o card mostra o fundo azul com o nome e uma linha pequena dizendo o motivo (toque nela para tentar de novo).
- A foto de perfil saiu do card: fica ao lado do nome RYZEN, no topo; toque para abrir o Perfil.

## Capas da Loja (SteamGridDB)
- As capas embutidas foram removidas do app. Agora cada jogo da Loja tem a capa buscada no **steamgriddb.com** (formato em pé) e guardada no aparelho; a capa que você escolher na galeria continua tendo prioridade. Sem capa ainda, o card mostra só o nome.
- Capas da Loja: o app procura cada jogo no catálogo do Xbox (mesma base do xbox.com/games) e guarda uma capa separada por jogo. Não precisa de chave.
- Na aba Loja, uma linha pequena embaixo mostra o estado da busca de capas (chave ausente/recusada, erro de rede, quantos jogos não foram achados). Toque nela para tentar de novo.
- As capas da Loja priorizam as **animadas** do SteamGridDB; se o jogo não tiver nenhuma, usa a estática.

## Qualidade (ajustes inspirados no XStreaming)
- **Qualidade do streaming › Máxima (teste):** o WebView se identifica como Smart TV (Tizen), como o XStreaming faz para pedir o 1080p de maior bitrate (HQ). É experimental: se o site do xCloud abrir com a tela errada, use Alta.
- **Preferir H.264:** agora ordena os perfis, com o 4d primeiro (depois 64 e 42e), como o XStreaming.
- **Tela em jogo:** usa a maior taxa de atualização múltipla de 60 Hz (60 ou 120) e pede pós-processamento mínimo (Android 11+).
- **Não portado:** FSR e geração de quadros (LSFG) do XStreaming dependem do renderizador nativo de vídeo (WebRTC nativo + Vulkan); não dá para ligar isso a uma página dentro do WebView. O filtro de Nitidez do Ryzen é o equivalente leve.

## Perfil e tela de carregamento
- Sem tela de boas-vindas e sem login com Google: o perfil guarda só foto e nome, salvos no aparelho. A foto de perfil do topo ficou maior.
- Tela de carregamento do jogo: fundo sempre com o banner horizontal do link do jogo, com a capa do jogo na lateral, barra de LED branco com brilho ao redor e preenchimento contínuo, sem saltos.
