package com.ryzen.ryzen

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.os.VibrationEffect
import android.os.Vibrator
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : FlutterActivity() {
    private var channel: MethodChannel? = null
    private var gameMode = false
    private var wifiLock: WifiManager.WifiLock? = null

    // Wi-Fi em modo de baixa latência/alto desempenho enquanto há um jogo aberto (streaming mais estável)
    @Suppress("DEPRECATION")
    private fun setWifiLock(on: Boolean) {
        try {
            if (on) {
                if (wifiLock == null) {
                    val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                    else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                    wifiLock = wm.createWifiLock(mode, "ryzen:stream").also { it.setReferenceCounted(false) }
                }
                if (wifiLock?.isHeld == false) wifiLock?.acquire()
            } else if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    // Script que roda ANTES dos scripts da página (document-start). O xCloud guarda uma referência
    // ao navigator.getGamepads original ao carregar; injetar depois (runJavaScript) chegava tarde.
    private var docHandler: ScriptHandler? = null
    private var gameWv: android.webkit.WebView? = null

    private fun findWebViews(v: android.view.View, out: MutableList<android.webkit.WebView>) {
        if (v is android.webkit.WebView) { out.add(v); return }
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) findWebViews(v.getChildAt(i), out)
    }

    private fun setDocScript(script: String?): Boolean {
        try { docHandler?.remove() } catch (_: Exception) {}
        docHandler = null
        if (script == null) { gameWv = null; return true }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return false
        val all = ArrayList<android.webkit.WebView>()
        findWebViews(window.decorView, all)
        val wv = all.lastOrNull { it.isShown } ?: all.lastOrNull() ?: return false
        gameWv = wv
        docHandler = WebViewCompat.addDocumentStartJavaScript(wv, script, setOf("*"))
        return true
    }

    // Em jogo: escolhe a maior taxa de atualização múltipla de 60 Hz (evita judder com stream de 60 fps;
    // 90 Hz não é usado) e pede pós-processamento mínimo da tela (menos latência, Android 11+).
    @Suppress("DEPRECATION")
    private fun setGameDisplay(on: Boolean) {
        runOnUiThread {
            try {
                val lp = window.attributes
                var id = 0
                if (on && Build.VERSION.SDK_INT >= 23) {
                    val d = windowManager.defaultDisplay
                    val cur = d.mode
                    val best = d.supportedModes
                        .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                        .filter { Math.round(it.refreshRate) % 60 == 0 }
                        .maxByOrNull { it.refreshRate }
                    id = best?.modeId ?: 0
                }
                lp.preferredDisplayModeId = id
                window.attributes = lp
            } catch (_: Throwable) {
            }
            try {
                if (Build.VERSION.SDK_INT >= 30) window.setPreferMinimalPostProcessing(on)
            } catch (_: Throwable) {
            }
        }
    }

    override fun onDestroy() {
        setWifiLock(false)
        super.onDestroy()
    }

    // Diálogo de permissão (microfone), barra de notificações ou outro app: o Android pode não
    // entregar o "soltar" dos botões e o estado ficava preso. Zera ao perder o foco.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus && gameMode) {
            keyState.fill(0.0); hatState.fill(0.0); axes.fill(0.0)
            padHandler.removeCallbacks(exitRunnable)
            exitPending = false
            padChanged()
        }
    }

    // ---------- controle dentro de jogo/link (streaming) ----------
    // A WebView fica dentro do Flutter e não recebe os eixos do controle (analógicos,
    // gatilhos, direcional "hat") nem todos os botões; por isso, com um jogo aberto, o
    // Activity lê o controle inteiro e repassa o estado ao Dart (canal "pad"), que o
    // entrega à página como um gamepad padrão (navigator.getGamepads). O B agora vai
    // para o jogo; para sair segure SELECT + START por ~0,8 s (ou use o voltar do Android).
    private val keyState = DoubleArray(17)   // botões vindos de KeyEvent
    private val hatState = DoubleArray(17)   // gatilhos analógicos e direcional vindos de eixos
    private val axes = DoubleArray(4)        // LX, LY, RX, RY
    private val padHandler = Handler(Looper.getMainLooper())
    private var flushPending = false
    private var exitPending = false
    private var menuMode = false          // menu rápido aberto: o controle navega o menu, não o jogo
    private var lastMenuDir: String? = null
    private var lastPadId = -1
    // SELECT + START segurados = abre o menu rápido do jogo
    private val exitRunnable = Runnable {
        exitPending = false
        keyState.fill(0.0)
        channel?.invokeMethod("gameMenu", null)
    }
    private val flushRunnable = Runnable {
        flushPending = false
        val out = DoubleArray(21)
        for (i in 0 until 17) out[i] = maxOf(keyState[i], hatState[i])
        for (i in 0 until 4) out[17 + i] = axes[i]
        channel?.invokeMethod("pad", out)
    }

    private fun has(src: Int, flag: Int) = (src and flag) == flag

    private fun padIndex(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_BUTTON_A -> 0
        KeyEvent.KEYCODE_BUTTON_B -> 1
        KeyEvent.KEYCODE_BUTTON_X -> 2
        KeyEvent.KEYCODE_BUTTON_Y -> 3
        KeyEvent.KEYCODE_BUTTON_L1 -> 4
        KeyEvent.KEYCODE_BUTTON_R1 -> 5
        KeyEvent.KEYCODE_BUTTON_L2 -> 6
        KeyEvent.KEYCODE_BUTTON_R2 -> 7
        KeyEvent.KEYCODE_BUTTON_SELECT -> 8
        KeyEvent.KEYCODE_BUTTON_START -> 9
        KeyEvent.KEYCODE_BUTTON_THUMBL -> 10
        KeyEvent.KEYCODE_BUTTON_THUMBR -> 11
        KeyEvent.KEYCODE_DPAD_UP -> 12
        KeyEvent.KEYCODE_DPAD_DOWN -> 13
        KeyEvent.KEYCODE_DPAD_LEFT -> 14
        KeyEvent.KEYCODE_DPAD_RIGHT -> 15
        KeyEvent.KEYCODE_BUTTON_MODE -> 16
        else -> -1
    }

    private fun padResetAll() {
        keyState.fill(0.0); hatState.fill(0.0); axes.fill(0.0)
        padHandler.removeCallbacks(exitRunnable)
        exitPending = false
        menuMode = false
        lastMenuDir = null
        padChanged()
    }

    private fun padChanged() {
        // SELECT + START segurados juntos = sair do jogo
        val both = gameMode && keyState[8] > 0.5 && keyState[9] > 0.5
        if (both && !exitPending) {
            exitPending = true
            padHandler.postDelayed(exitRunnable, 800)
        } else if (!both && exitPending) {
            exitPending = false
            padHandler.removeCallbacks(exitRunnable)
        }
        if (!flushPending) {
            flushPending = true
            padHandler.postDelayed(flushRunnable, 8) // agrupa eventos (~120 Hz no máx.)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (gameMode && menuMode) {
            val a = when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> "up"
                KeyEvent.KEYCODE_DPAD_DOWN -> "down"
                KeyEvent.KEYCODE_DPAD_LEFT -> "left"
                KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> "accept"
                KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_MODE, KeyEvent.KEYCODE_BUTTON_START,
                KeyEvent.KEYCODE_ESCAPE -> "cancel"
                else -> null
            }
            if (a != null) {
                if (event.action == KeyEvent.ACTION_DOWN) channel?.invokeMethod("menuKey", a)
                return true
            }
            if (KeyEvent.isGamepadButton(event.keyCode)) return true
        }
        if (gameMode && event.keyCode == KeyEvent.KEYCODE_BUTTON_MODE) {
            // botão Guia/Xbox abre o menu rápido (quando o Android o entrega ao app)
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                keyState.fill(0.0)
                channel?.invokeMethod("gameMenu", null)
            }
            return true
        }
        if (gameMode) {
            val i = padIndex(event.keyCode)
            if (i >= 0) {
                val src = event.source
                val isDpad = i in 12..15
                val fromPad = !isDpad || has(src, InputDevice.SOURCE_GAMEPAD) ||
                    has(src, InputDevice.SOURCE_DPAD) || (src and InputDevice.SOURCE_CLASS_JOYSTICK) != 0
                if (fromPad) {
                    lastPadId = event.deviceId
                    // também entrega o evento real à WebView: o Gamepad API nativo do Chromium só
                    // enxerga o controle se a WebView receber esses eventos
                    try { gameWv?.dispatchKeyEvent(event) } catch (_: Throwable) {}
                    when (event.action) {
                        KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) { keyState[i] = 1.0; padChanged() }
                        KeyEvent.ACTION_UP -> { keyState[i] = 0.0; padChanged() }
                    }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (gameMode && menuMode && (ev.source and InputDevice.SOURCE_CLASS_JOYSTICK) != 0 &&
            ev.action == MotionEvent.ACTION_MOVE
        ) {
            val x = if (Math.abs(ev.getAxisValue(MotionEvent.AXIS_HAT_X)) > 0.5f)
                ev.getAxisValue(MotionEvent.AXIS_HAT_X) else ev.getAxisValue(MotionEvent.AXIS_X)
            val y = if (Math.abs(ev.getAxisValue(MotionEvent.AXIS_HAT_Y)) > 0.5f)
                ev.getAxisValue(MotionEvent.AXIS_HAT_Y) else ev.getAxisValue(MotionEvent.AXIS_Y)
            val d: String? = when {
                Math.abs(y) >= Math.abs(x) && y < -0.6f -> "up"
                Math.abs(y) >= Math.abs(x) && y > 0.6f -> "down"
                x < -0.6f -> "left"
                x > 0.6f -> "right"
                else -> null
            }
            if (d != lastMenuDir) {
                lastMenuDir = d
                if (d != null) channel?.invokeMethod("menuKey", d)
            }
            return true
        }
        if (gameMode && (ev.source and InputDevice.SOURCE_CLASS_JOYSTICK) != 0 &&
            ev.action == MotionEvent.ACTION_MOVE
        ) {
            lastPadId = ev.deviceId
            try { gameWv?.dispatchGenericMotionEvent(ev) } catch (_: Throwable) {}
            val dev = ev.device
            fun has(axis: Int) = dev?.getMotionRange(axis, ev.source) != null
            fun dz(v: Float) = if (Math.abs(v) < 0.1f) 0.0 else v.toDouble().coerceIn(-1.0, 1.0)
            // gatilho: converte a faixa do eixo (-1..1 ou 0..1) para 0..1
            fun trig(axis: Int): Double {
                val v = ev.getAxisValue(axis)
                val min = dev?.getMotionRange(axis, ev.source)?.min ?: 0f
                return (if (min < 0f) (v + 1f) / 2f else v).toDouble().coerceIn(0.0, 1.0)
            }

            axes[0] = dz(ev.getAxisValue(MotionEvent.AXIS_X))
            axes[1] = dz(ev.getAxisValue(MotionEvent.AXIS_Y))

            val newStyle = has(MotionEvent.AXIS_LTRIGGER) || has(MotionEvent.AXIS_RTRIGGER) ||
                has(MotionEvent.AXIS_BRAKE) || has(MotionEvent.AXIS_GAS)
            val oldStyle = !newStyle && has(MotionEvent.AXIS_Z) && has(MotionEvent.AXIS_RZ) &&
                has(MotionEvent.AXIS_RX) && has(MotionEvent.AXIS_RY)
            if (newStyle) {
                // Xbox / PS4 recentes: analógico direito em Z/RZ, gatilhos em LTRIGGER/RTRIGGER (ou BRAKE/GAS)
                axes[2] = dz(ev.getAxisValue(MotionEvent.AXIS_Z))
                axes[3] = dz(ev.getAxisValue(MotionEvent.AXIS_RZ))
                hatState[6] = maxOf(
                    if (has(MotionEvent.AXIS_LTRIGGER)) trig(MotionEvent.AXIS_LTRIGGER) else 0.0,
                    if (has(MotionEvent.AXIS_BRAKE)) trig(MotionEvent.AXIS_BRAKE) else 0.0)
                hatState[7] = maxOf(
                    if (has(MotionEvent.AXIS_RTRIGGER)) trig(MotionEvent.AXIS_RTRIGGER) else 0.0,
                    if (has(MotionEvent.AXIS_GAS)) trig(MotionEvent.AXIS_GAS) else 0.0)
            } else if (oldStyle) {
                // PS3/PS4 antigos: analógico direito em Z/RZ, gatilhos analógicos em RX/RY
                axes[2] = dz(ev.getAxisValue(MotionEvent.AXIS_Z))
                axes[3] = dz(ev.getAxisValue(MotionEvent.AXIS_RZ))
                hatState[6] = trig(MotionEvent.AXIS_RX)
                hatState[7] = trig(MotionEvent.AXIS_RY)
            } else {
                // controles simples: analógico direito em RX/RY (ou Z/RZ), gatilhos só como botão
                val useRx = has(MotionEvent.AXIS_RX) && has(MotionEvent.AXIS_RY)
                axes[2] = dz(ev.getAxisValue(if (useRx) MotionEvent.AXIS_RX else MotionEvent.AXIS_Z))
                axes[3] = dz(ev.getAxisValue(if (useRx) MotionEvent.AXIS_RY else MotionEvent.AXIS_RZ))
            }

            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            hatState[12] = if (hy < -0.5f) 1.0 else 0.0
            hatState[13] = if (hy > 0.5f) 1.0 else 0.0
            hatState[14] = if (hx < -0.5f) 1.0 else 0.0
            hatState[15] = if (hx > 0.5f) 1.0 else 0.0
            padChanged()
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // usa a área do recorte (notch/câmera) também, sem faixa preta nas laterais
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ryzen/native")
        channel!!.setMethodCallHandler { call, result ->
                when (call.method) {
                    "docScript" -> {
                        val ok = try { setDocScript(call.arguments as? String) } catch (_: Throwable) { false }
                        result.success(ok)
                    }
                    "gameMode" -> {
                        gameMode = call.arguments as? Boolean ?: false
                        padResetAll()
                        setWifiLock(gameMode)
                        setGameDisplay(gameMode)
                        runOnUiThread {
                            if (gameMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                        result.success(true)
                    }
                    "menuMode" -> {
                        menuMode = call.arguments as? Boolean ?: false
                        lastMenuDir = null
                        if (menuMode) { keyState.fill(0.0); hatState.fill(0.0); axes.fill(0.0); padChanged() }
                        result.success(true)
                    }
                    "rumble" -> {
                        val m = call.arguments as? Map<*, *>
                        rumble((m?.get("ms") as? Number)?.toInt() ?: 0, (m?.get("amp") as? Number)?.toInt() ?: 128)
                        result.success(true)
                    }
                    "padInfo" -> result.success(padInfo())
                    "setBrightness" -> {
                        setBrightness((call.arguments as? Number)?.toInt() ?: -1)
                        result.success(true)
                    }
                    "getBrightness" -> result.success(getBrightness())
                    "listApps" -> Thread {
                        val list = listApps()
                        runOnUiThread { result.success(list) }
                    }.start()
                    "launch" -> {
                        val pkg = call.arguments as? String
                        val intent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                        if (intent != null) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "battery" -> result.success(battery())
                    "status" -> result.success(status())
                    "setVolume" -> {
                        setVolume((call.arguments as? Int) ?: 0)
                        result.success(true)
                    }
                    "toggleMute" -> {
                        toggleMute()
                        result.success(true)
                    }
                    "openSettings" -> result.success(openSettings(call.arguments as? String))
                    "openUrl" -> result.success(openUrl(call.arguments as? String))
                    "openStore" -> result.success(openStore(call.arguments as? String))
                    "perm" -> requestPerm(call.arguments as? String ?: "", result)
                    "wifiScan" -> wifiScan(result)
                    "btBonded" -> result.success(btBonded())
                    "btDiscover" -> btDiscover(result)
                    "btPair" -> result.success(btPair(call.arguments as? String))
                    else -> result.notImplemented()
                }
            }
    }

    // ---------- vibração do controle, bateria do controle e brilho ----------
    @Suppress("DEPRECATION")
    private fun rumble(ms: Int, amp: Int) {
        try {
            val dev = if (lastPadId >= 0) InputDevice.getDevice(lastPadId) else null
            var vib: Vibrator? = dev?.vibrator
            if (vib == null || !vib.hasVibrator()) vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vib == null) return
            if (ms <= 0) { vib.cancel(); return }
            val d = ms.coerceIn(1, 5000).toLong()
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(d, amp.coerceIn(1, 255)))
            else vib.vibrate(d)
        } catch (e: Exception) {
        }
    }

    private fun padInfo(): Map<String, Any> {
        try {
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                if (d.isVirtual) continue
                if (has(d.sources, InputDevice.SOURCE_GAMEPAD) || has(d.sources, InputDevice.SOURCE_JOYSTICK)) {
                    var bat = -1
                    if (Build.VERSION.SDK_INT >= 31) {
                        try {
                            val b = d.batteryState
                            if (b.isPresent && !b.capacity.isNaN()) bat = Math.round(b.capacity * 100)
                        } catch (e: Exception) {
                        }
                    }
                    return mapOf("connected" to true, "name" to (d.name ?: ""), "battery" to bat)
                }
            }
        } catch (e: Exception) {
        }
        return mapOf("connected" to false, "name" to "", "battery" to -1)
    }

    private fun setBrightness(pct: Int) {
        runOnUiThread {
            val lp = window.attributes
            lp.screenBrightness = if (pct < 0) -1f else (pct / 100f).coerceIn(0.02f, 1f)
            window.attributes = lp
        }
    }

    private fun getBrightness(): Int {
        val w = window.attributes.screenBrightness
        if (w >= 0f) return Math.round(w * 100)
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255
        } catch (e: Exception) {
            50
        }
    }

    private fun listApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                mapOf(
                    "name" to it.loadLabel(pm).toString(),
                    "package" to it.activityInfo.packageName,
                    "icon" to iconBytes(it.loadIcon(pm))
                )
            }
            .sortedBy { (it["name"] as String).lowercase() }
    }

    private fun iconBytes(d: Drawable): ByteArray? {
        return try {
            val size = 192
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            d.setBounds(0, 0, size, size)
            d.draw(canvas)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    // ---------- links e Play Store (jogos na nuvem) ----------
    private fun openUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url.trim())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openStore(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        return openUrl("market://details?id=$pkg") || openUrl("https://play.google.com/store/apps/details?id=$pkg")
    }

    // ---------- permissões ----------
    private var pendingPerm: MethodChannel.Result? = null

    private fun permsFor(kind: String): List<String> = when (kind) {
        "wifi" -> listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        "mic" -> listOf(Manifest.permission.RECORD_AUDIO)
        "bt" -> if (Build.VERSION.SDK_INT >= 31)
            listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        else -> emptyList()
    }

    private fun hasPerms(kind: String) =
        permsFor(kind).all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestPerm(kind: String, result: MethodChannel.Result) {
        val missing = permsFor(kind).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            result.success(true)
            return
        }
        pendingPerm?.success(false)
        pendingPerm = result
        requestPermissions(missing.toTypedArray(), 4242)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4242) {
            pendingPerm?.success(grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
            pendingPerm = null
        }
    }

    // ---------- lista de redes Wi-Fi ----------
    private fun wifiItems(wm: WifiManager): List<Map<String, Any>> {
        val res = try { wm.scanResults } catch (e: Exception) { emptyList() }
        @Suppress("DEPRECATION")
        val cur = try { wm.connectionInfo?.ssid?.trim('"') ?: "" } catch (e: Exception) { "" }
        val best = LinkedHashMap<String, android.net.wifi.ScanResult>()
        for (r in res) {
            @Suppress("DEPRECATION")
            val name = r.SSID ?: ""
            if (name.isBlank()) continue
            val old = best[name]
            if (old == null || r.level > old.level) best[name] = r
        }
        return best.map { (name, r) ->
            @Suppress("DEPRECATION")
            val lvl = WifiManager.calculateSignalLevel(r.level, 5)
            val caps = r.capabilities ?: ""
            mapOf(
                "ssid" to name,
                "level" to lvl,
                "secure" to (caps.contains("WPA") || caps.contains("WEP") || caps.contains("SAE") || caps.contains("EAP")),
                "connected" to (name == cur)
            )
        }.sortedWith(compareByDescending<Map<String, Any>> { it["connected"] as Boolean }
            .thenByDescending { it["level"] as Int })
    }

    private fun wifiScan(result: MethodChannel.Result) {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        fun reply(state: String, items: List<Map<String, Any>> = emptyList()) =
            result.success(mapOf("state" to state, "items" to items))
        if (!wm.isWifiEnabled) return reply("off")
        if (!hasPerms("wifi")) return reply("noperm")
        if (Build.VERSION.SDK_INT >= 28) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (!lm.isLocationEnabled) return reply("nolocation")
        }
        var done = false
        lateinit var rcv: BroadcastReceiver
        fun finish() {
            if (done) return
            done = true
            try { unregisterReceiver(rcv) } catch (e: Exception) { }
            reply("ok", wifiItems(wm))
        }
        rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) = finish()
        }
        registerReceiver(rcv, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 6000)
        @Suppress("DEPRECATION")
        val started = try { wm.startScan() } catch (e: Exception) { false }
        if (!started) finish() // limite de varreduras do Android: usa o resultado em cache
    }

    // ---------- dispositivos Bluetooth ----------
    private fun btDev(d: BluetoothDevice, extraName: String? = null): Map<String, Any> {
        val n = try { d.name } catch (e: Exception) { null } ?: extraName
        val bonded = try { d.bondState == BluetoothDevice.BOND_BONDED } catch (e: Exception) { false }
        return mapOf("name" to (n ?: ""), "address" to d.address, "paired" to bonded)
    }

    private fun btBonded(): Map<String, Any> {
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) return mapOf("state" to "off", "items" to emptyList<Any>())
        if (!hasPerms("bt")) return mapOf("state" to "noperm", "items" to emptyList<Any>())
        val items = try { ad.bondedDevices.map { btDev(it) } } catch (e: Exception) { emptyList() }
        return mapOf("state" to "ok", "items" to items)
    }

    @Suppress("DEPRECATION")
    private fun btFrom(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun btDiscover(result: MethodChannel.Result) {
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        fun reply(state: String, items: Collection<Map<String, Any>> = emptyList()) =
            result.success(mapOf("state" to state, "items" to items.toList()))
        if (ad == null || !ad.isEnabled) return reply("off")
        if (!hasPerms("bt")) return reply("noperm")
        val found = LinkedHashMap<String, Map<String, Any>>()
        try { ad.bondedDevices.forEach { found[it.address] = btDev(it) } } catch (e: Exception) { }
        var done = false
        lateinit var rcv: BroadcastReceiver
        fun finish() {
            if (done) return
            done = true
            try { unregisterReceiver(rcv) } catch (e: Exception) { }
            try { ad.cancelDiscovery() } catch (e: Exception) { }
            reply("ok", found.values.sortedWith(
                compareByDescending<Map<String, Any>> { it["paired"] as Boolean }
                    .thenBy { (it["name"] as String).lowercase() }))
        }
        rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                when (i.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d = btFrom(i) ?: return
                        found[d.address] = btDev(d, i.getStringExtra(BluetoothDevice.EXTRA_NAME))
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> finish()
                }
            }
        }
        val f = IntentFilter(BluetoothDevice.ACTION_FOUND)
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        registerReceiver(rcv, f)
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 14000)
        val ok = try { ad.cancelDiscovery(); ad.startDiscovery() } catch (e: Exception) { false }
        if (!ok) finish()
    }

    private fun btPair(address: String?): Boolean {
        return try {
            val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ad.cancelDiscovery()
            ad.getRemoteDevice(address).createBond()
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Wi-Fi / Bluetooth / volume ----------
    private fun status(): Map<String, Any> {
        var wifiEnabled = false
        var wifiConnected = false
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiEnabled = wm.isWifiEnabled
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            wifiConnected = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (e: Exception) {
        }
        var bt = false
        try {
            val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            bt = bm.adapter?.isEnabled == true
        } catch (e: Exception) {
        }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val muted = if (Build.VERSION.SDK_INT >= 23) am.isStreamMute(AudioManager.STREAM_MUSIC) else cur == 0
        return mapOf(
            "wifiEnabled" to wifiEnabled,
            "wifiConnected" to (wifiEnabled && wifiConnected),
            "bt" to bt,
            "volume" to (cur * 100 / max),
            "muted" to muted
        )
    }

    private fun setVolume(pct: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val v = Math.round(pct.coerceIn(0, 100) * max / 100f)
            if (Build.VERSION.SDK_INT >= 23 && am.isStreamMute(AudioManager.STREAM_MUSIC) && v > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
        } catch (e: Exception) {
        }
    }

    private fun toggleMute() {
        try {
            if (Build.VERSION.SDK_INT < 23) return
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val dir = if (am.isStreamMute(AudioManager.STREAM_MUSIC)) AudioManager.ADJUST_UNMUTE
            else AudioManager.ADJUST_MUTE
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
        } catch (e: Exception) {
        }
    }

    private fun openSettings(what: String?): Boolean {
        val actions = when (what) {
            "wifi" -> if (Build.VERSION.SDK_INT >= 29)
                listOf(Settings.Panel.ACTION_INTERNET_CONNECTIVITY, Settings.ACTION_WIFI_SETTINGS)
            else listOf(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> listOf(Settings.ACTION_BLUETOOTH_SETTINGS)
            "sound" -> listOf(Settings.ACTION_SOUND_SETTINGS)
            else -> return false
        }
        for (a in actions) {
            try {
                startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) {
            }
        }
        return false
    }

    private fun battery(): Map<String, Any> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return mapOf("percent" to pct, "charging" to charging)
    }
}
