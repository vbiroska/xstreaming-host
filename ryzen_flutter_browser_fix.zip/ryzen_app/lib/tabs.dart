import 'package:flutter/material.dart';

import 'covers.dart';
import 'i18n.dart';
import 'state.dart';
import 'ui.dart';

Widget _emptyState(BuildContext c, {bool fav = false}) => Center(
      child: GestureDetector(
        onTap: fav ? null : st.openGames,
        child: Text(
          tr(fav
              ? 'Nenhum favorito ainda.\nSelecione um jogo e aperte X para favoritar.'
              : 'Nenhum jogo selecionado.\nToque aqui ou vá em Config › Meus jogos.'),
          textAlign: TextAlign.center,
          style: ts(c, 24, color: st.subTxt),
        ),
      ),
    );

// ============================ INÍCIO ============================
class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final hc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    hc.dispose();
    super.dispose();
  }

  Widget _featCard(BuildContext context) {
    final s = context.s;
    final fi = st.featStore;
    final items = st.featItems;
    final title = fi < 0 ? 'Ryzen' : storeTitles[fi];
    final banner = fi < 0 ? null : st.featBanner(fi);
    // com todos os jogos da Loja no carrossel, mostra só 7 pontinhos (janela em volta do atual)
    final pos = items.indexOf(fi);
    final dotFrom = pos < 0 ? 0 : (pos - 3).clamp(0, (items.length - 7).clamp(0, items.length).toInt()).toInt();
    final dotTo = (dotFrom + 7 > items.length) ? items.length : dotFrom + 7;
    return Stack(fit: StackFit.expand, children: [
      Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1C2236), Color(0xFF4A63D6)],
          ),
        ),
      ),
      if (banner != null)
        Image(image: banner, fit: BoxFit.cover, alignment: Alignment.center, gaplessPlayback: true),
      if (banner == null && st.bannerInfo.isNotEmpty)
        Positioned(
          left: 24 * s,
          bottom: 6 * s,
          right: 220 * s,
          child: GestureDetector(
            onTap: () => st.fetchBanners(force: true),
            child: Text(st.bannerInfo,
                maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 13, color: const Color(0xCCFFFFFF))),
          ),
        ),
      // leitura do texto à esquerda e rodapé
      Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xCC0B1230), Color(0x00000000)],
            stops: [0.0, 0.7],
          ),
        ),
      ),
      Positioned(
        left: 24 * s,
        top: 22 * s,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 6 * s),
          decoration: BoxDecoration(color: const Color(0xFF3B4FE0), borderRadius: BorderRadius.circular(20 * s)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            SysIcon('gamepad', 24, white: true),
            SizedBox(width: 8 * s),
            Text(tr('Jogo em destaque'), style: ts(context, 18, color: Colors.white, bold: true)),
          ]),
        ),
      ),
      Positioned(
        left: 24 * s,
        top: 76 * s,
        width: 520 * s,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: ts(context, 54, color: Colors.white, bold: true)),
          SizedBox(height: 8 * s),
          Text(tr('Jogue na nuvem, sem instalar nada.'), style: ts(context, 22, color: Colors.white)),
        ]),
      ),
      Positioned(
        left: 24 * s,
        top: 226 * s,
        child: Row(children: [
          GestureDetector(
            onTap: st.featPlay,
            child: Container(
              width: 240 * s,
              height: 56 * s,
              decoration: BoxDecoration(
                color: const Color(0x33FFFFFF),
                borderRadius: BorderRadius.circular(28 * s),
                border: Border.all(color: const Color(0x55FFFFFF)),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SysIcon('play', 24, white: true),
                SizedBox(width: 10 * s),
                Text(tr('Jogar agora'), style: ts(context, 22, color: Colors.white)),
              ]),
            ),
          ),
          SizedBox(width: 12 * s),
          GestureDetector(
            onTap: () => st.setTab(2),
            child: Container(
              width: 56 * s,
              height: 56 * s,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0x33FFFFFF),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0x55FFFFFF)),
              ),
              child: Text('•••', style: ts(context, 20, color: Colors.white, bold: true)),
            ),
          ),
        ]),
      ),
      // pontinhos do carrossel
      Positioned(
        right: 20 * s,
        bottom: 16 * s,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 8 * s),
          decoration: BoxDecoration(color: const Color(0x55000000), borderRadius: BorderRadius.circular(20 * s)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            for (var k = dotFrom; k < dotTo; k++)
              GestureDetector(
                onTap: () => st.featSet(k),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: EdgeInsets.symmetric(horizontal: 4 * s),
                  width: (items[k] == fi ? 28 : 10) * s,
                  height: 10 * s,
                  decoration: BoxDecoration(
                    color: items[k] == fi ? Colors.white : const Color(0x88FFFFFF),
                    borderRadius: BorderRadius.circular(5 * s),
                  ),
                ),
              ),
          ]),
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final items = st.recentItems;
    final last = st.lastItem;
    if (_last != st.homeIdx) {
      _last = st.homeIdx;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(hc, st.homeIdx * 284 * s, 284 * s));
    }
    return Stack(children: [
      // Banner em destaque: passa os jogos da Loja (banner buscado na web)
      Positioned(
        left: 25 * s,
        top: 16 * s,
        right: (25 + 590 + 20) * s,
        height: 300 * s,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22 * s),
          child: GestureDetector(
            onHorizontalDragEnd: (d) {
              final v = d.primaryVelocity ?? 0;
              if (v < -200) st.featMove(1);
              if (v > 200) st.featMove(-1);
            },
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 600),
              child: KeyedSubtree(key: ValueKey('feat${st.featStore}'), child: _featCard(context)),
            ),
          ),
        ),
      ),
      // Último jogo
      Positioned(
        right: 25 * s,
        top: 16 * s,
        width: 590 * s,
        height: 300 * s,
        child: Glass(
          radius: 22 * s,
          child: Stack(children: [
            Positioned(left: 28 * s, top: 18 * s, child: Text(tr('Último Jogo'), style: ts(context, 25))),
            Positioned(
              left: 20 * s,
              top: 56 * s,
              width: 240 * s,
              height: 232 * s,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12 * s),
                child: Container(
                  color: st.dark ? const Color(0x26FFFFFF) : const Color(0x1F000000),
                  child: last == null
                      ? null
                      : Art(
                          img: st.itemImage(last),
                          fit: last.isStore ? BoxFit.cover : st.fitForApp(last.app!),
                          title: last.title),
                ),
              ),
            ),
            Positioned(
              left: 285 * s,
              top: 70 * s,
              width: 285 * s,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(last?.title ?? '—', maxLines: 3, overflow: TextOverflow.ellipsis, style: ts(context, 28)),
                SizedBox(height: 14 * s),
                Row(children: [
                  SysIcon('clock', 24),
                  SizedBox(width: 8 * s),
                  Text('${tr('Tempo jogado')}: ${st.hours(last)}', style: ts(context, 19)),
                ]),
              ]),
            ),
            Positioned(
              left: 300 * s,
              top: 222 * s,
              child: GestureDetector(
                onTap: () {
                  if (last != null) {
                    st.sfx('ok');
                    st.continueItem(last);
                  }
                },
                child: Container(
                  width: 250 * s,
                  height: 56 * s,
                  decoration: BoxDecoration(color: st.pill, borderRadius: BorderRadius.circular(28 * s)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SysIcon('play', 24),
                    SizedBox(width: 10 * s),
                    Text(tr('Continuar'), style: ts(context, 22, bold: true)),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
      // Destaques
      Positioned(
        left: 40 * s,
        top: 330 * s,
        child: Row(children: [
          SysIcon('gamepad', 38),
          SizedBox(width: 14 * s),
          Text(tr('Últimos Jogos'), style: ts(context, 26, bold: true)),
        ]),
      ),
      Positioned(
        right: 30 * s,
        top: 336 * s,
        child: GestureDetector(
          onTap: () => st.setTab(1),
          child: Row(children: [
            Text(tr('Ver Todos'), style: ts(context, 20)),
            SizedBox(width: 8 * s),
            SysIcon('arrow-right', 24),
          ]),
        ),
      ),
      Positioned(
        left: 30 * s,
        top: 384 * s,
        right: 20 * s,
        height: 335 * s,
        child: items.isEmpty
            ? _emptyState(context)
            : ListView.builder(
                controller: hc,
                scrollDirection: Axis.horizontal,
                itemExtent: 284 * s,
                itemCount: items.length,
                itemBuilder: (c, i) => GestureDetector(
                  onTap: () => st.tapHome(i),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: SizedBox(
                      width: 256 * s,
                      height: 310 * s,
                      child: itemTile(c, items[i], i == st.homeIdx, frosted: true, radius: 16, margin: 8),
                    ),
                  ),
                ),
              ),
      ),
    ]);
  }
}

// ============================ BIBLIOTECA ============================
class LibraryTab extends StatefulWidget {
  const LibraryTab({super.key});
  @override
  State<LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends State<LibraryTab> {
  final gc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    gc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final items = st.libItems;
    return Padding(
      padding: EdgeInsets.fromLTRB(30 * s, 14 * s, 30 * s, 30 * s),
      child: Column(children: [
        _filterChips(context),
        SizedBox(height: 10 * s),
        Expanded(
          child: items.isEmpty
          ? _emptyState(context, fav: st.libFilter == 1)
          : LayoutBuilder(builder: (ctx, c) {
              final cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
              st.libCols = cols;
              final cellH = c.maxWidth / cols * 300 / 235;
              if (_last != st.libIdx) {
                _last = st.libIdx;
                WidgetsBinding.instance
                    .addPostFrameCallback((_) => followIndex(gc, (st.libIdx ~/ cols) * cellH, cellH));
              }
              return GridView.builder(
                controller: gc,
                padding: EdgeInsets.zero,
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 235 * s,
                  childAspectRatio: 235 / 300,
                ),
                itemCount: items.length,
                itemBuilder: (c2, i) => GestureDetector(
                  onTap: () => st.tapLib(i),
                  child: FractionallySizedBox(
                    widthFactor: 205 / 235,
                    heightFactor: 270 / 300,
                    child: itemTile(c2, items[i], i == st.libIdx, frosted: false, radius: 14, margin: 8),
                  ),
                ),
              );
            }),
        ),
      ]),
    );
  }

  Widget _filterChips(BuildContext c) {
    final s = c.s;
    return SizedBox(
      height: 56 * s,
      child: Row(children: [
        Text('L2', style: ts(c, 18, color: st.subTxt)),
        SizedBox(width: 10 * s),
        for (var i = 0; i < libFilters.length; i++)
          GestureDetector(
            onTap: () => st.setFilter(i - st.libFilter),
            child: Container(
              height: 44 * s,
              padding: EdgeInsets.symmetric(horizontal: 22 * s),
              margin: EdgeInsets.only(right: 10 * s),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: st.libFilter == i ? st.accent : Colors.transparent,
                borderRadius: BorderRadius.circular(22 * s),
                border: Border.all(color: st.accent, width: 2 * s),
              ),
              child: Text(tr(libFilters[i]),
                  style: ts(c, 20, color: st.libFilter == i ? Colors.white : st.txt)),
            ),
          ),
        SizedBox(width: 4 * s),
        Text('R2', style: ts(c, 18, color: st.subTxt)),
      ]),
    );
  }
}

// ============================ LOJA ============================
class StoreTab extends StatefulWidget {
  const StoreTab({super.key});
  @override
  State<StoreTab> createState() => _StoreTabState();
}

class _StoreTabState extends State<StoreTab> {
  final gc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    gc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Stack(children: [
      Positioned.fill(child: _grid(context)),
      if (st.covInfo.isNotEmpty)
        Positioned(
          left: 30 * s,
          bottom: 4 * s,
          child: GestureDetector(
            onTap: () => st.fetchStoreCovers(force: true),
            child: Text(st.covInfo, style: ts(context, 14, color: st.subTxt)),
          ),
        ),
    ]);
  }

  Widget _grid(BuildContext context) {
    final s = context.s;
    return Padding(
      padding: EdgeInsets.all(30 * s),
      child: LayoutBuilder(builder: (ctx, c) {
        final cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
        st.storeCols = cols;
        final cellH = c.maxWidth / cols * 335 / 235;
        if (_last != st.storeIdx) {
          _last = st.storeIdx;
          WidgetsBinding.instance
              .addPostFrameCallback((_) => followIndex(gc, (st.storeIdx ~/ cols) * cellH, cellH));
        }
        return GridView.builder(
          controller: gc,
          padding: EdgeInsets.zero,
          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 235 * s,
            childAspectRatio: 235 / 335,
          ),
          itemCount: storeTitles.length,
          itemBuilder: (c2, i) => GestureDetector(
            onTap: () => st.tapStore(i),
            onLongPress: () => showStoreMenu(c2, i),
            child: FractionallySizedBox(
              widthFactor: 205 / 235,
              heightFactor: 300 / 335,
              child: AnimatedScale(
                scale: i == st.storeIdx ? 1.05 : 1.0,
                duration: const Duration(milliseconds: 120),
                child: Glass(
                  radius: 14 * s,
                  frosted: false,
                  border: i == st.storeIdx ? Colors.white : st.tileEdge,
                  borderWidth: i == st.storeIdx ? 4 * s : 1,
                  child: Stack(children: [
                    Padding(
                      padding: EdgeInsets.all(6 * s),
                      child: Art(img: st.storeImage(i), fit: BoxFit.cover, title: storeTitles[i]),
                    ),
                    if (st.pinned.contains(storeTitles[i]))
                      Positioned(top: 10 * s, right: 10 * s, child: starBadge(s)),
                  ]),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

// ============================ CONFIG ============================
class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final lc = ScrollController();
  int _last = -1, _lastCat = -1;

  @override
  void dispose() {
    lc.dispose();
    super.dispose();
  }

  Widget _control(BuildContext context, SetRow r) {
    final s = context.s;
    switch (r.kind) {
      case 'choice':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < r.options.length; i++) ...[
            if (i > 0) SizedBox(width: 8 * s),
            GestureDetector(
              onTap: () => st.setChoice(r.key, i),
              child: Container(
                width: 110 * s,
                height: 46 * s,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: st.choiceValue(r.key!) == i ? st.accent : Colors.transparent,
                  borderRadius: BorderRadius.circular(23 * s),
                  border: Border.all(color: st.accent, width: 2 * s),
                ),
                child: Text(tr(r.options[i]),
                    style: ts(context, 20, color: st.choiceValue(r.key!) == i ? Colors.white : st.txt)),
              ),
            ),
          ],
        ]);
      case 'wall':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(onTap: () => st.changeWall(-1), child: SysIcon('back', 28)),
          SizedBox(width: 12 * s),
          SizedBox(
            width: 330 * s,
            child: Text('${st.wallName}  (${st.wallIndex + 1}/${st.wallOptions.length})',
                textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 20)),
          ),
          SizedBox(width: 12 * s),
          GestureDetector(onTap: () => st.changeWall(1), child: SysIcon('arrow-right', 28)),
        ]);
      case 'cloud':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(onTap: () => st.changeRow(settingRows.indexOf(r), -1), child: SysIcon('back', 28)),
          SizedBox(width: 12 * s),
          SizedBox(
            width: 260 * s,
            child: Text(cloudServices[st.cloudService].name,
                textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 20)),
          ),
          SizedBox(width: 12 * s),
          GestureDetector(onTap: () => st.changeRow(settingRows.indexOf(r), 1), child: SysIcon('arrow-right', 28)),
        ]);
      case 'sys':
        return PillBtn(r.key == 'wifi' ? tr('Ver redes') : tr('Dispositivos'), () => st.changeRow(settingRows.indexOf(r), 0));
      case 'volume':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(onTap: () => st.adjustVolume(-1), child: SysIcon('back', 28)),
          SizedBox(width: 12 * s),
          SizedBox(
            width: 90 * s,
            child: Text(st.muted ? tr('Mudo') : (st.volumePct < 0 ? '--' : '${st.volumePct}%'),
                textAlign: TextAlign.center, style: ts(context, 20)),
          ),
          SizedBox(width: 12 * s),
          GestureDetector(onTap: () => st.adjustVolume(1), child: SysIcon('arrow-right', 28)),
          SizedBox(width: 12 * s),
          PillBtn(st.muted ? tr('Som') : tr('Mudo'), st.toggleMute, filled: false),
        ]);
      case 'games':
        return PillBtn(tr('Escolher'), st.openGames);
      case 'padtest':
        return PillBtn(tr('Testar'), st.openPadTest);
      case 'profile':
        return PillBtn(tr('Abrir'), st.openProfile);
      case 'gameicons':
      case 'storeicons':
        return PillBtn(tr('Editar'), () => st.changeRow(settingRows.indexOf(r), 0));
      case 'pickvideo':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          PillBtn(tr('Escolher'), st.pickVideoWall),
          if (st.videoWall != null) ...[
            SizedBox(width: 8 * s),
            PillBtn(tr('Remover'), st.removeVideoWall, filled: false),
          ],
        ]);
      case 'pick':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          PillBtn(tr('Escolher'), st.pickWall),
          if (st.wallIsCustom) ...[
            SizedBox(width: 8 * s),
            PillBtn(tr('Remover'), st.removeCurrentWall, filled: false),
          ],
        ]);
      default:
        final on = st.toggleValue(r.key!);
        return GestureDetector(
          onTap: () => st.toggle(r.key!),
          child: Container(
            width: 84 * s,
            height: 44 * s,
            decoration: BoxDecoration(
              color: on ? st.accent : const Color(0xFF8A90A8),
              borderRadius: BorderRadius.circular(22 * s),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 120),
              alignment: on ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                margin: EdgeInsets.all(4 * s),
                width: 36 * s,
                height: 36 * s,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              ),
            ),
          ),
        );
    }
  }

  Widget _sidebar(BuildContext context) {
    final s = context.s;
    return Column(children: [
      for (var c = 0; c < settingCats.length; c++)
        Padding(
          padding: EdgeInsets.only(bottom: 10 * s),
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => st.tapCat(c),
            child: Builder(builder: (context) {
              final cur = c == st.setCat;
              final focus = cur && st.setSide;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 140),
                height: 76 * s,
                padding: EdgeInsets.symmetric(horizontal: 24 * s),
                decoration: BoxDecoration(
                  color: focus ? st.accent : (cur ? st.selRow : Colors.transparent),
                  borderRadius: BorderRadius.circular(18 * s),
                  border: Border.all(color: cur && !focus ? st.accent : Colors.transparent, width: 2 * s),
                  boxShadow: focus
                      ? [BoxShadow(color: st.accent.withValues(alpha: 0.5), blurRadius: 24 * s)]
                      : const [],
                ),
                child: Row(children: [
                  SysIcon(settingCats[c].icon, 34, white: focus),
                  SizedBox(width: 22 * s),
                  Expanded(
                    child: Text(tr(settingCats[c].title),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: ts(context, 26, color: focus ? Colors.white : st.txt, bold: focus)),
                  ),
                  SysIcon('arrow-right', 24, white: focus),
                ]),
              );
            }),
          ),
        ),
    ]);
  }

  Widget _panel(BuildContext context, SetCat cat) {
    final s = context.s;
    final rows = cat.rows;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          width: 84 * s,
          height: 84 * s,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: st.glass, shape: BoxShape.circle, border: Border.all(color: st.tileEdge)),
          child: SysIcon(cat.icon, 44),
        ),
        SizedBox(width: 26 * s),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(tr(cat.title), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 40, bold: true)),
            SizedBox(height: 4 * s),
            Text(tr(cat.sub), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 20, color: st.subTxt)),
          ]),
        ),
      ]),
      SizedBox(height: 22 * s),
      Expanded(
        child: ListView.builder(
          controller: lc,
          padding: EdgeInsets.zero,
          itemExtent: 100 * s,
          itemCount: rows.length,
          itemBuilder: (c, k) {
            final i = rows[k];
            final r = settingRows[i];
            final cur = i == st.setIdx && !st.setSide;
            return Padding(
              padding: EdgeInsets.only(bottom: 10 * s),
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => st.tapRow(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 140),
                  decoration: BoxDecoration(
                    color: cur ? st.selRow : st.glass,
                    borderRadius: BorderRadius.circular(18 * s),
                    border: Border.all(color: cur ? st.accent : st.tileEdge, width: cur ? 3 * s : 1),
                  ),
                  child: Row(children: [
                    SizedBox(width: 24 * s),
                    SysIcon(r.icon, 34),
                    SizedBox(width: 22 * s),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tr(r.title), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 24)),
                          SizedBox(height: 3 * s),
                          Text(st.subText(i),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: ts(context, 16, color: st.subTxt)),
                        ],
                      ),
                    ),
                    _control(context, r),
                    SizedBox(width: 24 * s),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final cat = settingCats[st.setCat];
    final pos = cat.rows.indexOf(st.setIdx);
    if (_lastCat != st.setCat) {
      _lastCat = st.setCat;
      _last = -1;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (lc.hasClients) lc.jumpTo(0);
      });
    }
    if (_last != st.setIdx) {
      _last = st.setIdx;
      if (pos >= 0 && !st.setSide) {
        WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(lc, pos * 100 * s, 100 * s));
      }
    }
    return Padding(
      padding: EdgeInsets.fromLTRB(44 * s, 12 * s, 44 * s, 8 * s),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 400 * s, child: _sidebar(context)),
        Container(
          width: 2 * s,
          margin: EdgeInsets.symmetric(horizontal: 32 * s),
          color: st.tileEdge,
        ),
        Expanded(child: _panel(context, cat)),
      ]),
    );
  }
}


/// Toque longo num jogo da Loja: fixar na tela inicial e definir o link do jogo.
Future<void> showStoreMenu(BuildContext context, int i) async {
  final t = storeTitles[i];
  final pinned = st.pinned.contains(t);
  final c = TextEditingController(text: st.storeLink(t));
  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(t),
      content: TextField(
        controller: c,
        keyboardType: TextInputType.url,
        decoration: const InputDecoration(
          labelText: 'Link do jogo (opcional)',
          helperText: 'Vazio: abre o serviço de nuvem escolhido em Config',
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            st.togglePin(t);
            Navigator.pop(ctx);
          },
          child: Text(pinned ? 'Desafixar' : 'Fixar na tela inicial'),
        ),
        TextButton(
          onPressed: () {
            st.setStoreLink(t, c.text);
            Navigator.pop(ctx);
          },
          child: const Text('Salvar link'),
        ),
      ],
    ),
  );
  c.dispose();
}
