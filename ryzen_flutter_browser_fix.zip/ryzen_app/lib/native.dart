import 'dart:typed_data';
import 'package:flutter/services.dart';

class AppInfo {
  final String name;
  final String package;
  final Uint8List? icon;
  AppInfo(this.name, this.package, this.icon);
}

class BatteryInfo {
  final int percent;
  final bool charging;
  BatteryInfo(this.percent, this.charging);
}

class SysStatus {
  final bool wifiEnabled, wifiConnected, btOn, muted;
  final int volume; // 0-100
  SysStatus(this.wifiEnabled, this.wifiConnected, this.btOn, this.volume, this.muted);
}

class PadInfo {
  final bool connected;
  final String name;
  final int battery; // 0-100, -1 = desconhecida
  PadInfo(this.connected, this.name, this.battery);
}

class WifiNet {
  final String ssid;
  final int level; // 0-4
  final bool secure, connected;
  WifiNet(this.ssid, this.level, this.secure, this.connected);
}

class BtDev {
  final String name, address;
  final bool paired;
  BtDev(this.name, this.address, this.paired);
  String get label => name.isEmpty ? address : name;
}

/// state: ok | off | noperm | nolocation
class NetScan<T> {
  final String state;
  final List<T> items;
  NetScan(this.state, this.items);
}

/// Ponte com o Android (MainActivity.kt): lista apps, abre jogo e lê bateria.
class Native {
  static const _ch = MethodChannel('ryzen/native');

  /// Chamado quando o B do controle é pressionado com um jogo/link aberto.
  static void Function()? onGameBack;

  /// Estado do controle enquanto um jogo/link está aberto:
  /// 17 botões (padrão W3C: 0-3 A B X Y, 4-5 L1 R1, 6-7 L2 R2, 8 Select, 9 Start,
  /// 10-11 L3 R3, 12-15 direcional, 16 Guia) + 4 eixos (LX, LY, RX, RY).
  static void Function(List<double> state)? onPad;

  /// Botão Guia (ou SELECT+START segurados) com um jogo aberto: abre o menu rápido.
  static void Function()? onGameMenu;

  /// Navegação do menu rápido pelo controle: up, down, left, right, accept, cancel.
  static void Function(String key)? onMenuKey;
  static bool _handlerSet = false;

  static void _ensureHandler() {
    if (_handlerSet) return;
    _handlerSet = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'gameBack') onGameBack?.call();
      if (call.method == 'gameMenu') onGameMenu?.call();
      if (call.method == 'menuKey') onMenuKey?.call(call.arguments as String);
      if (call.method == 'pad') {
        final a = call.arguments;
        if (a is List) onPad?.call(a.map((e) => (e as num).toDouble()).toList());
      }
      return null;
    });
  }

  /// Liga/desliga a captura nativa do controle enquanto a WebView do jogo está aberta.
  static Future<void> setGameMode(bool on) async {
    _ensureHandler();
    try {
      await _ch.invokeMethod('gameMode', on);
    } catch (_) {}
  }

  /// Registra (ou remove, com null) um script que roda antes de qualquer script da página.
  static Future<bool> docScript(String? js) async {
    try {
      return await _ch.invokeMethod<bool>('docScript', js) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Com o menu rápido aberto, o controle navega o menu em vez de ir para o jogo.
  static Future<void> setMenuMode(bool on) async {
    _ensureHandler();
    try {
      await _ch.invokeMethod('menuMode', on);
    } catch (_) {}
  }

  /// Vibra o controle (ou o aparelho). ms <= 0 para parar.
  static Future<void> rumble(int ms, int amp) async {
    try {
      await _ch.invokeMethod('rumble', {'ms': ms, 'amp': amp});
    } catch (_) {}
  }

  static Future<PadInfo?> padInfo() async {
    try {
      final r = await _ch.invokeMethod<dynamic>('padInfo');
      if (r is! Map) return null;
      return PadInfo(r['connected'] as bool, r['name'] as String, r['battery'] as int);
    } catch (_) {
      return null;
    }
  }

  /// pct 5-100; -1 volta ao brilho do sistema.
  static Future<void> setBrightness(int pct) async {
    try {
      await _ch.invokeMethod('setBrightness', pct);
    } catch (_) {}
  }

  static Future<int> getBrightness() async {
    try {
      return await _ch.invokeMethod<int>('getBrightness') ?? 50;
    } catch (_) {
      return 50;
    }
  }

  static Future<List<AppInfo>> listApps() async {
    try {
      final r = await _ch.invokeListMethod<dynamic>('listApps') ?? [];
      return r.map((e) {
        final m = e as Map;
        return AppInfo(m['name'] as String, m['package'] as String, m['icon'] as Uint8List?);
      }).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<bool> launch(String pkg) async {
    try {
      return await _ch.invokeMethod<bool>('launch', pkg) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Abre um link (https://… ou esquema de app). false se nada abriu.
  static Future<bool> openUrl(String url) async {
    try {
      return await _ch.invokeMethod<bool>('openUrl', url) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openStore(String pkg) async {
    try {
      return await _ch.invokeMethod<bool>('openStore', pkg) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<SysStatus?> status() async {
    try {
      final r = await _ch.invokeMethod<dynamic>('status');
      if (r is! Map) return null;
      return SysStatus(r['wifiEnabled'] as bool, r['wifiConnected'] as bool, r['bt'] as bool,
          r['volume'] as int, r['muted'] as bool);
    } catch (_) {
      return null;
    }
  }

  static Future<void> setVolume(int pct) async {
    try {
      await _ch.invokeMethod('setVolume', pct);
    } catch (_) {}
  }

  static Future<void> toggleMute() async {
    try {
      await _ch.invokeMethod('toggleMute');
    } catch (_) {}
  }

  /// Pede as permissões do tipo 'wifi' ou 'bt'. true = todas concedidas.
  static Future<bool> perm(String kind) async {
    try {
      return await _ch.invokeMethod<bool>('perm', kind) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<NetScan<WifiNet>> wifiScan() async {
    try {
      final r = await _ch.invokeMethod<dynamic>('wifiScan') as Map;
      final items = (r['items'] as List)
          .map((e) {
            final m = e as Map;
            return WifiNet(m['ssid'] as String, m['level'] as int, m['secure'] as bool, m['connected'] as bool);
          })
          .toList();
      return NetScan(r['state'] as String, items);
    } catch (_) {
      return NetScan('error', []);
    }
  }

  static NetScan<BtDev> _bt(dynamic raw) {
    final r = raw as Map;
    final items = (r['items'] as List)
        .map((e) {
          final m = e as Map;
          return BtDev(m['name'] as String, m['address'] as String, m['paired'] as bool);
        })
        .toList();
    return NetScan(r['state'] as String, items);
  }

  static Future<NetScan<BtDev>> btBonded() async {
    try {
      return _bt(await _ch.invokeMethod<dynamic>('btBonded'));
    } catch (_) {
      return NetScan('error', []);
    }
  }

  static Future<NetScan<BtDev>> btDiscover() async {
    try {
      return _bt(await _ch.invokeMethod<dynamic>('btDiscover'));
    } catch (_) {
      return NetScan('error', []);
    }
  }

  static Future<bool> btPair(String address) async {
    try {
      return await _ch.invokeMethod<bool>('btPair', address) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 'wifi' | 'bluetooth' | 'sound'
  static Future<void> openSettings(String what) async {
    try {
      await _ch.invokeMethod('openSettings', what);
    } catch (_) {}
  }

  static Future<BatteryInfo?> battery() async {
    try {
      final r = await _ch.invokeMethod<dynamic>('battery');
      if (r is! Map) return null;
      return BatteryInfo(r['percent'] as int, r['charging'] as bool);
    } catch (_) {
      return null;
    }
  }
}
