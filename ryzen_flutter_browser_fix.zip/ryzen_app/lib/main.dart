import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'game.dart';
import 'login.dart';
import 'i18n.dart';
import 'overlays.dart';
import 'quick.dart';
import 'state.dart';
import 'tabs.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const RyzenApp());
}

class RyzenApp extends StatefulWidget {
  const RyzenApp({super.key});
  @override
  State<RyzenApp> createState() => _RyzenAppState();
}

class _RyzenAppState extends State<RyzenApp> {
  @override
  void initState() {
    super.initState();
    st.init();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ryzen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, useMaterial3: true),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  final fn = FocusNode(debugLabel: 'ryzen-root');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    fn.dispose();
    super.dispose();
  }

  bool _hadGame = false;

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) fn.requestFocus();
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    if (e is KeyUpEvent) return KeyEventResult.ignored;
    if (st.wake()) return KeyEventResult.handled; // acordou da tela de descanso
    final k = e.logicalKey;
    Act? a;
    if (k == LogicalKeyboardKey.arrowUp) {
      a = Act.up;
    } else if (k == LogicalKeyboardKey.arrowDown) {
      a = Act.down;
    } else if (k == LogicalKeyboardKey.arrowLeft) {
      a = Act.left;
    } else if (k == LogicalKeyboardKey.arrowRight) {
      a = Act.right;
    } else if (k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.gameButtonA) {
      a = Act.accept;
    } else if (k == LogicalKeyboardKey.escape || k == LogicalKeyboardKey.gameButtonB) {
      a = Act.cancel;
    } else if (k == LogicalKeyboardKey.gameButtonRight1 || k == LogicalKeyboardKey.pageDown) {
      a = Act.next;
    } else if (k == LogicalKeyboardKey.gameButtonLeft1 || k == LogicalKeyboardKey.pageUp) {
      a = Act.prev;
    } else if (k == LogicalKeyboardKey.gameButtonY) {
      a = Act.details;
    } else if (k == LogicalKeyboardKey.gameButtonX) {
      a = Act.favorite;
    } else if (k == LogicalKeyboardKey.gameButtonSelect) {
      a = Act.search;
    } else if (k == LogicalKeyboardKey.gameButtonStart) {
      a = Act.menu;
    } else if (k == LogicalKeyboardKey.gameButtonLeft2) {
      a = Act.filterPrev;
    } else if (k == LogicalKeyboardKey.gameButtonRight2) {
      a = Act.filterNext;
    }
    if (a == null) return KeyEventResult.ignored;
    st.act(a);
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: st,
      builder: (context, _) {
        if (!st.ready) return const ColoredBox(color: Colors.black);
        if (!st.msLogged) return const MsLoginGate();
        // Ao fechar o jogo a WebView some com o foco: devolve ao Ryzen.
        final hasGame = st.gameUrl != null;
        if (_hadGame && !hasGame) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) fn.requestFocus();
          });
        }
        _hadGame = hasGame;
        final s = context.s;
        final tabs = <Widget>[HomeTab(), LibraryTab(), StoreTab(), SettingsTab()];
        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, result) => st.act(Act.cancel),
          child: Listener(
            behavior: HitTestBehavior.translucent,
            onPointerDown: (_) => st.wake(),
            child: Focus(
            focusNode: fn,
            autofocus: true,
            onKeyEvent: _key,
            child: Scaffold(
              backgroundColor: Colors.black,
              body: Stack(children: [
                Positioned.fill(child: Background()),
                Positioned(top: 0, left: 0, right: 0, height: 130 * s, child: TopBar()),
                Positioned(
                  top: 130 * s,
                  bottom: 80 * s,
                  left: 0,
                  right: 0,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    layoutBuilder: (current, previous) =>
                        Stack(fit: StackFit.expand, children: [...previous, if (current != null) current]),
                    transitionBuilder: (child, anim) => FadeTransition(
                      opacity: anim,
                      child: SlideTransition(
                        position: Tween<Offset>(begin: const Offset(0.03, 0), end: Offset.zero).animate(anim),
                        child: child,
                      ),
                    ),
                    child: KeyedSubtree(key: ValueKey(st.tab), child: tabs[st.tab]),
                  ),
                ),
                Positioned(bottom: 0, left: 0, right: 0, height: 80 * s, child: Footer()),
                if (st.layer != Layer.none) Positioned.fill(child: LayerView()),
                if (st.gameUrl != null)
                  Positioned.fill(
                      child: GameView(key: ValueKey(st.gameUrl), url: st.gameUrl!, reloadTick: st.reloadTick, title: st.gameTitle, cover: st.gameCover, banner: st.gameBanner)),
                if (st.gameUrl != null && st.gameMenu) Positioned.fill(child: QuickPanelView()),
                if (st.idle) Positioned.fill(child: IdleScreen()),
              ]),
            ),
          ),
          ),
        );
      },
    );
  }
}

class Background extends StatelessWidget {
  const Background({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = st.dark;
    final wall = st.wallProvider;
    final video = st.videoWallPath;
    final tint = st.tintFor(st.focusedItem);
    return Stack(fit: StackFit.expand, children: [
      DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: dark
                ? const [Color(0xFF161A2C), Color(0xFF1D2340), Color(0xFF12162A)]
                : const [Color(0xFFDFE3F1), Color(0xFFC9CFE6), Color(0xFFE4E7F3)],
          ),
        ),
      ),
      if (wall != null)
        Image(
          image: ResizeImage(wall, width: 1920),
          fit: BoxFit.cover,
          gaplessPlayback: true,
          errorBuilder: (c, e, s) => const SizedBox.shrink(),
        ),
      if (video != null) VideoBg(path: video, paused: st.gameUrl != null),
      if (wall != null || video != null)
        ColoredBox(color: dark ? const Color(0x8C050816) : const Color(0x26FFFFFF)),
      // brilho suave na cor dominante da capa selecionada
      IgnorePointer(
        child: TweenAnimationBuilder<Color?>(
          tween: ColorTween(end: tint ?? Colors.transparent),
          duration: const Duration(milliseconds: 600),
          builder: (c, v, _) => DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -0.5),
                radius: 1.1,
                colors: [(v ?? Colors.transparent).withValues(alpha: dark ? 0.38 : 0.30), Colors.transparent],
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}

class TopBar extends StatefulWidget {
  const TopBar({super.key});
  @override
  State<TopBar> createState() => _TopBarState();
}

class _TopBarState extends State<TopBar> {
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && st.showClock) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  String _batteryIcon() {
    if (st.charging) return 'battery-charging';
    final b = st.battery;
    return b > 75 ? 'battery-100' : b > 50 ? 'battery-75' : b > 25 ? 'battery-50' : b > 10 ? 'battery-25' : 'battery-10';
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final names = ['Início', 'Biblioteca', 'Loja', 'Config'].map(tr).toList();
    const icons = ['home', 'library', 'store', 'settings'];
    final n = DateTime.now();
    final clock = '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
    return Stack(children: [
      Positioned(
        left: 40 * s,
        top: 24 * s,
        child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, children: [
          Text('RYZEN', style: ts(context, 44, spacing: 8)),
          SizedBox(width: 30 * s),
          GestureDetector(onTap: st.openProfile, child: Avatar(76)),
        ]),
      ),
      Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(top: 22 * s),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            for (var p = 0; p < RyzenState.tabOrder.length; p++) ...[
              if (p > 0) SizedBox(width: 14 * s),
              Builder(builder: (_) {
                final i = RyzenState.tabOrder[p];
                return GestureDetector(
                onTap: () => st.setTab(i),
                child: Container(
                  width: 150 * s,
                  height: 84 * s,
                  decoration: BoxDecoration(
                    color: st.tab == i ? st.pill : Colors.transparent,
                    borderRadius: BorderRadius.circular(24 * s),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SysIcon(icons[i], 34),
                    SizedBox(height: 4 * s),
                    Text(names[i],
                        style: ts(context, 22, bold: st.tab == i)),
                  ]),
                ),
              );
              }),
            ],
          ]),
        ),
      ),
      Positioned(
        right: 36 * s,
        top: 36 * s,
        child: Row(children: [
          if (st.padConnected) ...[
            SysIcon('gamepad', 32),
            if (st.padBattery >= 0) ...[
              SizedBox(width: 6 * s),
              Text('${st.padBattery}%', style: ts(context, 22)),
            ],
            SizedBox(width: 26 * s),
          ],
          SysIcon(st.wifiConnected ? 'wifi' : 'wifi-off', 32),
          SizedBox(width: 26 * s),
          if (st.showBt && st.btOn) ...[SysIcon('bluetooth', 32), SizedBox(width: 26 * s)],
          SysIcon(st.muted || st.volumePct == 0 ? 'volume-mute' : 'volume', 32),
          if (st.showBattery && st.hasBattery) ...[
            SizedBox(width: 26 * s),
            SysIcon(_batteryIcon(), 36),
            SizedBox(width: 8 * s),
            Text('${st.battery}%', style: ts(context, 24)),
          ],
          if (st.showClock) ...[
            SizedBox(width: 26 * s),
            Text(clock, style: ts(context, 26)),
          ],
        ]),
      ),
    ]);
  }
}

class Footer extends StatelessWidget {
  const Footer({super.key});

  Widget _btn(BuildContext c, String letter, String label) {
    final s = c.s;
    return Row(children: [
      Container(
        width: 36 * s,
        height: 36 * s,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: st.txt, shape: BoxShape.circle),
        child: Text(letter,
            style: ts(c, 20, bold: true, color: st.dark ? const Color(0xFF14182A) : Colors.white)),
      ),
      SizedBox(width: 10 * s),
      Text(label, style: ts(c, 22)),
    ]);
  }

  Widget _pill(BuildContext c, String text, String label) {
    final s = c.s;
    return Row(children: [
      Container(
        height: 36 * s,
        padding: EdgeInsets.symmetric(horizontal: 14 * s),
        alignment: Alignment.center,
        decoration: BoxDecoration(color: st.txt, borderRadius: BorderRadius.circular(18 * s)),
        child: Text(text,
            style: ts(c, 18, bold: true, color: st.dark ? const Color(0xFF14182A) : Colors.white)),
      ),
      SizedBox(width: 10 * s),
      Text(label, style: ts(c, 22)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Glass(
      border: Colors.transparent,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 34 * s),
        child: Row(children: [
          _btn(context, 'A', tr(st.tab == 2 ? 'Fixar / Desafixar na Início' : 'Selecionar')),
          SizedBox(width: 34 * s),
          _btn(context, 'B', tr('Voltar')),
          if (st.tab < 2) ...[
            SizedBox(width: 34 * s),
            _btn(context, 'X', tr('Favoritar')),
          ],
          SizedBox(width: 34 * s),
          GestureDetector(onTap: st.openSearch, child: _pill(context, 'Select', tr('Buscar'))),
          SizedBox(width: 34 * s),
          GestureDetector(onTap: st.openQuick, child: _pill(context, 'Start', tr('Menu'))),
          const Spacer(),
          Text('Ryzen v3.1', style: ts(context, 22)),
        ]),
      ),
    );
  }
}
