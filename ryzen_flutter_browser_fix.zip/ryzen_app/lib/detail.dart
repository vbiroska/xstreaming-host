import 'package:flutter/material.dart';

import 'i18n.dart';
import 'state.dart';
import 'ui.dart';

/// Informações de cada jogo da Loja (tela de detalhes).
class GameInfo {
  final String dev, date, desc;
  final List<String> genres;
  final int? steam; // id na Steam, usado só para buscar imagens
  final bool free;
  const GameInfo(this.dev, this.date, this.genres, this.desc, {this.steam, this.free = true});
}

const gameInfoMap = <String, GameInfo>{
  'Fortnite': GameInfo('—', '—', ['Jogo'], 'Jogue Fortnite pelo Xbox Cloud Gaming.'),
  'Fortnite Battle Royale': GameInfo('—', '—', ['Jogo'], 'Jogue Fortnite Battle Royale pelo Xbox Cloud Gaming.'),
  'Fortnite OG': GameInfo('—', '—', ['Jogo'], 'Jogue Fortnite OG pelo Xbox Cloud Gaming.'),
  'Fortnite Festival': GameInfo('—', '—', ['Jogo'], 'Jogue Fortnite Festival pelo Xbox Cloud Gaming.'),
  'LEGO Fortnite Odyssey': GameInfo('—', '—', ['Jogo'], 'Jogue LEGO Fortnite Odyssey pelo Xbox Cloud Gaming.'),
  'LEGO Fortnite Brick Life': GameInfo('—', '—', ['Jogo'], 'Jogue LEGO Fortnite Brick Life pelo Xbox Cloud Gaming.'),
  'Call of Duty Warzone': GameInfo('—', '—', ['Jogo'], 'Jogue Call of Duty Warzone pelo Xbox Cloud Gaming.', steam: 1938090),
  'Marvel Rivals': GameInfo('—', '—', ['Jogo'], 'Jogue Marvel Rivals pelo Xbox Cloud Gaming.', steam: 2767030),
  'Once Human': GameInfo('—', '—', ['Jogo'], 'Jogue Once Human pelo Xbox Cloud Gaming.', steam: 2139460),
  'Where Winds Meet': GameInfo('—', '—', ['Jogo'], 'Jogue Where Winds Meet pelo Xbox Cloud Gaming.', steam: 3564740),
  'War Thunder': GameInfo('—', '—', ['Jogo'], 'Jogue War Thunder pelo Xbox Cloud Gaming.', steam: 236390),
  'Asphalt Legends': GameInfo('—', '—', ['Jogo'], 'Jogue Asphalt Legends pelo Xbox Cloud Gaming.', steam: 805550),
  'Fishing Planet': GameInfo('—', '—', ['Jogo'], 'Jogue Fishing Planet pelo Xbox Cloud Gaming.', steam: 380600),
  '3on3 FreeStyle': GameInfo('—', '—', ['Jogo'], 'Jogue 3on3 FreeStyle pelo Xbox Cloud Gaming.', steam: 1269960),
  'Disney Speedstorm': GameInfo('—', '—', ['Jogo'], 'Jogue Disney Speedstorm pelo Xbox Cloud Gaming.', steam: 1537830),
  'The First Descendant': GameInfo('—', '—', ['Jogo'], 'Jogue The First Descendant pelo Xbox Cloud Gaming.', steam: 2074920),
  'Splitgate Arena Reloaded': GameInfo('—', '—', ['Jogo'], 'Jogue Splitgate Arena Reloaded pelo Xbox Cloud Gaming.', steam: 677620),
  'Halo Infinite': GameInfo('—', '—', ['Jogo'], 'Jogue Halo Infinite pelo Xbox Cloud Gaming.', steam: 1240440),
  'Killer Instinct': GameInfo('—', '—', ['Jogo'], 'Jogue Killer Instinct pelo Xbox Cloud Gaming.', steam: 577940),
  'Spacelords': GameInfo('—', '—', ['Jogo'], 'Jogue Spacelords pelo Xbox Cloud Gaming.', steam: 436180),
  'Tell Me Why': GameInfo('—', '—', ['Jogo'], 'Jogue Tell Me Why pelo Xbox Cloud Gaming.', steam: 1184770),
  'Little Nightmares III Free Trial': GameInfo('—', '—', ['Jogo'], 'Jogue Little Nightmares III Free Trial pelo Xbox Cloud Gaming.', steam: 1392860),
  'Cyberpunk 2077': GameInfo('—', '—', ['Jogo'], 'Jogue Cyberpunk 2077 pelo Xbox Cloud Gaming.', steam: 1091500),
  'NBA 2K27': GameInfo('—', '—', ['Jogo'], 'Jogue NBA 2K27 pelo Xbox Cloud Gaming.'),
  'Mortal Kombat 11': GameInfo('—', '—', ['Jogo'], 'Jogue Mortal Kombat 11 pelo Xbox Cloud Gaming.', steam: 976310),
  'Mortal Kombat 1': GameInfo('—', '—', ['Jogo'], 'Jogue Mortal Kombat 1 pelo Xbox Cloud Gaming.', steam: 1971870),
  'The Witcher 3 Wild Hunt': GameInfo('—', '—', ['Jogo'], 'Jogue The Witcher 3 Wild Hunt pelo Xbox Cloud Gaming.', steam: 292030),
  'Gang Beasts': GameInfo('—', '—', ['Jogo'], 'Jogue Gang Beasts pelo Xbox Cloud Gaming.', steam: 285900),
  'Cuphead': GameInfo('—', '—', ['Jogo'], 'Jogue Cuphead pelo Xbox Cloud Gaming.', steam: 268910),
  'Tom Clancys Ghost Recon Wildlands': GameInfo('—', '—', ['Jogo'], 'Jogue Tom Clancys Ghost Recon Wildlands pelo Xbox Cloud Gaming.', steam: 460930),
  'Hogwarts Legacy': GameInfo('—', '—', ['Jogo'], 'Jogue Hogwarts Legacy pelo Xbox Cloud Gaming.', steam: 990080),
  'ARC Raiders': GameInfo('—', '—', ['Jogo'], 'Jogue ARC Raiders pelo Xbox Cloud Gaming.', steam: 1808500),
  'Batman Arkham Knight': GameInfo('—', '—', ['Jogo'], 'Jogue Batman Arkham Knight pelo Xbox Cloud Gaming.', steam: 208650),
  'Among Us': GameInfo('—', '—', ['Jogo'], 'Jogue Among Us pelo Xbox Cloud Gaming.', steam: 945360),
  'REMATCH': GameInfo('—', '—', ['Jogo'], 'Jogue REMATCH pelo Xbox Cloud Gaming.', steam: 2138720),
  'Dead by Daylight': GameInfo('—', '—', ['Jogo'], 'Jogue Dead by Daylight pelo Xbox Cloud Gaming.', steam: 381210),
  'Hollow Knight': GameInfo('—', '—', ['Jogo'], 'Jogue Hollow Knight pelo Xbox Cloud Gaming.', steam: 367520),
  'Injustice 2': GameInfo('—', '—', ['Jogo'], 'Jogue Injustice 2 pelo Xbox Cloud Gaming.', steam: 627270),
  'F1 25': GameInfo('—', '—', ['Jogo'], 'Jogue F1 25 pelo Xbox Cloud Gaming.', steam: 3059520),
  'Dune Awakening': GameInfo('—', '—', ['Jogo'], 'Jogue Dune Awakening pelo Xbox Cloud Gaming.', steam: 1172710),
  'Descenders': GameInfo('—', '—', ['Jogo'], 'Jogue Descenders pelo Xbox Cloud Gaming.', steam: 681280),
  'Gears 5': GameInfo('—', '—', ['Jogo'], 'Jogue Gears 5 pelo Xbox Cloud Gaming.', steam: 1097840),
  'Forza Horizon 6': GameInfo('—', '—', ['Jogo'], 'Jogue Forza Horizon 6 pelo Xbox Cloud Gaming.', steam: 2483190),
  'Forza Horizon 5': GameInfo('—', '—', ['Jogo'], 'Jogue Forza Horizon 5 pelo Xbox Cloud Gaming.', steam: 1551360),
  'Red Dead Redemption 2': GameInfo('—', '—', ['Jogo'], 'Jogue Red Dead Redemption 2 pelo Xbox Cloud Gaming.', steam: 1174180),
  'Grand Theft Auto V': GameInfo('—', '—', ['Jogo'], 'Jogue Grand Theft Auto V pelo Xbox Cloud Gaming.', steam: 271590),
  'Sea of Thieves': GameInfo('—', '—', ['Jogo'], 'Jogue Sea of Thieves pelo Xbox Cloud Gaming.', steam: 1172620),
  'Diablo IV': GameInfo('—', '—', ['Jogo'], 'Jogue Diablo IV pelo Xbox Cloud Gaming.', steam: 2344520),
  'Fallout 4': GameInfo('—', '—', ['Jogo'], 'Jogue Fallout 4 pelo Xbox Cloud Gaming.', steam: 377160),
  'Fallout 76': GameInfo('—', '—', ['Jogo'], 'Jogue Fallout 76 pelo Xbox Cloud Gaming.', steam: 1151340),
  'Starfield': GameInfo('—', '—', ['Jogo'], 'Jogue Starfield pelo Xbox Cloud Gaming.', steam: 1716740),
  'Palworld': GameInfo('—', '—', ['Jogo'], 'Jogue Palworld pelo Xbox Cloud Gaming.', steam: 1623730),
  'State of Decay 2': GameInfo('—', '—', ['Jogo'], 'Jogue State of Decay 2 pelo Xbox Cloud Gaming.', steam: 495420),
  'The Elder Scrolls V Skyrim': GameInfo('—', '—', ['Jogo'], 'Jogue The Elder Scrolls V Skyrim pelo Xbox Cloud Gaming.', steam: 489830),
  'Far Cry 6': GameInfo('—', '—', ['Jogo'], 'Jogue Far Cry 6 pelo Xbox Cloud Gaming.', steam: 2369390),
  'Assassins Creed Valhalla': GameInfo('—', '—', ['Jogo'], 'Jogue Assassins Creed Valhalla pelo Xbox Cloud Gaming.', steam: 2208920),
  'Resident Evil Village': GameInfo('—', '—', ['Jogo'], 'Jogue Resident Evil Village pelo Xbox Cloud Gaming.', steam: 1196590),
  'It Takes Two': GameInfo('—', '—', ['Jogo'], 'Jogue It Takes Two pelo Xbox Cloud Gaming.', steam: 1426210),
  'No Mans Sky': GameInfo('—', '—', ['Jogo'], 'Jogue No Mans Sky pelo Xbox Cloud Gaming.', steam: 275850),
  'ARK Survival Ascended': GameInfo('—', '—', ['Jogo'], 'Jogue ARK Survival Ascended pelo Xbox Cloud Gaming.', steam: 2399830),
  'A Way Out': GameInfo('—', '—', ['Jogo'], 'Jogue A Way Out pelo Xbox Cloud Gaming.', steam: 1222700),
  'The Crew Motorfest': GameInfo('—', '—', ['Jogo'], 'Jogue The Crew Motorfest pelo Xbox Cloud Gaming.', steam: 2698940),
  'Star Wars Outlaws': GameInfo('—', '—', ['Jogo'], 'Jogue Star Wars Outlaws pelo Xbox Cloud Gaming.', steam: 2842040),
};

/// Capturas de tela (Steam) do jogo; vazio quando ele não tem ID da Steam.
List<String> shotsFor(String title) {
  final id = infoFor(title).steam;
  if (id == null) return <String>[];
  final base = 'https://shared.steamstatic.com/store_item_assets/steam/apps/$id/';
  return ['${base}header.jpg', '${base}capsule_616x353.jpg', '${base}library_hero.jpg', '${base}page_bg_generated_v6b.jpg'];
}

/// Trailers (links da pesquisa de 25/11/2026). Links de youtube.com/watch viram miniatura com play;
/// os demais abrem a página oficial ou a busca do YouTube. Jogo fora da lista: busca automática.
const trailerLinks = <String, String>{};

String trailerFor(String title) =>
    trailerLinks[title] ??
    'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent('$title official trailer')}';

/// true = ao abrir a tela de detalhes, o trailer (quando for um vídeo do YouTube) já abre
/// em tela cheia e começa a tocar sozinho. Troque para false para desligar.
const kAutoTrailer = true;

/// Link usado para tocar o trailer: vídeos do YouTube vão para a versão mobile do player.
String trailerPlayUrl(String title) {
  final u = trailerFor(title);
  final id = trailerVideoId(u);
  return id == null ? u : 'https://m.youtube.com/watch?v=$id';
}

/// ID do vídeo quando o link é um youtube.com/watch?v=..., senão null.
String? trailerVideoId(String url) {
  final u = Uri.tryParse(url);
  if (u == null || !u.host.endsWith('youtube.com') || u.path != '/watch') return null;
  return u.queryParameters['v'];
}

GameInfo infoFor(String title) =>
    gameInfoMap[title] ?? const GameInfo('—', '—', ['Jogo'], 'Jogue este título pelo serviço de nuvem configurado no Ryzen.');

/// Até 7 jogos relacionados: primeiro os que dividem gênero, depois os demais.
List<int> relatedTo(int i) {
  final g = infoFor(storeTitles[i]).genres.toSet();
  final same = <int>[], rest = <int>[];
  for (var j = 0; j < storeTitles.length; j++) {
    if (j == i) continue;
    (infoFor(storeTitles[j]).genres.any(g.contains) ? same : rest).add(j);
  }
  return [...same, ...rest].take(7).toList();
}

const _bg = Color(0xFF0A0E17);
const _relW = 196.0, _relH = 250.0, _relGap = 16.0; // capas relacionadas (proporção de capa, sem corte)
const _shotW = 272.0, _shotH = 153.0, _shotGap = 16.0; // capturas 16:9 inteiras

class GameInfoView extends StatefulWidget {
  const GameInfoView({super.key});

  @override
  State<GameInfoView> createState() => _GameInfoViewState();
}

class _GameInfoViewState extends State<GameInfoView> {
  final _vert = ScrollController();
  final _rel = ScrollController();
  final _shotsCtl = ScrollController();
  final _relKey = GlobalKey();
  final _shotKey = GlobalKey();
  int _lastFocus = 0, _lastRel = 0, _lastInfo = -1, _lastTr = 0;

  @override
  void initState() {
    super.initState();
    st.addListener(_onState);
  }

  @override
  void dispose() {
    st.removeListener(_onState);
    _vert.dispose();
    _rel.dispose();
    _shotsCtl.dispose();
    super.dispose();
  }

  void _onState() {
    if (mounted) setState(() {});
  }

  // Mantém o item focado visível (rolagem horizontal e vertical) ao navegar com o controle.
  void _follow(double s) {
    final f = st.infoFocus, r = st.relIdx, i = st.infoIdx;
    final changed = f != _lastFocus || r != _lastRel || i != _lastInfo || st.trIdx != _lastTr;
    if (!changed) return;
    final newGame = i != _lastInfo;
    _lastFocus = f;
    _lastTr = st.trIdx;
    _lastRel = r;
    _lastInfo = i;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (newGame) {
        if (_vert.hasClients) _vert.jumpTo(0);
        if (_rel.hasClients) _rel.jumpTo(0);
        if (_shotsCtl.hasClients) _shotsCtl.jumpTo(0);
        return;
      }
      if (f == 4) {
        final ctx = _shotKey.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(ctx,
              alignment: 0.9, duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
        }
        if (_shotsCtl.hasClients) {
          final k = (st.trIdx - 1).clamp(0, 1000).toInt();
          final step = (_shotW + _shotGap) * s;
          final view = _shotsCtl.position.viewportDimension;
          final target = (k * step - (view - _shotW * s) / 2).clamp(0.0, _shotsCtl.position.maxScrollExtent).toDouble();
          _shotsCtl.animateTo(st.trIdx == 0 ? 0 : target,
              duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
        }
      } else if (f == 3) {
        final ctx = _relKey.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(ctx,
              alignment: 0.9, duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
        }
        if (_rel.hasClients) {
          final step = (_relW + _relGap) * s;
          final view = _rel.position.viewportDimension;
          final target = (r * step - (view - _relW * s) / 2).clamp(0.0, _rel.position.maxScrollExtent).toDouble();
          _rel.animateTo(target, duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
        }
      } else if (_vert.hasClients) {
        _vert.animateTo(0, duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    _follow(s);
    final i = st.infoIdx.clamp(0, storeTitles.length - 1).toInt();
    final title = storeTitles[i];
    final info = infoFor(title);
    final pinned = st.pinned.contains(title);
    final hero = st.featBanner(i) ?? st.storeImage(i);
    final rel = relatedTo(i);
    final f = st.infoFocus;
    final shots = shotsFor(title);
    final xbox = st.storeLink(title).contains('play.xbox.com');
    final trailer = trailerFor(title);
    final vid = trailerVideoId(trailer);

    Widget ring(bool on, Widget child, double r) => AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(r * s),
            border: Border.all(color: on ? Colors.white : Colors.transparent, width: 3 * s),
          ),
          child: child,
        );

    Widget chip(Widget icon, String text) => Container(
          padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 8 * s),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.10),
            borderRadius: BorderRadius.circular(20 * s),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            icon,
            SizedBox(width: 8 * s),
            Text(text, style: ts(context, 17, color: Colors.white)),
          ]),
        );

    Widget trailerCard() {
      final on = f == 4 && st.trIdx == 0;
      Widget fallback() => hero != null
          ? Image(image: ResizeImage(hero, width: 600), fit: BoxFit.cover)
          : const ColoredBox(color: Colors.white10);
      Widget thumb = vid == null
          ? fallback()
          : Image.network('https://i.ytimg.com/vi/$vid/maxresdefault.jpg',
              fit: BoxFit.cover,
              errorBuilder: (c, e, t) => Image.network('https://i.ytimg.com/vi/$vid/mqdefault.jpg',
                  fit: BoxFit.cover, errorBuilder: (c, e, t) => fallback()));
      return GestureDetector(
        onTap: () => st.tapTrailerRow(0),
        child: AnimatedScale(
          scale: on ? 1.04 : 1.0,
          duration: const Duration(milliseconds: 100),
          child: Container(
            width: _shotW * s,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(10 * s),
              border: Border.all(color: on ? Colors.white : Colors.transparent, width: 3 * s),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(fit: StackFit.expand, children: [
              thumb,
              ColoredBox(color: Colors.black.withOpacity(0.28)),
              Center(
                child: Container(
                  width: 58 * s,
                  height: 58 * s,
                  decoration: BoxDecoration(color: st.accent, shape: BoxShape.circle),
                  child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 40 * s),
                ),
              ),
              Positioned(
                left: 10 * s,
                bottom: 8 * s,
                child: Text(tr('Assistir trailer'),
                    style: ts(context, 16, color: Colors.white, bold: true)),
              ),
            ]),
          ),
        ),
      );
    }

    Widget btn(String text, Widget icon, bool focused, VoidCallback onTap, {Color? color, double w = 200}) =>
        GestureDetector(
          onTap: onTap,
          child: ring(
            focused,
            Container(
              width: w * s,
              height: 62 * s,
              decoration: BoxDecoration(
                color: color ?? Colors.white.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12 * s),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                icon,
                if (text.isNotEmpty) SizedBox(width: 10 * s),
                if (text.isNotEmpty) Text(text, style: ts(context, 22, color: Colors.white, bold: true)),
              ]),
            ),
            14,
          ),
        );

    Widget infoCard(IconData ic, String label, String value) => Expanded(
          child: Container(
            height: 76 * s,
            margin: EdgeInsets.only(left: 14 * s),
            padding: EdgeInsets.symmetric(horizontal: 16 * s),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.07),
              borderRadius: BorderRadius.circular(14 * s),
              border: Border.all(color: Colors.white.withOpacity(0.16)),
            ),
            child: Row(children: [
              Icon(ic, color: Colors.white70, size: 34 * s),
              SizedBox(width: 14 * s),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tr(label), style: ts(context, 15, color: Colors.white60)),
                  Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 19, color: Colors.white)),
                ]),
              ),
            ]),
          ),
        );

    return Stack(children: [
      const Positioned.fill(child: ColoredBox(color: _bg)),
      // imagem larga de fundo (à direita), esmaecida para a esquerda e para baixo
      Positioned(
        top: 0,
        right: 0,
        width: MediaQuery.sizeOf(context).width * 0.7,
        height: 640 * s,
        child: Stack(fit: StackFit.expand, children: [
          if (hero != null) Image(image: ResizeImage(hero, width: 1400), fit: BoxFit.cover, alignment: Alignment.centerRight),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_bg, _bg.withOpacity(0.0)], stops: const [0.0, 0.7]),
            ),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [_bg.withOpacity(0.0), _bg],
                stops: const [0.55, 1.0],
              ),
            ),
          ),
        ]),
      ),
      Positioned.fill(
        child: SingleChildScrollView(
          controller: _vert,
          padding: EdgeInsets.fromLTRB(48 * s, 26 * s, 48 * s, 24 * s),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            GestureDetector(
              onTap: st.closeLayer,
              child: Container(
                width: 52 * s,
                height: 44 * s,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10 * s),
                ),
                child: Center(child: SysIcon('back', 26, white: true)),
              ),
            ),
            SizedBox(height: 22 * s),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 198 * s,
                height: 248 * s,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12 * s),
                  border: Border.all(color: Colors.white24, width: 2 * s),
                ),
                clipBehavior: Clip.antiAlias,
                child: Art(img: st.storeImage(i), fit: BoxFit.cover, title: title),
              ),
              SizedBox(width: 34 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 56, color: Colors.white, bold: true)),
                  SizedBox(height: 4 * s),
                  Text(info.dev, style: ts(context, 21, color: Colors.white70)),
                  SizedBox(height: 14 * s),
                  Wrap(spacing: 12 * s, runSpacing: 8 * s, children: [
                    if (xbox) chip(Icon(Icons.cloud_outlined, size: 22 * s, color: Colors.white), 'Xbox Cloud Gaming'),
                    if (info.free) chip(Icon(Icons.sell_outlined, size: 22 * s, color: Colors.white), tr('Grátis para jogar')),
                    chip(Icon(Icons.public, size: 22 * s, color: Colors.white), tr('Multijogador online')),
                  ]),
                  SizedBox(height: 18 * s),
                  Row(children: [
                    btn(tr('Jogar'), SysIcon('play', 28, white: true), f == 0, st.infoPlay, color: st.accent, w: 224),
                    SizedBox(width: 14 * s),
                    btn(tr(pinned ? 'Favoritado' : 'Favoritar'), SysIcon(pinned ? 'heart-fill' : 'heart', 28, white: true), f == 1,
                        st.infoPin, w: 190),
                    SizedBox(width: 14 * s),
                    btn('', Icon(Icons.ios_share, color: Colors.white, size: 30 * s), f == 2, st.infoShare, w: 76),
                    if (st.infoMsg.isNotEmpty) ...[
                      SizedBox(width: 16 * s),
                      Text(tr(st.infoMsg), style: ts(context, 18, color: Colors.white70)),
                    ],
                  ]),
                ]),
              ),
            ]),
            SizedBox(height: 26 * s),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                flex: 5,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tr('Sobre o jogo'), style: ts(context, 30, color: Colors.white, bold: true)),
                  SizedBox(height: 8 * s),
                  Text(info.desc, maxLines: 4, overflow: TextOverflow.ellipsis, style: ts(context, 20, color: Colors.white70)),
                ]),
              ),
              SizedBox(width: 24 * s),
              Expanded(
                flex: 8,
                child: Row(children: [
                  infoCard(Icons.sports_esports_outlined, 'Gênero', info.genres.join(', ')),
                  infoCard(Icons.calendar_month_outlined, 'Lançamento', info.date),
                  infoCard(Icons.person_outline, 'Desenvolvedor', info.dev),
                ]),
              ),
            ]),
            SizedBox(height: 22 * s),
            Text(shots.isNotEmpty ? tr('Trailer e capturas de tela') : tr('Trailer'),
                style: ts(context, 28, color: Colors.white, bold: true)),
            SizedBox(height: 10 * s),
            SizedBox(
              key: _shotKey,
              height: (_shotH + 12) * s,
              child: Row(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 6 * s, horizontal: 4 * s),
                  child: trailerCard(),
                ),
                SizedBox(width: _shotGap * s),
                Expanded(
                  child: ListView.separated(
                    controller: _shotsCtl,
                    scrollDirection: Axis.horizontal,
                    physics: const ClampingScrollPhysics(),
                    clipBehavior: Clip.none,
                    padding: EdgeInsets.symmetric(vertical: 6 * s),
                    itemCount: shots.length,
                    separatorBuilder: (_, __) => SizedBox(width: _shotGap * s),
                    itemBuilder: (c, k) {
                      final on = f == 4 && st.trIdx == k + 1;
                      return GestureDetector(
                        onTap: () => st.tapTrailerRow(k + 1),
                        child: AnimatedScale(
                          scale: on ? 1.04 : 1.0,
                          duration: const Duration(milliseconds: 100),
                          child: Container(
                            width: _shotW * s,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(10 * s),
                              border: Border.all(color: on ? Colors.white : Colors.transparent, width: 3 * s),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: Image.network(shots[k],
                                fit: BoxFit.contain,
                                errorBuilder: (c, e, t) => const SizedBox.shrink()),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ]),
            ),
            SizedBox(height: 20 * s),
            Text(tr('Jogos relacionados'), style: ts(context, 28, color: Colors.white, bold: true)),
            SizedBox(height: 10 * s),
            SizedBox(
              key: _relKey,
              height: (_relH + 14) * s,
              child: ListView.separated(
                controller: _rel,
                scrollDirection: Axis.horizontal,
                physics: const ClampingScrollPhysics(),
                clipBehavior: Clip.none,
                padding: EdgeInsets.symmetric(vertical: 7 * s, horizontal: 4 * s),
                itemCount: rel.length,
                separatorBuilder: (_, __) => SizedBox(width: _relGap * s),
                itemBuilder: (c, k) {
                  final on = f == 3 && st.relIdx == k;
                  return GestureDetector(
                    onTap: () => st.openInfo(rel[k]),
                    child: AnimatedScale(
                      scale: on ? 1.06 : 1.0,
                      duration: const Duration(milliseconds: 100),
                      child: Container(
                        width: _relW * s,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(10 * s),
                          border: Border.all(color: on ? Colors.white : Colors.transparent, width: 3 * s),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Art(img: st.storeImage(rel[k]), fit: BoxFit.contain, title: storeTitles[rel[k]], fontSize: 15),
                      ),
                    ),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
      if (st.shotOpen >= 0 && st.shotOpen < shots.length)
        Positioned.fill(
          child: GestureDetector(
            onTap: st.closeShot,
            child: Container(
              color: Colors.black.withOpacity(0.92),
              padding: EdgeInsets.all(32 * s),
              child: Stack(children: [
                Positioned.fill(
                  child: Image.network(shots[st.shotOpen],
                      fit: BoxFit.contain,
                      errorBuilder: (c, e, t) => const SizedBox.shrink()),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Text('${st.shotOpen + 1} / ${shots.length}',
                      style: ts(context, 20, color: Colors.white70)),
                ),
              ]),
            ),
          ),
        ),
    ]);
  }
}
