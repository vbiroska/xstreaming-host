import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart' show RenderRepaintBoundary;

import 'detail.dart';
import 'i18n.dart';
import 'quick.dart';
import 'state.dart';
import 'ui.dart';

/// Painel modal com lista (usado por "Meus jogos" e pelos editores de ícones/capas).
class ListPanel extends StatefulWidget {
  final String title, subtitle, hint;
  final List<Widget> buttons;
  final int count, index;
  final double rowHeight;
  final Widget Function(BuildContext, int) rowBuilder;
  final void Function(int) onTapRow;
  const ListPanel({
    super.key,
    required this.title,
    required this.subtitle,
    required this.hint,
    required this.buttons,
    required this.count,
    required this.index,
    required this.rowBuilder,
    required this.onTapRow,
    this.rowHeight = 72,
  });

  @override
  State<ListPanel> createState() => _ListPanelState();
}

class _ListPanelState extends State<ListPanel> {
  final sc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final size = MediaQuery.sizeOf(context);
    final ext = (widget.rowHeight + 8) * s;
    if (_last != widget.index) {
      _last = widget.index;
      final i = widget.index;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(sc, i * ext, ext));
    }
    return Stack(children: [
      Positioned.fill(
        child: GestureDetector(onTap: () {}, child: Container(color: const Color(0x99000000))),
      ),
      Center(
        child: Container(
          width: math.min(1100 * s, size.width - 40 * s),
          height: math.min(760 * s, size.height - 40 * s),
          decoration: BoxDecoration(
            color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
            borderRadius: BorderRadius.circular(22 * s),
            border: Border.all(color: st.tileEdge),
          ),
          child: Stack(children: [
            Positioned(left: 40 * s, top: 22 * s, child: Text(widget.title, style: ts(context, 30, bold: true))),
            Positioned(left: 40 * s, top: 72 * s, child: Text(widget.subtitle, style: ts(context, 18, color: st.subTxt))),
            Positioned(
              right: 40 * s,
              top: 24 * s,
              child: Row(children: [
                for (var i = 0; i < widget.buttons.length; i++) ...[
                  if (i > 0) SizedBox(width: 8 * s),
                  widget.buttons[i],
                ],
              ]),
            ),
            Positioned(
              left: 30 * s,
              top: 112 * s,
              right: 30 * s,
              bottom: 78 * s,
              child: ListView.builder(
                controller: sc,
                itemExtent: ext,
                itemCount: widget.count,
                itemBuilder: (c, i) {
                  final cur = i == widget.index;
                  return Padding(
                    padding: EdgeInsets.only(bottom: 8 * s),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => widget.onTapRow(i),
                      child: Container(
                        decoration: BoxDecoration(
                          color: cur ? st.selRow : Colors.transparent,
                          borderRadius: BorderRadius.circular(14 * s),
                          border: Border.all(color: cur ? st.accent : Colors.transparent, width: 3 * s),
                        ),
                        child: widget.rowBuilder(c, i),
                      ),
                    ),
                  );
                },
              ),
            ),
            Positioned(left: 40 * s, bottom: 22 * s, child: Text(widget.hint, style: ts(context, 20, color: st.subTxt))),
          ]),
        ),
      ),
    ]);
  }
}

/// Perfil: foto, nome e preferências.
class ProfileView extends StatefulWidget {
  ProfileView({super.key});
  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  late int _tick = st.nameTick;
  late int _dTick = st.dlgTick;

  Future<void> _editName() async {
    final c = TextEditingController(text: st.profName);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Editar perfil')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: c,
            autofocus: true,
            maxLength: 24,
            decoration: InputDecoration(labelText: tr('Nome de exibição')),
          ),
          if (st.profPhoto.isNotEmpty)
            TextButton(
              onPressed: () {
                st.clearAvatar();
                Navigator.pop(ctx, false);
              },
              child: Text(tr('Remover foto')),
            ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Cancelar'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr('Salvar'))),
        ],
      ),
    );
    if (ok == true) st.setUserName(c.text);
    c.dispose();
  }

  Future<void> _infoDialog(String kind) {
    final about = kind == 'about';
    return showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(about ? tr('Sobre o Ryzen') : tr('Privacidade e segurança')),
        content: Text(about
            ? tr('Ryzen v3.1 — launcher de jogos para Android, port do tema Pegasus Ryzen v2.0.')
            : tr('Sua foto, nome e preferências ficam salvos só neste aparelho.')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Fechar')))],
      ),
    );
  }

  /// (ícone, texto, perigoso)
  (String, String, bool) _row(String id) {
    switch (id) {
      case 'edit':
        return ('user', tr('Editar perfil'), false);
      case 'photo':
        return ('folder', tr('Escolher foto da galeria'), false);
      case 'config':
        return ('settings', tr('Configurações'), false);
      case 'privacy':
        return ('check', tr('Privacidade e segurança'), false);
      case 'about':
        return ('info', tr('Sobre o Ryzen'), false);
      default:
        return ('check', tr('Continuar'), false);
    }
  }

  Widget _chip(String id, int i, {required Widget child, required double height, double radius = 16}) {
    final s = context.s;
    final sel = i == st.profIdx;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        st.profIdx = i;
        st.profileAccept(i);
      },
      child: Container(
        height: height * s,
        decoration: BoxDecoration(
          color: sel ? st.selRow : (st.dark ? const Color(0x14FFFFFF) : const Color(0x33FFFFFF)),
          borderRadius: BorderRadius.circular(radius * s),
          border: Border.all(color: sel ? st.accent : st.tileEdge, width: sel ? 3 * s : 1),
        ),
        child: child,
      ),
    );
  }

  Widget _menuRow(String id, int i) {
    final s = context.s;
    final r = _row(id);
    final color = r.$3 ? const Color(0xFFFF6B81) : st.txt;
    return _chip(
      id,
      i,
      height: id == 'signout' ? 62 : 66,
      child: Row(children: [
        SizedBox(width: 22 * s),
        r.$3
            ? ColorFiltered(
                colorFilter: const ColorFilter.mode(Color(0xFFFF6B81), BlendMode.srcIn),
                child: SysIcon(r.$1, 30, white: true))
            : SysIcon(r.$1, 30),
        SizedBox(width: 22 * s),
        Expanded(child: Text(r.$2, style: ts(context, 22, color: color))),
        Icon(Icons.chevron_right_rounded, size: 34 * s, color: r.$3 ? color : st.subTxt),
        SizedBox(width: 16 * s),
      ]),
    );
  }

  Widget _stat(String value, String label) {
    final s = context.s;
    return Expanded(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(value, style: ts(context, 28, bold: true)),
        SizedBox(height: 2 * s),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 16, color: st.subTxt)),
      ]),
    );
  }

  Widget _leftPanel(List<String> ids) {
    final s = context.s;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(height: 6 * s),
      GestureDetector(
        onTap: st.pickAvatar,
        child: SizedBox(
          width: 170 * s,
          height: 170 * s,
          child: Stack(clipBehavior: Clip.none, children: [
            Center(child: Avatar(160)),
            Positioned(
              right: 6 * s,
              bottom: 6 * s,
              child: Container(
                width: 44 * s,
                height: 44 * s,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: st.accent,
                  border: Border.all(color: st.tileEdge, width: 2 * s),
                ),
                child: Icon(Icons.edit_rounded, size: 22 * s, color: Colors.white),
              ),
            ),
          ]),
        ),
      ),
      SizedBox(height: 14 * s),
      Text(st.userName, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: ts(context, 32, bold: true)),
      SizedBox(height: 6 * s),
      SizedBox(height: 16 * s),
      Container(width: 40 * s, height: 2 * s, color: st.tileEdge),
      SizedBox(height: 16 * s),
      Container(
        padding: EdgeInsets.symmetric(vertical: 14 * s),
        decoration: BoxDecoration(
          color: st.dark ? const Color(0x14FFFFFF) : const Color(0x33FFFFFF),
          borderRadius: BorderRadius.circular(16 * s),
        ),
        child: IntrinsicHeight(
          child: Row(children: [
            _stat('${st.playedCount}', tr('Jogos jogados')),
            Container(width: 1, color: st.tileEdge),
            _stat(st.totalHours, tr('Horas de jogo')),
          ]),
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final size = MediaQuery.sizeOf(context);
    if (_tick != st.nameTick) {
      _tick = st.nameTick;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _editName();
      });
    }
    if (_dTick != st.dlgTick) {
      _dTick = st.dlgTick;
      final kind = st.dlgKind;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _infoDialog(kind);
      });
    }
    final crop = st.cropSrc;
    if (crop != null) return _CropPanel(key: ValueKey(crop), path: crop);
    final ids = st.profileIds;
    final menu = [for (var i = 0; i < ids.length; i++) i];
    return Stack(children: [
      Positioned.fill(child: GestureDetector(onTap: () {}, child: Container(color: const Color(0xB3000000)))),
      Center(
        child: Container(
          width: math.min(1060 * s, size.width - 40 * s),
          constraints: BoxConstraints(maxHeight: size.height - 30 * s),
          decoration: BoxDecoration(
            color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
            borderRadius: BorderRadius.circular(28 * s),
            border: Border.all(color: st.tileEdge),
          ),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(34 * s, 14 * s, 34 * s, 30 * s),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              SizedBox(
                height: 56 * s,
                child: Stack(children: [
                  Center(
                    child: Container(
                      width: 80 * s,
                      height: 5 * s,
                      decoration: BoxDecoration(color: st.subTxt, borderRadius: BorderRadius.circular(3 * s)),
                    ),
                  ),
                  Positioned(
                    right: 0,
                    top: 4 * s,
                    child: GestureDetector(
                      onTap: st.closeProfile,
                      child: Container(
                        width: 50 * s,
                        height: 50 * s,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: st.tileEdge, width: 1.5 * s),
                        ),
                        child: SysIcon('close', 26),
                      ),
                    ),
                  ),
                ]),
              ),
              SizedBox(height: 6 * s),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(flex: 5, child: Padding(padding: EdgeInsets.only(right: 20 * s), child: _leftPanel(ids))),
                Expanded(
                  flex: 7,
                  child: Column(children: [
                    for (final i in menu) ...[
                      _menuRow(ids[i], i),
                      SizedBox(height: 12 * s),
                    ],
                  ]),
                ),
              ]),
            ]),
          ),
        ),
      ),
    ]);
  }
}

/// Editor de corte da foto de perfil: arraste e use dois dedos para dar zoom.
class _CropPanel extends StatefulWidget {
  final String path;
  const _CropPanel({super.key, required this.path});
  @override
  State<_CropPanel> createState() => _CropPanelState();
}

class _CropPanelState extends State<_CropPanel> {
  final _key = GlobalKey();
  final _tc = TransformationController();
  late int _tick = st.cropTick;
  Size? _img;
  bool _init = false, _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await File(widget.path).readAsBytes();
      final im = await decodeImageFromList(bytes);
      final sz = Size(im.width.toDouble(), im.height.toDouble());
      im.dispose();
      if (mounted) setState(() => _img = sz);
    } catch (_) {
      st.cancelCrop();
    }
  }

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving || _img == null) return;
    setState(() => _saving = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final out = await b.toImage(pixelRatio: 640 / b.size.width);
      final data = await out.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('sem dados');
      await st.saveAvatarBytes(data.buffer.asUint8List());
    } catch (_) {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final size = MediaQuery.sizeOf(context);
    if (_tick != st.cropTick) {
      _tick = st.cropTick;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _save();
      });
    }
    final box = math.max(180 * s, math.min(460 * s, size.height - 340 * s));
    final img = _img;
    var cw = box, ch = box;
    if (img != null) {
      final k = box / math.min(img.width, img.height);
      cw = img.width * k;
      ch = img.height * k;
      if (!_init) {
        _init = true;
        _tc.value = Matrix4.translationValues(-(cw - box) / 2, -(ch - box) / 2, 0);
      }
    }
    return Stack(children: [
      Positioned.fill(child: GestureDetector(onTap: () {}, child: Container(color: const Color(0xCC000000)))),
      Center(
        child: Container(
          width: math.min(760 * s, size.width - 40 * s),
          padding: EdgeInsets.fromLTRB(30 * s, 22 * s, 30 * s, 20 * s),
          decoration: BoxDecoration(
            color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
            borderRadius: BorderRadius.circular(22 * s),
            border: Border.all(color: st.tileEdge),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(tr('Ajustar foto'), style: ts(context, 30, bold: true)),
            SizedBox(height: 4 * s),
            Text(tr('Arraste para posicionar e use dois dedos para dar zoom'),
                textAlign: TextAlign.center, style: ts(context, 17, color: st.subTxt)),
            SizedBox(height: 14 * s),
            SizedBox(
              width: box,
              height: box,
              child: Stack(fit: StackFit.expand, children: [
                RepaintBoundary(
                  key: _key,
                  child: ClipRect(
                    child: img == null
                        ? const ColoredBox(color: Color(0x33000000))
                        : InteractiveViewer(
                            transformationController: _tc,
                            constrained: false,
                            minScale: 1,
                            maxScale: 6,
                            boundaryMargin: EdgeInsets.zero,
                            child: SizedBox(
                              width: cw,
                              height: ch,
                              child: Image.file(File(widget.path), fit: BoxFit.fill),
                            ),
                          ),
                  ),
                ),
                IgnorePointer(child: CustomPaint(painter: _CirclePainter())),
              ]),
            ),
            SizedBox(height: 16 * s),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              PillBtn(tr('Cancelar'), st.cancelCrop, w: 200, h: 54, font: 22, filled: false),
              SizedBox(width: 16 * s),
              PillBtn(_saving ? tr('Salvando…') : tr('Salvar'), _save, w: 200, h: 54, font: 22),
            ]),
            SizedBox(height: 8 * s),
            Text(tr('A  Salvar        B  Cancelar'), style: ts(context, 16, color: st.subTxt)),
          ]),
        ),
      ),
    ]);
  }
}

class _CirclePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 2;
    final path = Path()
      ..addRect(Offset.zero & size)
      ..addOval(Rect.fromCircle(center: c, radius: r))
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(path, Paint()..color = const Color(0x99000000));
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = const Color(0xCCFFFFFF));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class LayerView extends StatelessWidget {
  const LayerView({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    if (st.layer == Layer.gameInfo) return const GameInfoView();
    if (st.layer == Layer.profile) return ProfileView();
    if (st.layer == Layer.panel) return QuickPanelView();
    if (st.layer == Layer.search) return SearchView();
    if (st.layer == Layer.wifi || st.layer == Layer.bt) {
      final wifi = st.layer == Layer.wifi;
      return ListPanel(
        title: wifi ? 'Redes Wi-Fi' : 'Dispositivos Bluetooth',
        subtitle: st.netMsg.isNotEmpty
            ? st.netMsg
            : (wifi ? '${st.wifiNets.length} redes encontradas' : '${st.btDevs.length} dispositivos'),
        hint: wifi
            ? 'A  Conectar (abre os ajustes)        Y  Atualizar        B  Fechar'
            : 'A  Parear / abrir ajustes        Y  Atualizar        B  Fechar',
        buttons: [
          PillBtn(st.scanning ? 'Buscando…' : 'Atualizar', st.scanNet, w: 150, h: 44, font: 19, filled: false),
          PillBtn('Ajustes', () => st.netAccept2(), w: 130, h: 44, font: 19, filled: false),
          PillBtn('Fechar', st.closeLayer, w: 130, h: 44, font: 19),
        ],
        count: st.netCount,
        index: st.netIdx,
        onTapRow: (i) {
          st.netIdx = i;
          st.sfx('ok');
          st.netAccept();
        },
        rowBuilder: (c, i) {
          if (wifi) {
            final n = st.wifiNets[i];
            return Row(children: [
              SizedBox(width: 22 * s),
              Opacity(opacity: 0.3 + 0.175 * n.level, child: SysIcon('wifi', 34)),
              SizedBox(width: 22 * s),
              Expanded(child: Text(n.ssid, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
              if (n.connected) Text('Conectada  ', style: ts(c, 18, color: st.accent, bold: true)),
              Text(n.secure ? 'Protegida' : 'Aberta', style: ts(c, 17, color: st.subTxt)),
              SizedBox(width: 22 * s),
            ]);
          }
          final d = st.btDevs[i];
          return Row(children: [
            SizedBox(width: 22 * s),
            SysIcon('bluetooth', 34),
            SizedBox(width: 22 * s),
            Expanded(child: Text(d.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
            Text(d.paired ? 'Pareado' : 'Disponível · A: parear',
                style: ts(c, 17, color: d.paired ? st.accent : st.subTxt)),
            SizedBox(width: 22 * s),
          ]);
        },
      );
    }
    if (st.layer == Layer.games) {
      return ListPanel(
        title: 'Meus jogos',
        subtitle: '${st.selected.length} de ${st.apps.length} selecionados',
        hint: 'A  Marcar / Desmarcar        B  Concluir',
        buttons: [
          PillBtn('Todos', st.selectAll, w: 130, h: 44, font: 19, filled: false),
          PillBtn('Nenhum', st.selectNone, w: 130, h: 44, font: 19, filled: false),
          PillBtn('Concluir', st.closeLayer, w: 130, h: 44, font: 19),
        ],
        count: st.apps.length,
        index: st.pickIdx,
        onTapRow: (i) {
          st.pickIdx = i;
          st.sfx('ok');
          st.toggleApp(st.apps[i].package);
        },
        rowBuilder: (c, i) {
          final a = st.apps[i];
          final sel = st.selected.contains(a.package);
          return Row(children: [
            SizedBox(width: 22 * s),
            Container(
              width: 36 * s,
              height: 36 * s,
              decoration: BoxDecoration(
                color: sel ? st.accent : Colors.transparent,
                borderRadius: BorderRadius.circular(9 * s),
                border: Border.all(color: st.accent, width: 2 * s),
              ),
              child: sel ? Center(child: SysIcon('check', 24, white: true)) : null,
            ),
            SizedBox(width: 24 * s),
            Expanded(child: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
            SizedBox(width: 22 * s),
          ]);
        },
      );
    }

    final store = st.layer == Layer.editStore;
    final n = store ? storeTitles.length : st.apps.length;
    return ListPanel(
      title: store ? 'Capas da loja' : 'Ícones dos aplicativos',
      subtitle: 'Escolha a imagem de cada item, direto da galeria do aparelho',
      hint: 'A  Trocar imagem        Direita  Restaurar        B  Fechar',
      buttons: [PillBtn('Concluir', st.closeLayer, w: 130, h: 44, font: 19)],
      count: n,
      index: st.editIdx,
      rowHeight: 76,
      onTapRow: (i) {
        st.editIdx = i;
        st.sfx('ok');
        st.pickFor(store, store ? storeTitles[i] : st.apps[i].package);
      },
      rowBuilder: (c, i) {
        final key = store ? storeTitles[i] : st.apps[i].package;
        final name = store ? storeTitles[i] : st.apps[i].name;
        final img = store ? st.storeImage(i) : st.appImage(st.apps[i]);
        final mapped = st.isMapped(store, key);
        return Row(children: [
          SizedBox(width: 16 * s),
          SizedBox(
            width: 56 * s,
            height: 56 * s,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10 * s),
              child: Art(img: img, fit: BoxFit.cover, title: ''),
            ),
          ),
          SizedBox(width: 20 * s),
          Expanded(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
          if (mapped) ...[
            Text('Personalizado', style: ts(c, 17, color: st.subTxt)),
            SizedBox(width: 12 * s),
            GestureDetector(
              onTap: () => st.clearMapped(store, key),
              child: SysIcon('close', 28),
            ),
          ],
          SizedBox(width: 22 * s),
        ]);
      },
    );
  }
}
