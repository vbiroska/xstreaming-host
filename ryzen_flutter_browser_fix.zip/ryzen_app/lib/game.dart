import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'native.dart';
import 'i18n.dart';
import 'state.dart';
import 'login.dart';

/// Aceita link completo, "site.com" ou texto (vira busca no Google).
String normalizeUrl(String raw) {
  final t = raw.trim();
  final u = Uri.tryParse(t);
  if (u != null && u.hasScheme && !t.contains(' ')) return t;
  if (!t.contains(' ') && t.contains('.')) return 'https://$t';
  return 'https://www.google.com/search?q=${Uri.encodeQueryComponent(t)}';
}


/// Gamepad padrão (W3C) injetado na página: a WebView dentro do Flutter não recebe
/// analógicos/gatilhos/direcional, então o estado vem do lado nativo e aparece aqui
/// em navigator.getGamepads() + evento gamepadconnected. Idempotente.
const _padJs = r'''
(function(){
  if (window.__rz || window !== window.top) return;
  var __t0 = Math.round((window.performance && performance.now) ? performance.now() : 0);
  var __orig = null, lastErr = '';
  try { __orig = navigator.getGamepads.bind(navigator); } catch (e) {}
  function note(e){ try { lastErr = String((e && e.message) || e).slice(0, 70); } catch (x) {} }
  try { window.addEventListener('error', function(e){ var m = String(e && e.message); if (/gamepad|pad/i.test(m)) note(m); }); } catch (e) {}
  var N = 17, buttons = [], axes = [0,0,0,0], ts = 0, first = true, i;
  for (i = 0; i < N; i++) buttons.push(0);
  function send(ms, m){
    try {
      if (window.RyzenPad) window.RyzenPad.postMessage(JSON.stringify({ ms: ms, amp: Math.round(Math.max(0, Math.min(1, m)) * 255) }));
    } catch (e) {}
  }
  var rumble = { type: 'dual-rumble',
    playEffect: function(t, p){ p = p || {}; send(p.duration || 0, Math.max(p.strongMagnitude || 0, p.weakMagnitude || 0)); return Promise.resolve('complete'); },
    pulse: function(v, d){ send(d || 0, v || 0); return Promise.resolve(true); },
    reset: function(){ send(0, 0); return Promise.resolve('complete'); } };
  var padObj = { id: 'Xbox 360 Controller (XInput STANDARD GAMEPAD)', index: 0, connected: true,
    mapping: 'standard', timestamp: 0, axes: axes, buttons: [],
    vibrationActuator: rumble, hapticActuators: [rumble] };
  for (i = 0; i < N; i++) padObj.buttons.push({ pressed: false, touched: false, value: 0 });
  // mesmo objeto sempre (como no Chrome): quem guarda a referência continua vendo o estado atual
  function snap(){
    for (var k = 0; k < N; k++) {
      var v = buttons[k], bt = padObj.buttons[k];
      bt.pressed = v > 0.5; bt.touched = v > 0; bt.value = v;
    }
    padObj.timestamp = ts;
    return padObj;
  }
  // xCloud (e outros) só leem o controle quando a página está focada e visível; dentro da
  // WebView do Flutter o documento costuma ficar sem foco, então a leitura nunca começava.
  try { Object.setPrototypeOf(padObj, Gamepad.prototype); } catch (e) {}
  try { document.hasFocus = function(){ return true; }; } catch (e) {}
  try { Object.defineProperty(document, 'visibilityState', { get: function(){ return 'visible'; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(document, 'hidden', { get: function(){ return false; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(document, 'webkitVisibilityState', { get: function(){ return 'visible'; }, configurable: true }); } catch (e) {}
  var frames = 0;
  (function loop(){ frames++; try { requestAnimationFrame(loop); } catch (e) {} })();
  var calls = 0, lis = 0, ups = 0;
  var fn = function(){ calls++; return [snap(), null, null, null]; };
  try { Object.defineProperty(navigator, 'getGamepads', { value: fn, configurable: true, writable: true }); }
  catch (e) { try { navigator.getGamepads = fn; } catch (e2) {} }
  // sites que chamam Navigator.prototype.getGamepads.call(navigator) também passam por aqui
  try { Object.defineProperty(Navigator.prototype, 'getGamepads', { value: fn, configurable: true, writable: true }); } catch (e) {}
  function announce(){
    var ev;
    try { window.dispatchEvent(new Event('focus')); } catch (e) {}
    try { document.dispatchEvent(new Event('visibilitychange')); } catch (e) {}
    try { ev = new Event('gamepadconnected'); ev.gamepad = snap(); window.dispatchEvent(ev); } catch (e) { note(e); }
  }
  window.addEventListener('load', announce);
  // sites (SPA, como o xCloud) registram o ouvinte depois do evento: entrega o gamepad na hora
  var _add = window.addEventListener;
  function replay(l){
    setTimeout(function(){
      try {
        var ev = new Event('gamepadconnected'); ev.gamepad = snap();
        if (typeof l === 'function') l.call(window, ev); else if (l && l.handleEvent) l.handleEvent(ev);
      } catch (e) { note(e); }
    }, 0);
  }
  window.addEventListener = function(t, l, o){
    var r = _add.apply(this, arguments);
    if (t === 'gamepadconnected' && l) { lis++; replay(l); }
    return r;
  };
  var _og = null;
  try {
    Object.defineProperty(window, 'ongamepadconnected', { configurable: true,
      get: function(){ return _og; }, set: function(f){ _og = f; if (f) replay(f); } });
  } catch (e) {}
  window.__rz = { u: function(a){
    ups++;
    var any = false, k;
    for (k = 0; k < N; k++) { buttons[k] = a[k] || 0; if (buttons[k]) any = true; }
    for (k = 0; k < 4; k++) { axes[k] = a[N + k] || 0; if (axes[k]) any = true; }
    ts = (window.performance && performance.now) ? performance.now() : Date.now();
    if (first && any) { first = false; announce(); }
  } };
  var lastCalls = 0, lastFrames = 0;
  setInterval(function(){
    var rp = -1;
    try { if (__orig) { var l = __orig() || [], c2 = 0; for (var q = 0; q < l.length; q++) if (l[q]) c2++; rp = c2; } } catch (e) { note(e); }
    try {
      if (window.RyzenPad) window.RyzenPad.postMessage(JSON.stringify({ diag: {
        cps: calls - lastCalls, lis: lis, ups: ups, wv: /; wv\)/.test(navigator.userAgent) ? 1 : 0,
        top: window === window.top ? 1 : 0, host: location.host,
        raf: frames - lastFrames, ok: (navigator.getGamepads === fn) ? 1 : 0,
        hf: document.hasFocus() ? 1 : 0, t0: __t0, ds: window.__rzDoc ? 1 : 0, rp: rp, err: lastErr } }));
    } catch (e) {}
    lastCalls = calls; lastFrames = frames;
  }, 1000);
})();
''';

/// Gancho no WebRTC da página (xCloud e similares). Roda no início do documento, antes dos scripts do site.
/// jb: 0 padrão, 1 buffer equilibrado (~60 ms), 2 mínimo (20 ms); stats: manda números do stream a cada segundo;
/// h264: pede H.264 primeiro na negociação (costuma ter decodificação por hardware no celular).
String _rtcJs(int jb, bool stats, bool h264) => r'''
(function(cfg){
  if (window.__rzrtc) return; window.__rzrtc = 1;
  var Orig = window.RTCPeerConnection || window.webkitRTCPeerConnection;
  if (!Orig) return;
  var pcs = [];
  function tune(pc) {
    try {
      pc.getReceivers().forEach(function(r){
        if (!r.track) return;
        try { if ('jitterBufferTarget' in r) r.jitterBufferTarget = cfg.jb == 1 ? 60 : 20; } catch (e) {}
        try { if ('playoutDelayHint' in r) r.playoutDelayHint = cfg.jb == 1 ? 0.06 : 0; } catch (e) {}
      });
    } catch (e) {}
  }
  function prefer(pc) {
    try {
      var caps = RTCRtpReceiver.getCapabilities('video');
      if (!caps || !caps.codecs) return;
      var h = [], o = [];
      caps.codecs.forEach(function(c){ (/h264/i.test(c.mimeType) ? h : o).push(c); });
      if (!h.length) return;
      // perfil mais alto primeiro (4d, depois 64, depois 42e/baseline): mais qualidade por bitrate
      var rank = function(c) {
        var f = (c.sdpFmtpLine || '').toLowerCase(), r = 1;
        if (/profile-level-id=4d/.test(f)) r = 4; else if (/profile-level-id=64/.test(f)) r = 3; else if (/profile-level-id=42e/.test(f)) r = 2;
        if (/packetization-mode=1/.test(f)) r += 0.5;
        return r;
      };
      h.sort(function(a, b) { return rank(b) - rank(a); });
      pc.getTransceivers().forEach(function(t){
        try {
          var k = (t.receiver && t.receiver.track) ? t.receiver.track.kind : '';
          if (k === 'video' && t.setCodecPreferences) t.setCodecPreferences(h.concat(o));
        } catch (e) {}
      });
    } catch (e) {}
  }
  function Wrap(a, b) {
    var pc = (b === undefined) ? new Orig(a) : new Orig(a, b);
    pcs.push(pc);
    if (cfg.h264) {
      try {
        var oc = pc.createOffer;
        pc.createOffer = function(){ prefer(pc); return oc.apply(pc, arguments); };
        var at = pc.addTransceiver;
        pc.addTransceiver = function(){ var t = at.apply(pc, arguments); prefer(pc); return t; };
      } catch (e) {}
    }
    if (cfg.jb > 0) {
      pc.addEventListener('track', function(){ tune(pc); setTimeout(function(){ tune(pc); }, 1500); });
      pc.addEventListener('connectionstatechange', function(){ if (pc.connectionState === 'connected') tune(pc); });
    }
    return pc;
  }
  Wrap.prototype = Orig.prototype;
  try { Wrap.generateCertificate = Orig.generateCertificate; } catch (e) {}
  window.RTCPeerConnection = Wrap;
  if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = Wrap;
  if (!cfg.stats) return;
  var last = null;
  setInterval(function(){
    var pc = null;
    for (var i = pcs.length - 1; i >= 0; i--) { if (pcs[i].connectionState === 'connected') { pc = pcs[i]; break; } }
    if (!pc || !window.RyzenStats) return;
    pc.getStats().then(function(rep){
      var v = null, pair = null, codecs = {};
      rep.forEach(function(s){
        if (s.type === 'codec') codecs[s.id] = s.mimeType;
        if (s.type === 'inbound-rtp' && (s.kind === 'video' || s.mediaType === 'video')) v = s;
        if (s.type === 'candidate-pair' && s.nominated && s.currentRoundTripTime != null) pair = s;
      });
      if (!v) return;
      var now = performance.now(), o = {
        w: v.frameWidth || 0, h: v.frameHeight || 0, fps: v.framesPerSecond || 0,
        codec: (codecs[v.codecId] || '').replace('video/', ''),
        lost: v.packetsLost || 0, drop: v.framesDropped || 0,
        rtt: pair ? Math.round(pair.currentRoundTripTime * 1000) : -1
      };
      if (last) {
        var dt = (now - last.t) / 1000;
        if (dt > 0) o.mbps = Math.round((v.bytesReceived - last.b) * 8 / dt / 1e5) / 10;
        var de = (v.jitterBufferEmittedCount || 0) - last.je;
        if (de > 0) o.jb = Math.round(((v.jitterBufferDelay || 0) - last.jd) / de * 1000);
        var df = (v.framesDecoded || 0) - last.fd;
        if (df > 0) o.dec = Math.round(((v.totalDecodeTime || 0) - last.td) / df * 1000 * 10) / 10;
        o.dl = (v.packetsLost || 0) - last.pl;
      }
      last = { t: now, b: v.bytesReceived || 0, je: v.jitterBufferEmittedCount || 0, jd: v.jitterBufferDelay || 0,
               fd: v.framesDecoded || 0, td: v.totalDecodeTime || 0, pl: v.packetsLost || 0 };
      window.RyzenStats.postMessage(JSON.stringify(o));
    }).catch(function(){});
  }, 1000);
})({jb: ''' + '$jb' + ', stats: ' + (stats ? 'true' : 'false') + ', h264: ' + (h264 ? 'true' : 'false') + '});';

/// 1 se a página (ou um iframe visível dela) é o login/escolha de conta da Microsoft.
const _loginProbeJs = r'''
(function(){
  var re = /(^|\.)(login\.live\.com|login\.microsoftonline\.com|login\.microsoft\.com|account\.live\.com)$/;
  if (re.test(location.hostname)) return 1;
  var f = document.querySelectorAll('iframe');
  for (var i = 0; i < f.length; i++) {
    try {
      var u = new URL(f[i].src || 'about:blank', location.href);
      if (re.test(u.hostname)) {
        var r = f[i].getBoundingClientRect();
        if (r.width > 100 && r.height > 100) return 1;
      }
    } catch (e) {}
  }
  return 0;
})()''';

/// Navegador de PC (Edge): serviços como o xCloud liberam 1080p e a melhor codificação.
const _desktopUa =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0';

/// Smart TV Samsung (Tizen): o xCloud libera o 1080p de maior bitrate (HQ). Experimental.
const _tizenUa =
    'Mozilla/5.0 (SMART-TV; LINUX; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) '
    '94.0.4606.31/7.0 TV Safari/537.36';

/// Informa à página uma conexão rápida e sem economia de dados.
const _fastNetJs = r'''
(function(){
  if (window.__rzq) return; window.__rzq = 1;
  try {
    var fake = { effectiveType: '4g', downlink: 50, rtt: 30, saveData: false, type: 'wifi',
      addEventListener: function(){}, removeEventListener: function(){} };
    Object.defineProperty(navigator, 'connection', { get: function(){ return fake; }, configurable: true });
  } catch (e) {}
})();''';

/// Ajuste da tela do vídeo/canvas da página (xCloud etc.).
/// mode: 0 padrão (não mexe), 1 preencher (object-fit: cover), 2 esticar (object-fit: fill).
String _fitJs(int mode) => r'''
(function(m){
  var id = '__rz_fit', e = document.getElementById(id);
  if (!m) { if (e) e.remove(); return; }
  var css = 'video[data-rz],canvas[data-rz]{object-fit:' + (m == 1 ? 'cover' : 'fill') +
      ' !important;width:100% !important;height:100% !important;}';
  if (!e) { e = document.createElement('style'); e.id = id; (document.head || document.documentElement).appendChild(e); }
  if (e.textContent !== css) e.textContent = css;
  var area = innerWidth * innerHeight, l = document.querySelectorAll('video,canvas');
  for (var i = 0; i < l.length; i++) {
    var r = l[i].getBoundingClientRect();
    if (r.width * r.height > area * 0.25) l[i].setAttribute('data-rz', '1');
  }
})(''' + '$mode' + ');';

/// Nitidez: filtro SVG de realce (convolução 3x3) aplicado ao vídeo da página.
/// level: 0 desligado, 1 leve, 2 forte. Não aumenta a resolução; só realça as bordas.
String _sharpJs(int level) => r'''
(function(l){
  var sid = '__rz_sharp_svg', cid = '__rz_sharp_css', s = document.getElementById(sid), c = document.getElementById(cid);
  if (!l) {
    if (s) s.remove(); if (c) c.remove();
    var old = document.querySelectorAll('[data-rzs]');
    for (var j = 0; j < old.length; j++) old[j].removeAttribute('data-rzs');
    return;
  }
  var a = l == 1 ? 0.25 : 0.5, m = [0, -a, 0, -a, 1 + 4 * a, -a, 0, -a, 0].join(' ');
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute"><filter id="__rz_sharp" color-interpolation-filters="sRGB" x="0" y="0" width="100%" height="100%">' +
    '<feConvolveMatrix order="3" kernelMatrix="' + m + '" divisor="1" bias="0" edgeMode="duplicate" preserveAlpha="true"/></filter></svg>';
  if (!s) { s = document.createElement('div'); s.id = sid; (document.body || document.documentElement).appendChild(s); }
  if (s.getAttribute('data-l') != l) { s.innerHTML = svg; s.setAttribute('data-l', l); }
  var css = 'video[data-rzs]{filter:url(#__rz_sharp) contrast(1.03) !important;}';
  if (!c) { c = document.createElement('style'); c.id = cid; (document.head || document.documentElement).appendChild(c); }
  if (c.textContent !== css) c.textContent = css;
  var area = innerWidth * innerHeight, v = document.querySelectorAll('video');
  for (var i = 0; i < v.length; i++) {
    if (v[i].hasAttribute('data-rzs')) continue;
    var r = v[i].getBoundingClientRect();
    if (r.width * r.height > area * 0.25) v[i].setAttribute('data-rzs', '1');
  }
})(''' + '$level' + ');';

/// Jogo em tela cheia: WebView própria, sem barra de endereço.
/// Para sair: botão voltar do Android, ou segurar SELECT + START no controle.
/// O controle inteiro (botões, analógicos, gatilhos, direcional) é lido pelo lado
/// nativo e entregue à página como um gamepad padrão; o B vai para o jogo.
class GameView extends StatefulWidget {
  final String url;
  final int reloadTick;
  final String? title;
  final ImageProvider? cover, banner;
  const GameView({super.key, required this.url, this.reloadTick = 0, this.title, this.cover, this.banner});

  @override
  State<GameView> createState() => _GameViewState();
}

class _GameViewState extends State<GameView> {
  late final WebViewController c;
  bool loading = true;
  bool hint = true;
  List<double> _pad = List<double>.filled(21, 0);
  Timer? _ensure, _hintTimer;
  void Function(List<double>)? _padHandler;
  String _diag = '';
  String _stats = '';
  int _sent = 0;
  bool _early = false;

  bool _checking = false;

  // Na tela de escolha de conta/login da Microsoft a tela de carregamento sai para a pessoa poder tocar;
  // quando a página volta ao xCloud ela volta, até o vídeo do jogo começar.
  void _setOnLogin(String u) {
    final l = isMsLoginHost(Uri.tryParse(u)?.host ?? '');
    if (l != _urlLogin && mounted) setState(() => _urlLogin = l);
  }

  // Além do endereço da página, olha a página por dentro: o login da Microsoft pode abrir em um
  // iframe ou trocar o endereço sem recarregar, e a tela de carregamento taparia a escolha da conta.
  bool _loginChecking = false;
  void _checkLoginPage() {
    if (_loginChecking) return;
    _loginChecking = true;
    c.runJavaScriptReturningResult(_loginProbeJs).then((r) {
      final l = r.toString() == '1';
      if (l != _jsLogin && mounted) setState(() => _jsLogin = l);
    }).catchError((_) {}).whenComplete(() => _loginChecking = false);
  }

  // Zona morta radial: ignora o desvio pequeno do analógico parado (controle com folga/desgaste faz o
  // personagem andar sozinho) e reescala o resto para o curso inteiro, sem salto na borda.
  List<double> _deadzone(List<double> v) {
    if (v.length < 21) return v;
    final dz = st.padDeadzone;
    final o = List<double>.of(v);
    for (final i in const [17, 19]) {
      final x = o[i], y = o[i + 1];
      final len = math.sqrt(x * x + y * y);
      if (len == 0) continue;
      if (len < dz) {
        o[i] = 0;
        o[i + 1] = 0;
      } else {
        final k = ((len > 1 ? 1.0 : len) - dz) / (1 - dz) / len;
        o[i] = (x * k).clamp(-1.0, 1.0).toDouble();
        o[i + 1] = (y * k).clamp(-1.0, 1.0).toDouble();
      }
    }
    return o;
  }


  void _inject() {
    // o script do controle é grande: só reenvia se a página trocou de documento e ele sumiu
    if (!_checking) {
      _checking = true;
      c.runJavaScriptReturningResult('window.__rz ? 1 : 0').then((r) {
        if (r.toString() != '1') c.runJavaScript(_padJs).catchError((_) {});
      }).catchError((_) {}).whenComplete(() => _checking = false);
    }
    c.runJavaScript(_fitJs(st.gameFit)).catchError((_) {});
    if (st.sharpLevel > 0 || _sharpOn) {
      c.runJavaScript(_sharpJs(st.sharpLevel)).catchError((_) {});
      _sharpOn = st.sharpLevel > 0;
    }
    if (st.streamQ >= 1) c.runJavaScript(_fastNetJs).catchError((_) {});
  }

  bool _sharpOn = false;

  // Tela de carregamento própria: só aparece em jogo aberto com nome (Loja/biblioteca) e some
  // quando o vídeo do jogo começa a trazer quadros (ou se a página cair no login da Microsoft).
  late bool _splash = widget.title != null;
  bool _vidChecking = false;
  bool _urlLogin = false, _jsLogin = false; // login/escolha de conta da Microsoft aberto (pelo endereço ou por dentro da página)
  bool get _onLogin => _urlLogin || _jsLogin;
  final DateTime _t0 = DateTime.now();
  int _secs = 0;

  void _checkVideo() {
    if (!_splash || _vidChecking) return;
    _vidChecking = true;
    c
        .runJavaScriptReturningResult(
            "(function(){var v=document.querySelectorAll('video');for(var i=0;i<v.length;i++){var x=v[i];"
            "if(x.readyState>=3&&x.videoWidth>0&&!x.paused&&x.currentTime>0.5)return 1;}return 0;})()")
        .then((r) {
      if (r.toString() == '1' && mounted && _splash) setState(() => _splash = false);
    }).catchError((_) {}).whenComplete(() => _vidChecking = false);
  }

  // Só uma chamada de JavaScript em andamento por vez, sempre com o estado MAIS RECENTE.
  // Antes cada evento do controle (~120/s) virava um runJavaScript; com o vídeo do jogo
  // ocupando a CPU a fila crescia e a página recebia estados velhos (controle "travado").
  bool _sending = false, _dirty = false;
  String _lastSent = '';

  void _push({bool force = false}) {
    if (force) _lastSent = '';
    _dirty = true;
    _flush();
  }

  void _flush() {
    if (_sending || !_dirty || !mounted) return;
    _dirty = false;
    var v = _pad;
    if (st.nintendo && v.length >= 4) {
      // layout Nintendo: troca A↔B e X↔Y
      v = List<double>.of(v);
      final t0 = v[0];
      v[0] = v[1];
      v[1] = t0;
      final t2 = v[2];
      v[2] = v[3];
      v[3] = t2;
    }
    final a = jsonEncode(v.map((e) => double.parse(e.toStringAsFixed(3))).toList());
    if (a == _lastSent) return;
    _lastSent = a;
    _sending = true;
    _sent++;
    c
        .runJavaScript('window.__rz&&window.__rz.u($a)')
        .timeout(const Duration(milliseconds: 300), onTimeout: () {})
        .catchError((_) {})
        .whenComplete(() {
      _sending = false;
      if (_dirty) _flush();
    });
  }

  @override
  void initState() {
    super.initState();
    _padHandler = (v) {
      _pad = _deadzone(v);
      // com o menu rápido aberto o jogo só recebe o "soltar tudo"
      if (st.gameMenu && v.any((e) => e != 0)) return;
      _push();
    };
    Native.onPad = _padHandler;
    Native.setGameMode(true);
    // a WebView pode trocar de documento (SPA, redirecionamentos): garante o gamepad sempre
    _ensure = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (_splash && mounted) {
        final n = DateTime.now().difference(_t0).inSeconds;
        if (n != _secs) setState(() => _secs = n);
        _checkVideo();
      }
      if (_splash) _checkLoginPage();
      _inject();
      _push(force: true); // se a página trocou de documento, reenvia o estado atual
    });
    _hintTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) setState(() => hint = false);
    });
    c = WebViewController(
      onPermissionRequest: (req) async {
        if (await Native.perm('mic')) {
          await req.grant();
        } else {
          await req.deny();
        }
      },
    )
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setUserAgent(st.streamQ >= 2 ? _tizenUa : (st.streamQ >= 1 ? _desktopUa : null))
      ..addJavaScriptChannel('RyzenStats', onMessageReceived: (m) {
        try {
          final j = jsonDecode(m.message) as Map;
          final res = '${j['w']}x${j['h']}';
          final mb = j['mbps'] == null ? '-' : '${j['mbps']} Mbps';
          final jb = j['jb'] == null ? '-' : '${j['jb']} ms';
          final dec = j['dec'] == null ? '-' : '${j['dec']} ms';
          final rtt = (j['rtt'] as num) < 0 ? '-' : '${j['rtt']} ms';
          final t = '$res · ${(j['fps'] as num).round()} FPS · ${j['codec']}\n'
              '$mb · rede $rtt · buffer $jb · decod. $dec\n'
              'perdidos: ${j['dl'] ?? 0}/s (total ${j['lost']}) · quadros descartados: ${j['drop']}';
          if (mounted) setState(() => _stats = t);
        } catch (_) {}
      })
      ..addJavaScriptChannel('RyzenPad', onMessageReceived: (m) {
        try {
          final j = jsonDecode(m.message) as Map;
          final d = j['diag'];
          if (d is Map) {
            final t = 'página lê o controle: ${d['cps']}x/s · ouvintes: ${d['lis']} · '
                'recebido: ${d['ups']} (enviado: $_sent) · quadros: ${d['raf']}/s · hook: ${d['ok']} · foco: ${d['hf']} · inj: ${d['t0']}ms · ${_early ? 'inicio' : 'tarde'} · ds: ${d['ds']} · real: ${d['rp']} · err: ${d['err']}\n'
                '${d['wv'] == 1 ? 'UA WebView' : 'UA normal'} · '
                '${d['top'] == 1 ? 'topo' : 'iframe'} · ${d['host']}';
            if (mounted) setState(() => _diag = t);
            return;
          }
          final ms = (j['ms'] as num).toInt();
          final amp = (j['amp'] as num).toInt();
          Native.rumble(amp <= 0 ? 0 : ms, amp);
        } catch (_) {}
      })
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (r) {
          final u = Uri.tryParse(r.url);
          const inApp = {'http', 'https', 'about', 'data', 'blob', 'javascript'};
          if (u == null || inApp.contains(u.scheme)) return NavigationDecision.navigate;
          Native.openUrl(r.url);
          return NavigationDecision.prevent;
        },
        onPageStarted: (u) {
          _inject();
          _setOnLogin(u);
        },
        onProgress: (_) => _inject(),
        onUrlChange: (ch) {
          final u = ch.url;
          if (u != null) _setOnLogin(u);
        },
        onPageFinished: (u) {
          _inject();
          _setOnLogin(u);
          _push(force: true);
          if (mounted) setState(() => loading = false);
        },
      ))
      ;
    // som/vídeo do jogo tocam sem exigir um toque; microfone liberado para o chat de voz
    final plat = c.platform;
    if (plat is AndroidWebViewController) {
      plat.setMediaPlaybackRequiresUserGesture(false);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  // Registra o gamepad como script de início de documento (antes dos scripts do site) e só
  // então carrega a página. A WebView leva alguns quadros para entrar na tela: tenta várias vezes.
  Future<void> _start() async {
    for (var i = 0; i < 12 && mounted; i++) {
      if (await Native.docScript('window.__rzDoc=1;' + _padJs + ((st.jbLevel > 0 || st.showStats || st.h264) ? _rtcJs(st.jbLevel, st.showStats, st.h264) : ''))) {
        _early = true;
        break;
      }
      await Future.delayed(const Duration(milliseconds: 150));
    }
    if (!mounted) return;
    c.loadRequest(Uri.parse(normalizeUrl(widget.url)));
  }

  @override
  void didUpdateWidget(GameView old) {
    super.didUpdateWidget(old);
    if (old.reloadTick != widget.reloadTick) c.reload();
  }

  @override
  void dispose() {
    _ensure?.cancel();
    _hintTimer?.cancel();
    // se outro GameView já assumiu (troca direta de link), não desliga a captura dele
    if (identical(Native.onPad, _padHandler)) {
      Native.onPad = null;
      Native.setGameMode(false);
      Native.docScript(null);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.black,
      child: Stack(children: [
        Positioned.fill(child: WebViewWidget(controller: c)),
        if (_splash && !_onLogin)
          Positioned.fill(
            child: _LoadingSplash(
              title: widget.title!,
              cover: widget.cover,
              banner: widget.banner,
              secs: _secs,
              onBack: () => st.closeGame(),
            ),
          ),
        if (loading && !(_splash && !_onLogin)) const Center(child: CircularProgressIndicator()),
        if (_stats.isNotEmpty && st.showStats && !st.gameMenu)
          Positioned(
            top: 6,
            right: 8,
            child: IgnorePointer(
              child: Text(_stats,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 11, decoration: TextDecoration.none, backgroundColor: Color(0x99000000))),
            ),
          ),
        if (_diag.isNotEmpty)
          Positioned(
            left: 6,
            bottom: 4,
            child: IgnorePointer(
              child: Text(_diag,
                  style: const TextStyle(
                      color: Color(0xFF7CFC7C), fontSize: 10, decoration: TextDecoration.none, backgroundColor: Color(0x99000000))),
            ),
          ),
        if (hint)
          Positioned(
            top: 12,
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xCC000000),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    tr('Para abrir o menu: segure SELECT + START (ou botão Guia)'),
                    style: const TextStyle(color: Colors.white, fontSize: 14, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
          ),
      ]),
    );
  }
}


String _mmss(int s) {
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, x = s % 60;
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(h)}:${two(m)}:${two(x)}';
}

class _SplashPill extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool icon;
  const _SplashPill({required this.label, required this.onTap, this.icon = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0x66000000),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: const Color(0x66FFFFFF), width: 1.5),
          ),
          child: Text(label,
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600, decoration: TextDecoration.none)),
        ),
      );
}

/// Tela de carregamento do jogo: banner largo do jogo ao fundo, capa, nome, tempo e barra de LED branco.
class _LoadingSplash extends StatefulWidget {
  final String title;
  final ImageProvider? cover, banner;
  final int secs;
  final VoidCallback onBack;
  const _LoadingSplash({required this.title, required this.cover, required this.banner, required this.secs, required this.onBack});

  @override
  State<_LoadingSplash> createState() => _LoadingSplashState();
}

class _LoadingSplashState extends State<_LoadingSplash> with SingleTickerProviderStateMixin {
  // um "relógio" que repinta só a barra a cada quadro: o avanço fica contínuo, sem saltos de pixel
  late final AnimationController _tick = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  final DateTime _t0 = DateTime.now();

  @override
  void dispose() {
    _tick.dispose();
    super.dispose();
  }

  /// Não sabemos o progresso real da fila: a barra enche suave e desacelera, sem nunca voltar nem chegar ao fim.
  double get _progress {
    final t = DateTime.now().difference(_t0).inMicroseconds / 1e6;
    return 0.96 * (1 - math.exp(-t / 28)) + 0.02;
  }

  Widget _ledBar(double h) {
    final barH = math.max(10.0, h * 0.022);
    return RepaintBoundary(
      child: Padding(
        // espaço para o brilho não ser cortado
        padding: EdgeInsets.symmetric(vertical: barH * 1.6, horizontal: barH * 1.2),
        child: AnimatedBuilder(
          animation: _tick,
          builder: (_, __) {
            final pulse = 0.5 + 0.5 * math.sin(_tick.value * 2 * math.pi);
            final p = _progress;
            return LayoutBuilder(builder: (_, box) {
              final w = box.maxWidth;
              final fw = (w * p).clamp(barH, w).toDouble();
              return SizedBox(
                height: barH,
                child: Stack(clipBehavior: Clip.none, children: [
                  // trilho: aro de luz branca ao redor
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: const Color(0x33FFFFFF),
                        borderRadius: BorderRadius.circular(barH),
                        border: Border.all(color: Color.fromRGBO(255, 255, 255, 0.55 + 0.25 * pulse), width: 1.2),
                        boxShadow: [
                          BoxShadow(color: Color.fromRGBO(255, 255, 255, 0.22 + 0.12 * pulse), blurRadius: barH * 1.6),
                        ],
                      ),
                    ),
                  ),
                  // preenchimento em LED branco, com brilho que acompanha a ponta
                  Positioned(
                    left: 0,
                    top: 0,
                    bottom: 0,
                    width: fw,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xCCFFFFFF), Color(0xFFFFFFFF)]),
                        borderRadius: BorderRadius.circular(barH),
                        boxShadow: [
                          BoxShadow(color: Color.fromRGBO(255, 255, 255, 0.55 + 0.25 * pulse), blurRadius: barH * 1.3, spreadRadius: barH * 0.12),
                          BoxShadow(color: const Color(0x66FFFFFF), blurRadius: barH * 3),
                        ],
                      ),
                    ),
                  ),
                ]),
              );
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final banner = widget.banner, cover = widget.cover;
    final cw = (h * 0.5) * 0.78; // capa em pé (proporção ~3:4)
    return DefaultTextStyle(
      style: const TextStyle(color: Colors.white, decoration: TextDecoration.none),
      child: Stack(fit: StackFit.expand, children: [
        const ColoredBox(color: Color(0xFF05070E)),
        // fundo: sempre o banner horizontal do link do jogo (nunca a capa)
        if (banner != null)
          RepaintBoundary(
            child: Image(
              image: banner,
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              filterQuality: FilterQuality.medium,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        // escurece à esquerda (texto legível) e embaixo (barra), sem esconder o banner
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [Color(0xAA05070E), Color(0x2205070E)],
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x00000000), Color(0x99000000)],
              stops: [0.45, 1.0],
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: h * 0.1, vertical: h * 0.1),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
            // capa do jogo na lateral (o fundo é o banner)
            Container(
              width: cw,
              height: cw / 0.78,
              decoration: BoxDecoration(
                color: const Color(0xFF151A2A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0x44FFFFFF)),
                boxShadow: const [BoxShadow(color: Color(0x99000000), blurRadius: 30)],
                image: cover == null ? null : DecorationImage(image: cover, fit: BoxFit.cover),
              ),
              child: cover == null
                  ? Center(child: Text('RYZEN', style: TextStyle(color: Colors.white54, fontSize: h * 0.05, fontWeight: FontWeight.w800, letterSpacing: 3)))
                  : null,
            ),
            SizedBox(width: h * 0.06),
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.title,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.white, fontSize: h * 0.085, fontWeight: FontWeight.w800, height: 1.05, shadows: const [Shadow(color: Color(0xAA000000), blurRadius: 14)])),
                SizedBox(height: h * 0.04),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                  decoration: BoxDecoration(color: const Color(0x55000000), borderRadius: BorderRadius.circular(30), border: Border.all(color: const Color(0x55FFFFFF), width: 1.5)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.cloud_queue_rounded, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    Text(tr('Fila de transmissão'), style: TextStyle(color: Colors.white, fontSize: h * 0.04, fontWeight: FontWeight.w600)),
                  ]),
                ),
                SizedBox(height: h * 0.035),
                Row(children: [
                  Text('${tr('Tempo decorrido')}: ', style: TextStyle(color: const Color(0xDDFFFFFF), fontSize: h * 0.04)),
                  Text(_mmss(widget.secs), style: TextStyle(color: Colors.white, fontSize: h * 0.04, fontWeight: FontWeight.w700)),
                ]),
                _ledBar(h),
                Text(tr('Aguarde enquanto o jogo é carregado…'), style: TextStyle(color: const Color(0xCCFFFFFF), fontSize: h * 0.034)),
              ]),
            ),
          ]),
        ),
        Positioned(left: h * 0.06, bottom: h * 0.06, child: _SplashPill(label: tr('Voltar'), onTap: widget.onBack)),
      ]),
    );
  }
}
