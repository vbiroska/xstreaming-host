import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'i18n.dart';
import 'state.dart';

/// Página de login da conta Microsoft (a mesma do account.microsoft.com).
const _loginUrl =
    'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?scope=https%3A%2F%2Faccount.microsoft.com%2FMBI+openid+profile+offline_access&response_type=code&client_id=81feaced-5ddd-41e7-8bef-3e20a2689bb7&redirect_uri=https%3A%2F%2Faccount.microsoft.com%2Fauth%2Fcomplete-signin-oauth&client-request-id=f044eb3c-75b4-46ca-b685-05aee9cc5f8e&x-client-SKU=MSAL.Desktop&x-client-Ver=4.90.1.0&prompt=login&client_info=1&state=H4sIAAAAAAAEAA3QyYJDMAAA0H-Zq4O9ONIiqhlK0LiV1NaqJfavn3mf8H6ahAqUXQSL1d72nDlEeVQx6ZIGyFqFbczPJ7Zzm224w5dtJlc-VE8zH1H5plSEP4DI0Vonk_B7Hl_IcW6LYhHaM5GdcXN-uoysii4tnmCWRzIhhnlyBczMXFEfhywV_V1WBB23KwNHCh_PGWThpXcRMg_N9wdF1GvnuuWSX3DKsFNpP7w4NQXhU4-k6wzcsxdXf7CL_m2F3hjPSXomZazHLIcW7crLk-jNHxDsTUwtDmWvZ1XeANSCCtPwHUUfphyXIb33rL0DzD9F_OoB9KJoAl8wDGHBmiX-lP8jzhp4JpIl59j9eu1qd_A3aqDyvBaeKuUp9MVedQzLyVUyysGWie0aFJanuwS89W-KaotpfpPw1oYTUnDEw21-3AkDf_4AAQQiCIIBAAA&msaoauth2=true&instance_aware=true&lc=1046&ru=https%3A%2F%2Faccount.microsoft.com%2Faccount';

/// Páginas de login da conta Microsoft.
bool isMsLoginHost(String host) =>
    host.endsWith('login.live.com') ||
    host.endsWith('login.microsoftonline.com') ||
    host.endsWith('login.microsoft.com') ||
    host.endsWith('account.live.com');

/// Tela de login obrigatória: abre o login da conta Microsoft e só libera o app depois que a pessoa
/// entra e a página volta ao account.microsoft.com. O login fica salvo na WebView (cookies),
/// então a tela só aparece na primeira vez.
class MsLoginGate extends StatefulWidget {
  const MsLoginGate({super.key});

  @override
  State<MsLoginGate> createState() => _MsLoginGateState();
}

class _MsLoginGateState extends State<MsLoginGate> {
  late final WebViewController c;
  bool _sawLogin = false, _error = false, _loading = true;

  @override
  void initState() {
    super.initState();
    c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (u) {
          final h = Uri.tryParse(u)?.host ?? '';
          if (isMsLoginHost(h)) _sawLogin = true;
          if (mounted) setState(() {
            _loading = true;
            _error = false;
          });
        },
        onPageFinished: (u) {
          final h = Uri.tryParse(u)?.host ?? '';
          if (isMsLoginHost(h)) {
            _sawLogin = true;
          } else if (_sawLogin && h.endsWith('account.microsoft.com')) {
            // passou pelo login da Microsoft e voltou à conta: login feito
            st.setMsLogged();
            return;
          }
          if (mounted) setState(() => _loading = false);
        },
        onWebResourceError: (e) {
          if (e.isForMainFrame ?? true) {
            if (mounted) setState(() {
              _error = true;
              _loading = false;
            });
          }
        },
      ))
      ..loadRequest(Uri.parse(_loginUrl));
  }

  void _retry() {
    setState(() {
      _error = false;
      _loading = true;
    });
    c.loadRequest(Uri.parse(_loginUrl));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(child: WebViewWidget(controller: c)),
                if (_loading && !_error) const Center(child: CircularProgressIndicator()),
                if (_error)
                  Positioned.fill(
                    child: ColoredBox(
                      color: Colors.black,
                      child: Center(
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          Text(tr('Sem conexão. Conecte-se à internet para entrar.'),
                              style: const TextStyle(color: Colors.white, fontSize: 16, decoration: TextDecoration.none)),
                          const SizedBox(height: 12),
                          FilledButton(onPressed: _retry, child: Text(tr('Tentar de novo'))),
                        ]),
                      ),
                    ),
                  ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
