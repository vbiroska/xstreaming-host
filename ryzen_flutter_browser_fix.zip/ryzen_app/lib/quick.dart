import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'i18n.dart';
import 'state.dart';
import 'ui.dart';

/// Menu rápido: painel do launcher (botão Start) e menu dentro do jogo (Guia ou SELECT+START).
class QuickPanelView extends StatelessWidget {
  const QuickPanelView({super.key});

  Widget _bar(BuildContext c, double f) {
    final s = c.s;
    return Container(
      width: 170 * s,
      height: 10 * s,
      decoration: BoxDecoration(
        color: st.dark ? const Color(0x33FFFFFF) : const Color(0x33000000),
        borderRadius: BorderRadius.circular(5 * s),
      ),
      alignment: Alignment.centerLeft,
      child: FractionallySizedBox(
        widthFactor: f.clamp(0.0, 1.0).toDouble(),
        child: Container(
          decoration: BoxDecoration(color: st.accent, borderRadius: BorderRadius.circular(5 * s)),
        ),
      ),
    );
  }

  Widget _row(BuildContext c, QRow r, bool cur, int i) {
    final s = c.s;
    final slider = r.kind != 'btn';
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => st.tapQuick(i),
      child: Container(
        height: 64 * s,
        margin: EdgeInsets.only(bottom: 8 * s),
        padding: EdgeInsets.symmetric(horizontal: 18 * s),
        decoration: BoxDecoration(
          color: cur ? st.selRow : Colors.transparent,
          borderRadius: BorderRadius.circular(14 * s),
          border: Border.all(color: cur ? st.accent : Colors.transparent, width: 3 * s),
        ),
        child: Row(children: [
          SysIcon(r.icon, 32),
          SizedBox(width: 18 * s),
          Expanded(child: Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 24))),
          if (slider) ...[
            GestureDetector(onTap: () => r.onSide(-1), child: SysIcon('back', 26)),
            SizedBox(width: 10 * s),
            _bar(c, r.frac()),
            SizedBox(width: 10 * s),
            GestureDetector(onTap: () => r.onSide(1), child: SysIcon('arrow-right', 26)),
            SizedBox(width: 14 * s),
            SizedBox(width: 70 * s, child: Text(r.value(), textAlign: TextAlign.right, style: ts(c, 20))),
          ] else
            Text(r.value(), style: ts(c, 20, color: st.subTxt)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final rows = st.quickRows;
    final idx = st.quickIdx.clamp(0, rows.length - 1).toInt();
    final size = MediaQuery.sizeOf(context);
    final inGame = st.gameUrl != null;
    return Stack(children: [
      Positioned.fill(
        child: GestureDetector(onTap: st.closeQuick, child: Container(color: const Color(0xB3000000))),
      ),
      Center(
        child: GestureDetector(
          onTap: () {},
          child: Container(
            width: math.min(720 * s, size.width - 40 * s),
            padding: EdgeInsets.fromLTRB(26 * s, 22 * s, 26 * s, 16 * s),
            decoration: BoxDecoration(
              color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
              borderRadius: BorderRadius.circular(22 * s),
              border: Border.all(color: st.tileEdge),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(inGame ? tr('Menu do jogo') : tr('Painel rápido'), style: ts(context, 30, bold: true)),
              SizedBox(height: 14 * s),
              for (var i = 0; i < rows.length; i++) _row(context, rows[i], i == idx, i),
              SizedBox(height: 4 * s),
              Text(tr('↑↓ Navegar    ←→ Ajustar    A Confirmar    B Fechar'),
                  style: ts(context, 17, color: st.subTxt)),
            ]),
          ),
        ),
      ),
    ]);
  }
}

/// Busca com teclado na tela, pensada para o controle.
class SearchView extends StatefulWidget {
  const SearchView({super.key});
  @override
  State<SearchView> createState() => _SearchViewState();
}

class _SearchViewState extends State<SearchView> {
  final rc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    rc.dispose();
    super.dispose();
  }

  Widget _key(BuildContext c, int i) {
    final s = c.s;
    final cur = !st.inResults && st.kbIdx == i;
    return Expanded(
      child: GestureDetector(
        onTap: () => st.kbTap(i),
        child: Container(
          height: 62 * s,
          margin: EdgeInsets.all(4 * s),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: cur ? st.accent : st.selRow,
            borderRadius: BorderRadius.circular(12 * s),
            border: Border.all(color: cur ? Colors.white : Colors.transparent, width: 2 * s),
          ),
          child: Text(kbKeys[i].toUpperCase(),
              style: ts(c, 24, bold: true, color: cur ? Colors.white : st.txt)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final size = MediaQuery.sizeOf(context);
    final res = st.searchResults;
    if (_last != st.resIdx) {
      _last = st.resIdx;
      final i = st.resIdx;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(rc, i * 166 * s, 166 * s));
    }
    final empty = st.query.isEmpty;
    return Stack(children: [
      Positioned.fill(
        child: GestureDetector(onTap: st.closeLayer, child: Container(color: const Color(0xB3000000))),
      ),
      Center(
        child: GestureDetector(
          onTap: () {},
          child: Container(
            width: math.min(1180 * s, size.width - 40 * s),
            padding: EdgeInsets.all(26 * s),
            decoration: BoxDecoration(
              color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
              borderRadius: BorderRadius.circular(22 * s),
              border: Border.all(color: st.tileEdge),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('Buscar jogos'), style: ts(context, 30, bold: true)),
              SizedBox(height: 10 * s),
              Container(
                height: 60 * s,
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 18 * s),
                alignment: Alignment.centerLeft,
                decoration: BoxDecoration(
                  color: st.selRow,
                  borderRadius: BorderRadius.circular(14 * s),
                  border: Border.all(color: st.accent, width: 2 * s),
                ),
                child: Text(empty ? tr('Digite para buscar') : st.query,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: ts(context, 26, color: empty ? st.subTxt : st.txt)),
              ),
              SizedBox(height: 12 * s),
              for (var r = 0; r < kbKeys.length ~/ kbCols; r++)
                Row(children: [for (var k = 0; k < kbCols; k++) _key(context, r * kbCols + k)]),
              SizedBox(height: 10 * s),
              SizedBox(
                height: 230 * s,
                width: double.infinity,
                child: res.isEmpty
                    ? Center(child: Text(tr('Nenhum resultado.'), style: ts(context, 22, color: st.subTxt)))
                    : ListView.builder(
                        controller: rc,
                        scrollDirection: Axis.horizontal,
                        itemExtent: 166 * s,
                        itemCount: res.length,
                        itemBuilder: (c, i) => GestureDetector(
                          onTap: () => st.openResult(i),
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(4 * s, 10 * s, 12 * s, 10 * s),
                            child: itemTile(c, res[i], st.inResults && i == st.resIdx,
                                frosted: false, radius: 12, margin: 6),
                          ),
                        ),
                      ),
              ),
              SizedBox(height: 6 * s),
              Text(tr('↑↓←→ Mover    A Digitar/Abrir    Y Apagar    B Fechar'),
                  style: ts(context, 17, color: st.subTxt)),
            ]),
          ),
        ),
      ),
    ]);
  }
}

/// Tela de descanso: relógio grande que se move devagar (evita marca na tela).
class IdleScreen extends StatefulWidget {
  const IdleScreen({super.key});
  @override
  State<IdleScreen> createState() => _IdleScreenState();
}

class _IdleScreenState extends State<IdleScreen> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final n = DateTime.now();
    final clock = '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
    final date = '${n.day.toString().padLeft(2, '0')}/${n.month.toString().padLeft(2, '0')}/${n.year}';
    final ang = n.minute / 60 * 2 * math.pi;
    final last = st.lastItem;
    final s = context.s;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => st.wake(),
      child: Container(
        color: const Color(0xE6000000),
        child: AnimatedAlign(
          duration: const Duration(seconds: 2),
          alignment: Alignment(math.sin(ang) * 0.35, math.cos(ang) * 0.25),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(clock, style: ts(context, 150, color: Colors.white, bold: true)),
            Text(date, style: ts(context, 34, color: const Color(0xFFB8BED6))),
            SizedBox(height: 26 * s),
            if (last != null)
              Text('${tr('Continuar')}: ${last.title}', style: ts(context, 26, color: Colors.white)),
            SizedBox(height: 26 * s),
            Text(tr('Descansando · aperte qualquer botão'),
                style: ts(context, 20, color: const Color(0xFF8D94B3))),
          ]),
        ),
      ),
    );
  }
}

/// Vídeo em loop (sem som) como papel de parede. Pausa enquanto um jogo está aberto.
class VideoBg extends StatefulWidget {
  final String path;
  final bool paused;
  const VideoBg({super.key, required this.path, this.paused = false});
  @override
  State<VideoBg> createState() => _VideoBgState();
}

class _VideoBgState extends State<VideoBg> {
  VideoPlayerController? _c;
  bool _ok = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final c = VideoPlayerController.file(File(widget.path));
    _c = c;
    try {
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      if (!widget.paused) await c.play();
      if (mounted) setState(() => _ok = true);
    } catch (_) {}
  }

  @override
  void didUpdateWidget(VideoBg old) {
    super.didUpdateWidget(old);
    if (old.path != widget.path) {
      _c?.dispose();
      _c = null;
      _ok = false;
      _init();
    } else if (_ok) {
      if (widget.paused) {
        _c?.pause();
      } else {
        _c?.play();
      }
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    if (!_ok || c == null) return const SizedBox.expand();
    final v = c.value;
    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(width: v.size.width, height: v.size.height, child: VideoPlayer(c)),
      ),
    );
  }
}
