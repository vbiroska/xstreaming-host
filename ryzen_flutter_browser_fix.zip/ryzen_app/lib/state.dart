import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:flutter/services.dart' show Clipboard, ClipboardData;
import 'covers.dart';
import 'detail.dart';
import 'i18n.dart';
import 'native.dart';

/// Ações de entrada (teclado / direcional / botões do controle).
enum Act { up, down, left, right, accept, cancel, next, prev, details, search, favorite, menu, filterPrev, filterNext }

/// Camadas sobrepostas (seletor de jogos e editores de imagem).
enum Layer { none, games, editApps, editStore, wifi, bt, search, panel, profile, gameInfo }

/// Jogos da Loja, na ordem do arquivo 'jogos'.
const _allStoreTitles = <String>[
  '007 First Light',
  'Asphalt Legends',
  'Bleach: Brave Souls',
  'Call of Duty: Modern Warfare II',
  'Call of Duty: Warzone',
  'Crackdown',
  'DC Universe Online',
  'Delta Force',
  'Disney Speedstorm',
  'Enlisted',
  'Final Fantasy XIV',
  'Fortnite',
  'Genshin Impact',
  'GOALS',
  'Halo Infinite',
  'Killer Instinct',
  'Life is Strange',
  'Life is Strange 2',
  'Little Nightmares III',
  'Marvel Rivals',
  'Naraka: Bladepoint',
  'Neverwinter',
  'Once Human',
  'Rainbow Six Siege',
  'Resident Evil Revelations 2',
  'Rogue Company',
  'SMITE 2',
  'Splitgate',
  'Star Trek: Resurgence',
  'The Finals',
  'The First Descendant',
  'Train Sim World 7',
  'UFL',
  'Vigor',
  'War Thunder',
  'Where Winds Meet',
  'World of Tanks Modern Armor',
  'World of Warships: Legends',
  'Wuthering Waves',
  'Zenless Zone Zero',
];

/// Capas (SteamGridDB) do arquivo 'capas - catálogo'. Só estas são usadas.
const storeCoverUrls = <String, String>{
  '007 First Light': 'https://cdn2.steamgriddb.com/grid/9cd0f2a7c17876d6721916f09bce496c.png',
  'Asphalt Legends': 'https://cdn2.steamgriddb.com/grid/9030f4d08302ac090873dbb9625369c4.jpg',
  'Bleach: Brave Souls': 'https://cdn2.steamgriddb.com/grid/acfb55b55a58e224cc8bb4aa0e0a36cf.png',
  'Call of Duty: Modern Warfare II': 'https://cdn2.steamgriddb.com/grid/5cef43602bc7486da26ba5fbf4483f43.png',
  'Call of Duty: Warzone': 'https://cdn2.steamgriddb.com/grid/da64a736b47e9b601309a3a86f013db0.png',
  'Crackdown': 'https://cdn2.steamgriddb.com/grid/0d866018f63b5c0f9b822175e2c5d72c.png',
  'DC Universe Online': 'https://cdn2.steamgriddb.com/grid/8d13b962933c461a03cd35de9d685ca2.png',
  'Delta Force': 'https://cdn2.steamgriddb.com/grid/32dc53f0bf0d323f9d83c9117211537e.png',
  'Disney Speedstorm': 'https://cdn2.steamgriddb.com/grid/e90a259d24f0277f8c0264f3b9ecb609.png',
  'Enlisted': 'https://cdn2.steamgriddb.com/grid/90bcaa2b87e473e2779dc59f373ce965.jpg',
  'Final Fantasy XIV': 'https://cdn2.steamgriddb.com/grid/0f0daf20cf5762ce062c08441286d72d.png',
  'Fortnite': 'https://cdn2.steamgriddb.com/grid/e9fb9de8a48aecc16094108c8f99ec3f.png',
  'Genshin Impact': 'https://cdn2.steamgriddb.com/grid/128c4e5468edba9fb15b643d4c71dca2.png',
  'GOALS': 'https://cdn2.steamgriddb.com/grid/baf8abb9e51ea2bcc7415853122bb409.png',
  'Halo Infinite': 'https://cdn2.steamgriddb.com/grid/5e6f4ecb84c2cef4254267d8479a3fb4.png',
  'Killer Instinct': 'https://cdn2.steamgriddb.com/grid/8617e5b11a7b27234df8332132f72268.png',
  'Life is Strange': 'https://cdn2.steamgriddb.com/grid/6de3745af2adcec82a5a13207fd2b0fb.png',
  'Life is Strange 2': 'https://cdn2.steamgriddb.com/grid/bfdbc30f191c77257fc190c480a56ca2.png',
  'Little Nightmares III': 'https://cdn2.steamgriddb.com/grid/393ca095fe6861771123648b9ddbdf43.png',
  'Marvel Rivals': 'https://cdn2.steamgriddb.com/grid/ea2f872d27e9488ed72f866003620a83.jpg',
  'Naraka: Bladepoint': 'https://cdn2.steamgriddb.com/grid/d4b448aa9eb0076910531596fcc9c9ce.jpg',
  'Neverwinter': 'https://cdn2.steamgriddb.com/grid/7335ba6042ccf25993775d68f3a21d26.png',
  'Once Human': 'https://cdn2.steamgriddb.com/grid/e3841a802cfdc359d5963b0d94593deb.png',
  'Rainbow Six Siege': 'https://cdn2.steamgriddb.com/grid/d656bba4a3a7032f1dae29ddd6ae0d89.png',
  'Resident Evil Revelations 2': 'https://cdn2.steamgriddb.com/grid/e67eecf0ca844bd510ca62420eb53769.png',
  'Rogue Company': 'https://cdn2.steamgriddb.com/grid/916bb2180ee8407ba21fa465f153923e.png',
  'SMITE 2': 'https://cdn2.steamgriddb.com/grid/d1cf730efac5e50b1ea0bd9750f46356.png',
  'Splitgate': 'https://cdn2.steamgriddb.com/grid/3cd4760f5ac9f99a485994a9234a13b6.png',
  'Star Trek: Resurgence': 'https://cdn2.steamgriddb.com/grid/7ada938aa7f0d165b15f65b954b1e0d5.jpg',
  'The Finals': 'https://cdn2.steamgriddb.com/grid/2a8b50d2b0b3e92c28e79837eaca7b53.png',
  'The First Descendant': 'https://cdn2.steamgriddb.com/grid/a42714ec747e619be50c63bbe376784d.png',
  'Train Sim World 7': 'https://cdn2.steamgriddb.com/grid/d3dba3fc4f9371bb7b5211dbb20a082d.png',
  'UFL': 'https://cdn2.steamgriddb.com/grid/c680c1dd666d518fb808bcd7e2710631.png',
  'Vigor': 'https://cdn2.steamgriddb.com/grid/d3f1b45ce2a613659432ab1425047bf1.jpg',
  'War Thunder': 'https://cdn2.steamgriddb.com/grid/f69aa2b8ef6276214e009a37a7914043.jpg',
  'Where Winds Meet': 'https://cdn2.steamgriddb.com/grid/f217b5bc102a5c703c61f4ea3f1fd064.jpg',
  'World of Tanks Modern Armor': 'https://cdn2.steamgriddb.com/grid/0e01dc761576df14d4a6af8bdf4933a2.png',
  'World of Warships: Legends': 'https://cdn2.steamgriddb.com/grid/a8fb7388c8503a46e82bacf8e1b7d9ee.png',
  'Wuthering Waves': 'https://cdn2.steamgriddb.com/grid/7cee9e13ee29834be975c2164736ad4d.png',
  'Zenless Zone Zero': 'https://cdn2.steamgriddb.com/grid/ec67232d98db337b536a51dfc365f359.jpg',
};

/// Banners (SteamGridDB heroes) do arquivo 'banners - catálogo'. Só estes são usados.
const featBannerUrls = <String, String>{
  '007 First Light': 'https://cdn2.steamgriddb.com/hero/eafbe9e1c794c1fdaffb331aa3f6d415.png',
  'Asphalt Legends': 'https://cdn2.steamgriddb.com/hero/9a9b03d4f2641f01b8ff6bfadb10d774.jpg',
  'Bleach: Brave Souls': 'https://cdn2.steamgriddb.com/hero/855ccf4bfb668f127591305ff3164c47.png',
  'Call of Duty: Modern Warfare II': 'https://cdn2.steamgriddb.com/hero/2f3883de55e83764cb264da3126d2fa3.webp',
  'Call of Duty: Warzone': 'https://cdn2.steamgriddb.com/hero/6aa899171430d12d1ed53cc8c02dc3d6.png',
  'Crackdown': 'https://cdn2.steamgriddb.com/hero/3054788e63c1810b6dad3b9f6775265f.jpg',
  'DC Universe Online': 'https://cdn2.steamgriddb.com/hero/4b50e99828c33d971ba5d9dc661037be.jpg',
  'Delta Force': 'https://cdn2.steamgriddb.com/hero/a2152948f15b20e0f2c508b4a6906ef5.jpg',
  'Disney Speedstorm': 'https://cdn2.steamgriddb.com/hero/1753c9eaa1f6facd35adf671345b6600.png',
  'Enlisted': 'https://cdn2.steamgriddb.com/hero/95c14ff9ca2c5d8ead4a18b1e830d504.png',
  'Final Fantasy XIV': 'https://cdn2.steamgriddb.com/hero/f088f07d118a27f5f81261e4d960ae66.webp',
  'Fortnite': 'https://cdn2.steamgriddb.com/hero/8b153b9a0ea56c71cde2f517c9db1fa3.webp',
  'Genshin Impact': 'https://cdn2.steamgriddb.com/hero/75e913d400755a0d2782fc65e2035e97.webp',
  'GOALS': 'https://cdn2.steamgriddb.com/hero/b4fd88fa7032af3d174535e97fd0745a.png',
  'Halo Infinite': 'https://cdn2.steamgriddb.com/hero/74a7ac36372d9ef2c7b7ff0cc02001d2.webp',
  'Killer Instinct': 'https://cdn2.steamgriddb.com/hero/6313a4d8a77612201899ebdaa8517bd6.png',
  'Life is Strange': 'https://cdn2.steamgriddb.com/hero/51fe2fba6faea9b92809477e2fe80b4c.webp',
  'Life is Strange 2': 'https://cdn2.steamgriddb.com/hero/f47b47a611df8ce65ef10b826ed1ad2e.jpg',
  'Little Nightmares III': 'https://cdn2.steamgriddb.com/hero/170a2a8c3e217217e4561938adae7dbc.webp',
  'Marvel Rivals': 'https://cdn2.steamgriddb.com/hero/e124813d86b2a9ca8a31fb8a1d8e4ffc.webp',
  'Naraka: Bladepoint': 'https://cdn2.steamgriddb.com/hero/94ac524c4fd3a20b66ecefb70d8db8fd.jpg',
  'Neverwinter': 'https://cdn2.steamgriddb.com/hero/ca1df370637de0c95f799368a0cde293.jpg',
  'Once Human': 'https://cdn2.steamgriddb.com/hero/9e1bc97f0030f0437762b235d6e85482.webp',
  'Rainbow Six Siege': 'https://cdn2.steamgriddb.com/hero/fb54043efe4fa7945dd52fd34085d45b.png',
  'Resident Evil Revelations 2': 'https://cdn2.steamgriddb.com/hero/b117f26dde7283f9912d88fe4c42fc20.webp',
  'Rogue Company': 'https://cdn2.steamgriddb.com/hero/d4a23f595d61dbaeb97773096e98c817.png',
  'SMITE 2': 'https://cdn2.steamgriddb.com/hero/8b649862360f1c2b5ccee333c282b1d4.webp',
  'Splitgate': 'https://cdn2.steamgriddb.com/hero/889cc87b407e13184320363013540306.webp',
  'Star Trek: Resurgence': 'https://cdn2.steamgriddb.com/hero/44a55c79211eb4fadfe8d19d5a3682ac.png',
  'The Finals': 'https://cdn2.steamgriddb.com/hero/ef7cbd5b955d10aa0705eceb0c97f2f1.webp',
  'The First Descendant': 'https://cdn2.steamgriddb.com/hero/a7b26cb5b027af620654771254a1a56c.webp',
  'Train Sim World 7': 'https://cdn2.steamgriddb.com/hero/69dd3c923f6badb0f4d5fa11c1c26504.png',
  'UFL': 'https://cdn2.steamgriddb.com/hero/52e02159858a815b615559952013a683.png',
  'Vigor': 'https://cdn2.steamgriddb.com/hero/f72a23858b9865a40479a3ce3f16649e.png',
  'War Thunder': 'https://cdn2.steamgriddb.com/hero/88f053fe2674b2cff28e3a6f306de99d.webp',
  'Where Winds Meet': 'https://cdn2.steamgriddb.com/hero/3244c5565e8519862bc19f0ad6c3ad9b.webp',
  'World of Tanks Modern Armor': 'https://cdn2.steamgriddb.com/hero/4b4c6c207e1e59c5af70b3b4c7b46c5a.png',
  'World of Warships: Legends': 'https://cdn2.steamgriddb.com/hero/e08dfc13a6d106f032f49aca8caa4f2f.jpg',
  'Wuthering Waves': 'https://cdn2.steamgriddb.com/hero/467792ff7af12b057e9dc97202d95ef0.webp',
  'Zenless Zone Zero': 'https://cdn2.steamgriddb.com/hero/4ab51fabd2ea0f563ec64f8951cac5e9.webp',
};

/// Capas em pé da Loja (título -> link direto da imagem). Baixadas uma vez e guardadas no aparelho.
/// Jogo sem link aqui, ou cujo link falhar, é procurado no catálogo do Xbox.
/// Todos os jogos da Loja (com ou sem link de jogar; sem link abre pelo serviço de nuvem).
/// Banners (imagem larga) do card azul da Início (título -> link direto). Baixados uma vez e guardados no aparelho.
/// Jogo sem link aqui, ou cujo link falhar, é procurado no uhdpaper.
final storeTitles = List<String>.unmodifiable(_allStoreTitles);

/// Links padrão de cada jogo da Loja (título -> link).
/// Quem editar o link no app (toque longo) sobrescreve o padrão;
/// apagar o link volta para o padrão daqui.
const defaultStoreLinks = <String, String>{
  '007 First Light': 'https://play.xbox.com/stream/9PN198B459VB/007-first-light',
  'Asphalt Legends': 'https://play.xbox.com/stream/9NZQPT0MWTD0/asphalt-legends',
  'Bleach: Brave Souls': 'https://play.xbox.com/stream/9NNRNX65NKNB/bleach-brave-souls-anime-game',
  'Call of Duty: Modern Warfare II': 'https://play.xbox.com/stream/9N872NBW5XG5/call-of-duty-modern-warfare-ii',
  'Call of Duty: Warzone': 'https://play.xbox.com/stream/9NNFG8BQRCXL/call-of-duty-warzone',
  'Crackdown': 'https://play.xbox.com/stream/C3VNJHHD7MM4/crackdown',
  'DC Universe Online': 'https://play.xbox.com/stream/9PPBQVV15N4P/dc-universe-online-for-xbox-series-xs',
  'Delta Force': 'https://play.xbox.com/stream/9NRMZXGKP4NM/delta-force',
  'Disney Speedstorm': 'https://play.xbox.com/stream/9PMR3T9NSF8W/disney-speedstorm',
  'Enlisted': 'https://play.xbox.com/stream/9NHKL695M9F2/enlisted',
  'Final Fantasy XIV': 'https://play.xbox.com/stream/9NGN7D8GJN02/final-fantasy-xiv-online-free-trial',
  'Fortnite': 'https://play.xbox.com/stream/BT5P2X999VH2/fortnite',
  'Genshin Impact': 'https://play.xbox.com/stream/9N7TFFRRZCC9/genshin-impact',
  'Halo Infinite': 'https://play.xbox.com/stream/9PP5G1F0C2B6/halo-infinite',
  'Killer Instinct': 'https://play.xbox.com/stream/BP4S3XLJG78M/killer-instinct',
  'Life is Strange': 'https://play.xbox.com/stream/BP5HKF86C1NJ/life-is-strange',
  'Life is Strange 2': 'https://play.xbox.com/stream/BTNTWQD5V8WG/life-is-strange-2-episodio-1',
  'Little Nightmares III': 'https://play.xbox.com/stream/9PMWB693ZK7X/little-nightmares-iii',
  'Marvel Rivals': 'https://play.xbox.com/stream/9N8PMW7QMD3D/marvel-rivals',
  'Naraka: Bladepoint': 'https://play.xbox.com/stream/9P8SQQJ5T94B/naraka-bladepoint',
  'Neverwinter': 'https://play.xbox.com/stream/C0GQP41KXPVZ/neverwinter',
  'Once Human': 'https://play.xbox.com/stream/9N0QWXC09MPT/once-human',
  'Rainbow Six Siege': 'https://play.xbox.com/stream/C12T09DSVP8J/tom-clancys-rainbow-six-siege',
  'Resident Evil Revelations 2': 'https://play.xbox.com/stream/C2BD1F6CB3L5/resident-evil-revelations-2-episodio-1',
  'Rogue Company': 'https://play.xbox.com/stream/BPHSZ44NGDB2/rogue-company',
  'SMITE 2': 'https://play.xbox.com/stream/9NV8W1KJSQLL/smite-2',
  'Splitgate': 'https://play.xbox.com/stream/9P4S1BPJLPHZ/splitgate',
  'Star Trek: Resurgence': 'https://play.xbox.com/stream/C3LF9PCRP9RP/star-trek-online',
  'The Finals': 'https://play.xbox.com/stream/9PGD71CMDS0Z/the-finals',
  'The First Descendant': 'https://play.xbox.com/stream/9P8FBXKMCLWC/the-first-descendant',
  'Train Sim World 7': 'https://play.xbox.com/stream/9NLX1C7RRBRP/train-sim-world-7-free-starter-edition',
  'UFL': 'https://play.xbox.com/stream/9NBBQK8PR7D6/ufl',
  'Vigor': 'https://play.xbox.com/stream/BQL8L17RV09Z/vigor',
  'War Thunder': 'https://play.xbox.com/stream/BX1DTCBD1HXJ/war-thunder',
  'Where Winds Meet': 'https://play.xbox.com/stream/9N76QGDS5GJR/where-winds-meet',
  'World of Tanks Modern Armor': 'https://play.xbox.com/stream/C57L9GR0HHB7/world-of-tanks-modern-armor',
  'World of Warships: Legends': 'https://play.xbox.com/stream/C1ZT6N30L1WH/world-of-warships-legends',
  'Wuthering Waves': 'https://play.xbox.com/stream/9P41GS5W1C6L/wuthering-waves',
  'Zenless Zone Zero': 'https://play.xbox.com/stream/9N4X0WFZ2STM/zenless-zone-zero',
};

class CloudSvc {
  final String name;
  final String? pkg, url;
  const CloudSvc(this.name, {this.pkg, this.url});
}

/// Serviços de jogos na nuvem para onde a Loja pode levar.
const cloudServices = <CloudSvc>[
  CloudSvc('GeForce NOW', pkg: 'com.nvidia.geforcenow'),
  CloudSvc('Moonlight', pkg: 'com.limelight'),
  CloudSvc('Steam Link', pkg: 'com.valvesoftware.steamlink'),
  CloudSvc('Xbox Cloud Gaming', url: 'https://www.xbox.com/play'),
];


class SetRow {
  final String title, icon, kind, sub;
  final String? key;
  final List<String> options;
  const SetRow(this.title, this.icon, this.kind, this.sub, {this.key, this.options = const []});
}

const settingRows = <SetRow>[
  SetRow('Tema', 'brightness', 'choice', 'Claro, escuro ou automático (escuro das 18h às 6h)',
      key: 'theme', options: ['Claro', 'Escuro', 'Auto']),
  SetRow('Meus jogos', 'gamepad', 'games', ''),
  SetRow('Mostrar só jogos selecionados', 'star', 'toggle',
      'Desligado: mostra todos os apps do aparelho', key: 'only'),
  SetRow('Papel de parede', 'folder', 'wall', 'Padrões do tema + imagens que você escolher'),
  SetRow('Imagem do dispositivo', 'search', 'pick',
      'A: escolher uma imagem da galeria · Direita: remover a atual (se for sua)'),
  SetRow('Vídeo de fundo', 'play', 'pickvideo',
      'A: escolher um vídeo da galeria (toca em loop, sem som) · Direita: remover'),
  SetRow('Ícones dos aplicativos', 'gamepad', 'gameicons',
      'Troque o ícone/capa de cada app e jogo da biblioteca · A: editar'),
  SetRow('Ícones da loja', 'store', 'storeicons',
      'Escolha a capa de cada jogo da loja, direto da galeria · A: editar'),
  SetRow('Serviço de nuvem', 'download', 'cloud',
      'Onde os jogos da Loja abrem · esquerda/direita: trocar'),
  SetRow('Transparência dos cards', 'info', 'choice', 'Intensidade do vidro fosco, estilo PS5',
      key: 'glass', options: ['Leve', 'Médio', 'Forte']),
  SetRow('Sons de navegação', 'bell', 'toggle', 'Sons estilo PS5 ao navegar, confirmar e voltar',
      key: 'sound'),
  SetRow('Wi-Fi', 'wifi', 'sys', '', key: 'wifi'),
  SetRow('Bluetooth', 'bluetooth', 'sys', '', key: 'bluetooth'),
  SetRow('Volume', 'volume', 'volume', 'Esquerda/direita: ajustar · A: mudo/som'),
  SetRow('Mostrar relógio', 'clock', 'toggle', 'Hora na barra superior', key: 'clock'),
  SetRow('Mostrar bateria', 'battery-100', 'toggle', 'Ícone e porcentagem da bateria',
      key: 'battery'),
  SetRow('Mostrar Bluetooth', 'bluetooth', 'toggle', 'Ícone na barra superior', key: 'bt'),
  SetRow('Capas da Microsoft', 'download', 'toggle',
      'Busca sozinha a capa dos jogos na Microsoft Store (precisa de internet)', key: 'ms'),
  SetRow('Mostrar capa inteira', 'gamepad', 'toggle',
      'Exibe a imagem completa nos cards, sem cortar', key: 'fit'),
  SetRow('Layout Nintendo (A↔B, X↔Y)', 'gamepad', 'toggle',
      'Troca A↔B e X↔Y nos jogos da nuvem (estilo Nintendo)', key: 'nintendo'),
  SetRow('Idioma / Language', 'info', 'choice', 'Idioma da interface',
      key: 'lang', options: ['PT', 'EN']),
  SetRow('Ajuste da tela do jogo', 'gamepad', 'choice',
      'Links e nuvem: Padrão, Preencher (corta as bordas) ou Esticar (sem cortar)',
      key: 'gfit', options: ['Padrão', 'Preencher', 'Esticar']),
  SetRow('Qualidade do streaming', 'gamepad', 'choice',
      'Alta: 1080p (modo PC). Máxima (teste): 1080p de maior bitrate (modo Smart TV); se o site ficar estranho, volte para Alta. A qualidade final depende da sua assinatura e internet. Vale ao abrir o jogo',
      key: 'sq', options: ['Padrão', 'Alta', 'Máxima (teste)']),
  SetRow('Perfil', 'user', 'profile', 'Foto e nome'),
  SetRow('Buffer do vídeo', 'gamepad', 'choice',
      'Equilibrado: buffer pequeno e estável, ajuda contra quadros descartados. Mínimo: menor latência, mas pode picotar. Vale ao abrir o jogo',
      key: 'lowlat', options: ['Padrão', 'Equilibrado', 'Mínimo']),
  SetRow('Estatísticas do streaming', 'info', 'toggle',
      'Mostra resolução, FPS, bitrate, perda, latência e codec durante o jogo. Vale ao abrir o jogo',
      key: 'stats'),
  SetRow('Testar controle', 'gamepad', 'padtest',
      'Abre uma tela que mostra botões e analógicos em tempo real'),
  SetRow('Nitidez da imagem', 'gamepad', 'choice',
      'Realça as bordas do vídeo. Não aumenta a resolução e pode pesar em aparelhos fracos. Vale ao abrir o jogo',
      key: 'sharp', options: ['Desligada', 'Leve', 'Forte']),
  SetRow('Preferir H.264 (teste)', 'gamepad', 'toggle',
      'Pede o codec H.264 ao serviço, que costuma decodificar por hardware. Confira o codec nas estatísticas. Vale ao abrir o jogo',
      key: 'h264'),
  SetRow('Zona morta dos analógicos', 'gamepad', 'choice',
      'Se o personagem anda sozinho, aumente. Ignora o movimento pequeno do analógico parado. Vale na hora',
      key: 'dz', options: ['10%', '15%', '20%', '25%', '30%']),
];

/// Categorias da aba Config (menu lateral). `rows` são índices de [settingRows].
class SetCat {
  final String title, icon, sub;
  final List<int> rows;
  const SetCat(this.title, this.icon, this.sub, this.rows);
}

const settingCats = <SetCat>[
  SetCat('Aparência', 'brightness', 'Tema, papel de parede e estilo dos cards.', [0, 3, 4, 5, 9, 18]),
  SetCat('Jogos', 'gamepad', 'Biblioteca, ícones, capas e serviço de nuvem.', [1, 2, 6, 7, 8, 17, 21, 22, 24, 25, 27, 28]),
  SetCat('Controles', 'gamepad', 'Layout e teste do controle.', [19, 26, 29]),
  SetCat('Áudio', 'volume', 'Volume e sons de navegação.', [13, 10]),
  SetCat('Rede', 'wifi', 'Wi-Fi e Bluetooth.', [11, 12]),
  SetCat('Sistema', 'settings', 'Barra superior e idioma.', [14, 15, 16, 20]),
  SetCat('Perfil', 'user', 'Foto e nome.', [23]),
];

int catOfRow(int i) {
  for (var c = 0; c < settingCats.length; c++) {
    if (settingCats[c].rows.contains(i)) return c;
  }
  return 0;
}

/// Página local de teste do controle (mostra botões, analógicos e gatilhos em tempo real).
const _padTestHtml = r'''<meta name="viewport" content="width=device-width,initial-scale=1">
<body style="background:#000;color:#fff;font:18px monospace;margin:14px">
<h3>Teste do controle</h3><pre id="o">Aperte um botão…</pre>
<script>
function f(){
  var g = navigator.getGamepads && navigator.getGamepads()[0], t = '';
  if (g) {
    t += g.id + '\n\nBotões apertados: ';
    var any = false;
    for (var i = 0; i < g.buttons.length; i++) if (g.buttons[i].pressed) { t += '[' + i + '] '; any = true; }
    if (!any) t += '-';
    t += '\n\nAnalógicos:\n';
    for (i = 0; i < g.axes.length; i++) t += ' eixo ' + i + ': ' + g.axes[i].toFixed(2) + '\n';
    t += '\nGatilhos: L2=' + g.buttons[6].value.toFixed(2) + '  R2=' + g.buttons[7].value.toFixed(2);
    t += '\n\n0=A 1=B 2=X 3=Y 4=L1 5=R1 6=L2 7=R2\n8=Select 9=Start 10=L3 11=R3\n12-15=direcional 16=Guia';
  } else {
    t = 'Nenhum controle detectado pela página.';
  }
  document.getElementById('o').textContent = t;
  requestAnimationFrame(f);
}
f();
</script>''';

final String padTestUrl = 'data:text/html;charset=utf-8,${Uri.encodeComponent(_padTestHtml)}';

/// Linha do menu rápido (painel do launcher e menu dentro do jogo).
/// kind: btn | vol | bri
class QRow {
  final String title, icon, kind;
  final String Function() value;
  final double Function() frac;
  final VoidCallback onAccept;
  final void Function(int) onSide;
  const QRow(this.title, this.icon, this.kind, this.value, this.onAccept, this.onSide,
      {this.frac = _zero});
}

double _zero() => 0;

const libFilters = ['Todos', 'Favoritos', 'Nuvem', 'Apps'];
const kbKeys = [
  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
  'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
  'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3',
  '4', '5', '6', '7', '8', '9', '␣', '⌫', '✕', '-',
];
const kbCols = 10;

class HomeItem {
  final AppInfo? app;
  final int storeIndex; // -1 quando é um app/jogo
  HomeItem.store(this.storeIndex) : app = null;
  HomeItem.app(AppInfo a)
      : app = a,
        storeIndex = -1;
  bool get isStore => app == null;
  String get title => isStore ? storeTitles[storeIndex] : app!.name;
}

class WallOpt {
  final String key, name;
  const WallOpt(this.key, this.name);
}

const _builtinWalls = <int, String>{
  2: 'Personalizado 2',
  3: 'Oceano',
  4: 'Neon',
  5: 'Floresta',
  6: 'Rosa',
  7: 'Grafite',
  8: 'Ryzen',
  10: 'Personalizado 10',
};

final st = RyzenState();

class RyzenState extends ChangeNotifier with WidgetsBindingObserver {
  late SharedPreferences _p;
  bool ready = false;
  bool msLogged = false; // passou pela tela de login da Microsoft


  // ---------- navegação ----------
  int tab = 0;
  Layer layer = Layer.none;
  int infoIdx = 0, infoFocus = 0, relIdx = 0, trIdx = 0, shotOpen = -1; // trIdx: 0 = trailer, 1.. = capturas
  String infoMsg = '';
  /// Link de jogo aberto em tela cheia (null = nenhum).
  String? gameUrl;
  String? gameTitle; // jogo aberto pela Loja/biblioteca (tela de carregamento)
  ImageProvider? gameCover, gameBanner;
  int homeIdx = 0, libIdx = 0, storeIdx = 0, setIdx = 0, pickIdx = 0, editIdx = 0;
  // ---------- perfil ----------
  String profName = '', profPhoto = '';
  int profIdx = 0, nameTick = 0, cropTick = 0;
  String? cropSrc; // foto escolhida, aguardando o corte

  int setCat = 0;
  bool setSide = true; // foco no menu lateral da Config (true) ou nas opções (false)
  int libCols = 6, storeCols = 6;

  // ---------- configurações ----------
  int themeMode = 0; // 0 claro, 1 escuro, 2 auto
  int glassLevel = 1;
  bool showStats = false, h264 = false; // ajustes do vídeo (valem ao abrir o jogo)
  int jbLevel = 0; // buffer do vídeo: 0 padrão, 1 equilibrado, 2 mínimo
  int sharpLevel = 0; // nitidez: 0 desligada, 1 leve, 2 forte
  int padDz = 0; // zona morta dos analógicos: 0 10%, 1 15%, 2 20%, 3 25%, 4 30%
  double get padDeadzone => 0.10 + 0.05 * padDz;
  bool get lowLat => jbLevel == 2;
  int streamQ = 0; // qualidade do streaming: 0 padrão, 1 alta (modo desktop), 2 máxima (Smart TV)
  int gameFit = 0; // ajuste da tela nos links/jogos: 0 padrão, 1 preencher, 2 esticar
  bool soundOn = true, showClock = true, showBattery = true, showBt = true;
  bool fitImages = true, onlySelected = true, msCovers = true;
  String wallKey = 'default';
  List<String> customWalls = [];
  Set<String> selected = {};
  List<String> pinned = [];
  Map<String, String> gameMap = {}, storeMap = {}, storeLinks = {}, autoLinks = {};
  int cloudService = 0;
  Set<String> favs = {};
  bool nintendo = false;
  String lang = 'pt';
  int brightness = -1; // -1 = ainda não lido/ajustado
  String? videoWall;
  Map<String, int> playSecs = {}, lastPlayed = {}, msMiss = {};
  Map<String, String> msMap = {};
  bool _fetchingCovers = false;

  // ---------- banners do destaque (Início) ----------
  Map<String, String> bannerMap = {};
  Map<String, int> bannerMiss = {};
  int featIdx = 0;
  bool _fetchingBanners = false;
  Map<String, String> storeCovMap = {};
  Map<String, int> storeCovMiss = {};
  bool _fetchingStoreCovs = false;
  String covInfo = 'Capas: aguardando…', bannerInfo = '';
  Timer? _featTimer;

  // ---------- sistema ----------
  List<AppInfo> apps = [];
  List<AppInfo> shown = [];
  List<HomeItem> homeItems = [];
  /// Fileira "Últimos Jogos" da Início: jogados mais recentemente primeiro.
  List<HomeItem> recentItems = [];
  int pinnedCount = 0;
  /// Itens da Biblioteca já filtrados pela coleção atual (libFilter).
  List<HomeItem> libItems = [];
  int libFilter = 0;

  // ---------- menu rápido / busca / descanso / controle ----------
  bool gameMenu = false;
  int menuIdx = 0, panelIdx = 0, reloadTick = 0;
  String query = '';
  int kbIdx = 0, resIdx = 0;
  bool inResults = false;
  DateTime lastInput = DateTime.now();
  bool idle = false;
  bool padConnected = false;
  int padBattery = -1;
  String padName = '';
  final Map<String, Color> _tints = {};
  final Set<String> _tinting = {};
  int battery = -1;
  bool charging = false;
  bool wifiEnabled = false, wifiConnected = false, btOn = false, muted = false;
  int volumePct = -1;

  // ---------- listas de Wi-Fi / Bluetooth ----------
  List<WifiNet> wifiNets = [];
  List<BtDev> btDevs = [];
  bool scanning = false;
  String netMsg = '';
  int netIdx = 0;
  bool night = false;

  Timer? _timer;
  DateTime _appsAt = DateTime.fromMillisecondsSinceEpoch(0);
  String? _launchPkg; // chave de jogo aberto fora do Ryzen (app ou serviço de nuvem)
  DateTime? _launchAt;
  String? _webKey; // chave de jogo da Loja aberto em tela cheia dentro do Ryzen
  DateTime? _webAt;
  bool _sfxReady = false;
  final Map<String, AudioPlayer> _players = {};

  // ---------- tema ----------
  bool get dark => themeMode == 1 || (themeMode == 2 && night);
  Color get txt => dark ? const Color(0xFFF2F4FB) : const Color(0xFF1B2030);
  Color get subTxt => dark ? const Color(0xFF9AA3C4) : const Color(0xFF555A6E);
  double get glassAlpha => const [0.28, 0.42, 0.58][glassLevel];
  double get glassBlur => const [24.0, 40.0, 64.0][glassLevel];
  Color get glass => dark
      ? const Color.fromRGBO(23, 28, 56, 1).withValues(alpha: glassAlpha)
      : Colors.white.withValues(alpha: glassAlpha);
  Color get tileEdge => dark ? const Color(0x40FFFFFF) : const Color(0x99FFFFFF);
  Color get selRow => dark ? const Color(0x33FFFFFF) : const Color(0x66FFFFFF);
  Color get pill => dark ? const Color(0x664A5580) : const Color(0xB3FFFFFF);
  Color get accent => const Color(0xFF4A63D6);
  bool get hasBattery => battery >= 0;

  // ---------- inicialização ----------
  Future<void> init() async {
    WidgetsBinding.instance.addObserver(this);
    Native.onGameBack = () => act(Act.cancel);
    _p = await SharedPreferences.getInstance();
    themeMode = _p.getInt('themeMode') ?? 0;
    glassLevel = (_p.getInt('glassLevel') ?? 1).clamp(0, 2).toInt();
    gameFit = (_p.getInt('gameFit') ?? 0).clamp(0, 2).toInt();
    streamQ = (_p.getInt('streamQ') ?? 0).clamp(0, 2).toInt();
    jbLevel = (_p.getInt('jbLevel') ?? ((_p.getBool('lowLat') ?? false) ? 2 : 0)).clamp(0, 2).toInt();
    sharpLevel = (_p.getInt('sharpLevel') ?? 0).clamp(0, 2).toInt();
    h264 = _p.getBool('h264') ?? false;
    padDz = (_p.getInt('padDz') ?? 0).clamp(0, 4).toInt();
    msLogged = _p.getBool('msLogged') ?? false;
    showStats = _p.getBool('showStats') ?? false;
    soundOn = _p.getBool('soundOn') ?? true;
    showClock = _p.getBool('showClock') ?? true;
    showBattery = _p.getBool('showBattery') ?? true;
    showBt = _p.getBool('showBt') ?? true;
    fitImages = _p.getBool('fitImages') ?? true;
    onlySelected = _p.getBool('onlySelected') ?? true;
    msCovers = _p.getBool('msCovers') ?? true;
    msMap = _strMap(_p.getString('msMap'));
    msMiss = _intMap(_p.getString('msMiss'));
    bannerMap = _strMap(_p.getString('bannerMap'));
    bannerMiss = _intMap(_p.getString('bannerMiss'));
    storeCovMap = _strMap(_p.getString('storeCovMap'));
    storeCovMiss = _intMap(_p.getString('storeCovMiss'));
    if ((_p.getInt('covAnim') ?? 0) != 5) {
      // capas da Loja agora priorizam as animadas: apaga as baixadas antes
      try {
        final base = await getApplicationSupportDirectory();
        for (final n in const ['sgdb', 'xbox', 'xbox_covers']) {
          final d = Directory('${base.path}/$n');
          if (d.existsSync()) d.deleteSync(recursive: true);
        }
      } catch (_) {}
      storeCovMap = {};
      storeCovMiss = {};
      _saveMap('storeCovMap', storeCovMap);
      _saveMap('storeCovMiss', storeCovMiss);
      _p.setInt('covAnim', 5);
    }
    if ((_p.getInt('covFix') ?? 0) < 1) {
      // novas capas de Wuthering Waves, Zenless Zone Zero e Call of Duty: descarta só as antigas
      for (final t in const ['Wuthering Waves', 'Zenless Zone Zero', 'Call of Duty']) {
        final f = storeCovMap.remove(t);
        storeCovMiss.remove(t);
        try {
          if (f != null && File(f).existsSync()) File(f).deleteSync();
        } catch (_) {}
      }
      _saveMap('storeCovMap', storeCovMap);
      _saveMap('storeCovMiss', storeCovMiss);
      _p.setInt('covFix', 1);
    }
    if ((_p.getInt('bannerSrc') ?? 0) != 3) {
      // banners agora vêm dos links da lista (e do uhdpaper só como reserva): apaga os baixados antes
      try {
        final base = await getApplicationSupportDirectory();
        final d = Directory('${base.path}/msbanners');
        if (d.existsSync()) d.deleteSync(recursive: true);
      } catch (_) {}
      bannerMap = {};
      bannerMiss = {};
      _saveMap('bannerMap', bannerMap);
      _saveMap('bannerMiss', bannerMiss);
      _p.setInt('bannerSrc', 3);
    }
    if ((_p.getInt('catV') ?? 0) < 6) {
      // catálogo novo (40 jogos): descarta capas, banners, favoritos e links do catálogo antigo
      try {
        final base = await getApplicationSupportDirectory();
        for (final n in const ['xbox_covers', 'msbanners']) {
          final d = Directory('${base.path}/$n');
          if (d.existsSync()) d.deleteSync(recursive: true);
        }
      } catch (_) {}
      storeCovMap = {};
      storeCovMiss = {};
      bannerMap = {};
      bannerMiss = {};
      _saveMap('storeCovMap', storeCovMap);
      _saveMap('storeCovMiss', storeCovMiss);
      _saveMap('bannerMap', bannerMap);
      _saveMap('bannerMiss', bannerMiss);
      _saveMap('storeMap', {});
      _saveMap('storeLinks', {});
      _saveMap('autoLinks', {});
      _p.setStringList('pinnedStore', []);
      _p.setInt('catV', 6);
    }
    wallKey = _p.getString('wallKey') ?? 'default';
    customWalls = _p.getStringList('customWalls') ?? [];
    selected = (_p.getStringList('myGames') ?? []).toSet();
    pinned = _p.getStringList('pinnedStore') ?? [];
    gameMap = _strMap(_p.getString('gameMap'));
    storeMap = _strMap(_p.getString('storeMap'));
    storeLinks = _strMap(_p.getString('storeLinks'));
    autoLinks = _strMap(_p.getString('autoLinks'));
    cloudService = (_p.getInt('cloudService') ?? 0).clamp(0, cloudServices.length - 1).toInt();
    playSecs = _intMap(_p.getString('playSecs'));
    lastPlayed = _intMap(_p.getString('lastPlayed'));
    favs = (_p.getStringList('favs') ?? []).toSet();
    nintendo = _p.getBool('nintendo') ?? false;
    lang = _p.getString('lang') ?? 'pt';
    videoWall = _p.getString('videoWall');
    final sb = _p.getInt('brightness');
    if (sb != null) {
      brightness = sb;
      Native.setBrightness(sb);
    }
    Native.onGameMenu = () {
      if (gameUrl != null && !gameMenu) openQuick();
    };
    Native.onMenuKey = (k) => act(switch (k) {
          'up' => Act.up,
          'down' => Act.down,
          'left' => Act.left,
          'right' => Act.right,
          'accept' => Act.accept,
          _ => Act.cancel,
        });
    _rebuild();
    profName = _p.getString('profName') ?? '';
    profPhoto = _p.getString('profPhoto') ?? '';
    // sem tela de boas-vindas e sem login Google: apaga o que versões antigas guardaram
    for (final k in const ['gName', 'gEmail', 'gPhoto', 'welcomeDone']) {
      _p.remove(k);
    }
    ready = true;
    notifyListeners();
    await refreshApps();
    await _tick();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _tick());
    _featTimer = Timer.periodic(const Duration(seconds: 7), (_) {
      if (tab == 0 && layer == Layer.none && featItems.length > 1) featMove(1);
    });
    fetchBanners();
    fetchStoreCovers();
    Future.delayed(const Duration(milliseconds: 900), () => _sfxReady = true);
  }

  Map<String, String> _strMap(String? j) {
    if (j == null) return {};
    try {
      return (jsonDecode(j) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return {};
    }
  }

  Map<String, int> _intMap(String? j) {
    if (j == null) return {};
    try {
      return (jsonDecode(j) as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    } catch (_) {
      return {};
    }
  }

  void _saveMap(String key, Map<String, dynamic> m) => _p.setString(key, jsonEncode(m));

  Future<void> refreshApps() async {
    final l = await Native.listApps();
    _appsAt = DateTime.now();
    if (l.isEmpty && apps.isNotEmpty) return;
    apps = l;
    _rebuild();
    notifyListeners();
    fetchCovers();
  }

  // ---------- capas da Microsoft ----------
  /// Baixa capas que faltam (uma por vez, em segundo plano). [force] ignora os "não achei" antigos.
  Future<void> fetchCovers({bool force = false}) async {
    if (!msCovers || _fetchingCovers || apps.isEmpty) return;
    _fetchingCovers = true;
    try {
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/mscovers');
      final now = DateTime.now().millisecondsSinceEpoch;
      var tries = 0;
      for (final a in List.of(shown)) {
        if (!msCovers) break;
        if (gameMap.containsKey(a.package)) continue;
        final have = msMap[a.package];
        if (have != null && File(have).existsSync()) continue;
        final miss = msMiss[a.package];
        if (!force && miss != null && now - miss < 7 * 86400000) continue;
        if (++tries > 80) break; // o resto fica para a próxima rodada
        final safe = a.package.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
        try {
          final path = await MsCovers.download(a.name, File('${dir.path}/$safe.jpg'));
          if (path != null) {
            msMap[a.package] = path;
            msMiss.remove(a.package);
            _saveMap('msMap', msMap);
          } else {
            msMiss[a.package] = now;
          }
          _saveMap('msMiss', msMiss);
          notifyListeners();
        } on CoverNetError {
          break; // sem internet: tenta de novo depois, sem marcar como "sem capa"
        }
      }
    } catch (_) {
    } finally {
      _fetchingCovers = false;
    }
  }

  // ---------- banners da Loja no destaque ----------
  /// Card azul da Início: todos os jogos da Loja em ordem aleatória (sorteada ao abrir o app), sem priorizar nenhum.
  late final List<int> _featOrder = [for (var i = 0; i < storeTitles.length; i++) i]..shuffle();
  List<int> get featItems => _featOrder;

  int get featStore {
    final l = featItems;
    return l.isEmpty ? -1 : l[featIdx.clamp(0, l.length - 1).toInt()];
  }

  ImageProvider? featBanner(int storeIndex) => customImage(bannerMap[storeTitles[storeIndex]]);

  /// Banner do jogo para a tela de carregamento: o baixado no aparelho ou, se ainda não baixou, direto do link. Nunca a capa.
  ImageProvider? bannerFor(String title) {
    final local = customImage(bannerMap[title]);
    if (local != null) return local;
    final link = featBannerUrls[title];
    return link == null ? null : NetworkImage(link);
  }

  void featMove(int d) {
    final n = featItems.length;
    if (n == 0) return;
    featIdx = (featIdx + d + n) % n;
    notifyListeners();
  }

  void featSet(int i) {
    featIdx = i;
    notifyListeners();
  }

  void featPlay() {
    final i = featStore;
    if (i < 0) return;
    sfx('ok');
    playStore(i);
  }

  /// Busca na web (catálogo da Microsoft) o banner de cada jogo em destaque e guarda no aparelho.
  Future<void> fetchBanners({bool force = false}) async {
    if (_fetchingBanners) return;
    _fetchingBanners = true;
    bannerInfo = 'Buscando banners…';
    notifyListeners();
    var fails = 0;
    var missed = 0;
    var lastWhy = '';
    try {
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/msbanners');
      final now = DateTime.now().millisecondsSinceEpoch;
      for (final i in featItems) {
        final title = storeTitles[i];
        final have = bannerMap[title];
        if (have != null && File(have).existsSync()) continue;
        final miss = bannerMiss[title];
        if (!force && miss != null && now - miss < 600000) {
          missed++;
          continue;
        }
        final safe = title.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
        try {
          final dest = File('${dir.path}/$safe.jpg');
          BannerSearch.lastErr = '';
          BannerSearch.lastShape = '';
          // só o link do arquivo de banners (featBannerUrls)
          String? path;
          final link = featBannerUrls[title];
          if (link != null) path = await BannerSearch.fromUrl(link, dest);
          if (path != null) {
            bannerMap[title] = path;
            bannerMiss.remove(title);
            _saveMap('bannerMap', bannerMap);
          } else {
            bannerMiss[title] = now;
            missed++;
            final why = BannerSearch.lastErr.isNotEmpty
                ? BannerSearch.lastErr
                : (BannerSearch.lastShape.isNotEmpty ? 'imagem ${BannerSearch.lastShape}' : '');
            if (why.isNotEmpty) lastWhy = '$title: $why';
          }
          _saveMap('bannerMiss', bannerMiss);
          notifyListeners();
        } on CoverNetError catch (e) {
          bannerInfo = 'Sem acesso aos banners (${e.why})';
          if (++fails >= 2) break;
        }
      }
      if (fails == 0) bannerInfo = missed > 0 ? 'Não achei banner de $missed jogo(s)${lastWhy.isNotEmpty ? ' ($lastWhy)' : ''}' : '';
    } catch (e) {
      bannerInfo = 'Erro: ${e.runtimeType}';
    } finally {
      _fetchingBanners = false;
      notifyListeners();
    }
  }

  /// Capas da Loja: baixa o link de cada jogo (storeCoverUrls); não há busca automática.
  Future<void> fetchStoreCovers({bool force = false}) async {
    if (_fetchingStoreCovs) return;
    _fetchingStoreCovs = true;
    covInfo = 'Buscando capas…';
    notifyListeners();
    var fails = 0;
    var missed = 0;
    String? err;
    var lastWhy = '';
    try {
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/xbox_covers');
      final now = DateTime.now().millisecondsSinceEpoch;
      for (final title in List.of(storeTitles)) {
        if (storeMap.containsKey(title)) continue; // capa escolhida por você tem prioridade
        final have = storeCovMap[title];
        if (have != null && File(have).existsSync()) continue;
        final miss = storeCovMiss[title];
        if (!force && miss != null && now - miss < 6 * 3600000) {
          missed++;
          continue;
        }
        final safe = title.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
        try {
          XboxStoreCovers.lastReason = '';
          final dest = File('${dir.path}/$safe.jpg');
          // só o link do arquivo de capas (storeCoverUrls)
          String? path;
          final link = storeCoverUrls[title];
          if (link != null) path = await CatalogCovers.download(link, dest);
          if (path != null) {
            storeCovMap[title] = path;
            storeCovMiss.remove(title);
            _saveMap('storeCovMap', storeCovMap);
          } else {
            storeCovMiss[title] = now;
            missed++;
            if (XboxStoreCovers.lastReason.isNotEmpty) lastWhy = '$title: ${XboxStoreCovers.lastReason}';
          }
          _saveMap('storeCovMiss', storeCovMiss);
          fails = 0;
          err = null;
          final got = storeTitles.where((x) => customImage(storeCovMap[x]) != null || storeMap.containsKey(x)).length;
          covInfo = 'Buscando capas… $got de ${storeTitles.length}';
          notifyListeners();
        } on CoverNetError catch (e) {
          err = 'sem conexão (${e.why})';
          if (++fails >= 3) break;
        }
      }
      final got = storeTitles.where((x) => customImage(storeCovMap[x]) != null || storeMap.containsKey(x)).length;
      final why = lastWhy;
      covInfo = err != null
          ? 'Capas: $err · toque para tentar de novo'
          : 'Capas: $got de ${storeTitles.length}${missed > 0 ? ' · $missed sem capa${why.isNotEmpty ? ' ($why)' : ''} · toque para tentar de novo' : ''}';
    } catch (e) {
      covInfo = 'Capas: erro ${e.runtimeType} · toque para tentar de novo';
    } finally {
      _fetchingStoreCovs = false;
      notifyListeners();
    }
  }

  Future<void> _tick() async {
    final h = DateTime.now().hour;
    final n = h >= 18 || h < 6;
    final b = await Native.battery();
    final x = await Native.status();
    final pad = await Native.padInfo();
    var changed = n != night;
    if (pad != null &&
        (pad.connected != padConnected || pad.battery != padBattery || pad.name != padName)) {
      padConnected = pad.connected;
      padBattery = pad.battery;
      padName = pad.name;
      changed = true;
    }
    if (!idle &&
        gameUrl == null &&
        layer == Layer.none &&
        DateTime.now().difference(lastInput).inMinutes >= 3) {
      idle = true;
      changed = true;
    }
    night = n;
    if (b != null && (b.percent != battery || b.charging != charging)) {
      battery = b.percent;
      charging = b.charging;
      changed = true;
    }
    if (x != null &&
        (x.wifiEnabled != wifiEnabled ||
            x.wifiConnected != wifiConnected ||
            x.btOn != btOn ||
            x.volume != volumePct ||
            x.muted != muted)) {
      wifiEnabled = x.wifiEnabled;
      wifiConnected = x.wifiConnected;
      btOn = x.btOn;
      volumePct = x.volume;
      muted = x.muted;
      changed = true;
    }
    if (changed) notifyListeners();
  }

  void openNetLayer(Layer l) {
    layer = l;
    netIdx = 0;
    netMsg = '';
    notifyListeners();
    scanNet();
  }

  int get netCount => layer == Layer.wifi ? wifiNets.length : btDevs.length;

  String _netError(String state, bool wifi) => switch (state) {
        'off' => wifi ? 'O Wi-Fi está desligado. Ligue-o nos ajustes do Android.' : 'O Bluetooth está desligado. Ligue-o nos ajustes do Android.',
        'nolocation' => 'Ative a Localização do aparelho para o Android listar as redes.',
        'noperm' => 'Permissão negada. Conceda nas permissões do app (Informações do app).',
        _ => 'Não foi possível buscar agora.',
      };

  Future<void> scanNet() async {
    if (scanning) return;
    final wifi = layer == Layer.wifi;
    scanning = true;
    netMsg = wifi ? 'Procurando redes…' : 'Procurando dispositivos…';
    notifyListeners();
    if (!await Native.perm(wifi ? 'wifi' : 'bt')) {
      scanning = false;
      netMsg = _netError('noperm', wifi);
      notifyListeners();
      return;
    }
    if (wifi) {
      final r = await Native.wifiScan();
      wifiNets = r.items;
      netMsg = r.state == 'ok' ? (r.items.isEmpty ? 'Nenhuma rede encontrada.' : '') : _netError(r.state, true);
    } else {
      final b = await Native.btBonded(); // pareados aparecem na hora
      if (b.state == 'ok') {
        btDevs = b.items;
        notifyListeners();
      }
      final r = await Native.btDiscover();
      if (r.state == 'ok') btDevs = r.items;
      netMsg = r.state == 'ok' ? (r.items.isEmpty ? 'Nenhum dispositivo encontrado.' : '') : _netError(r.state, false);
    }
    scanning = false;
    netIdx = _clampIdx(netIdx, netCount);
    notifyListeners();
  }

  Future<void> pairBt(BtDev d) async {
    netMsg = 'Pareando com ${d.label}… confirme no aviso do Android';
    notifyListeners();
    await Native.btPair(d.address);
    await Future.delayed(const Duration(seconds: 6));
    if (layer == Layer.bt) {
      scanning = false;
      scanNet();
    }
  }

  void netAccept2() => Native.openSettings(layer == Layer.wifi ? 'wifi' : 'bluetooth');

  void netAccept() {
    if (layer == Layer.wifi) {
      Native.openSettings('wifi');
    } else if (btDevs.isNotEmpty) {
      final d = btDevs[netIdx];
      if (d.paired) {
        Native.openSettings('bluetooth');
      } else {
        pairBt(d);
      }
    }
  }

  Future<void> adjustVolume(int dir) async {
    final v = ((volumePct < 0 ? 0 : volumePct) + dir * 5).clamp(0, 100).toInt();
    volumePct = v;
    notifyListeners();
    await Native.setVolume(v);
    await _tick();
  }

  Future<void> toggleMute() async {
    await Native.toggleMute();
    await _tick();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s != AppLifecycleState.resumed || !ready) return;
    lastInput = DateTime.now();
    _tick(); // atualiza Wi-Fi/Bluetooth/volume ao voltar das configurações
    final pkg = _launchPkg, at = _launchAt;
    if (pkg != null && at != null) {
      final secs = DateTime.now().difference(at).inSeconds;
      _launchPkg = null;
      _launchAt = null;
      _addPlaySecs(pkg, secs);
    }
    if (DateTime.now().difference(_appsAt).inSeconds > 60) refreshApps();
    _tick();
    notifyListeners();
  }

  // ---------- listas ----------
  void _rebuild() {
    shown = onlySelected ? apps.where((a) => selected.contains(a.package)).toList() : List.of(apps);
    final l = <HomeItem>[];
    for (final t in pinned) {
      final i = storeTitles.indexOf(t);
      if (i >= 0) l.add(HomeItem.store(i));
    }
    pinnedCount = l.length;
    l.addAll(shown.map(HomeItem.app));
    homeItems = l;
    final played = l.where((it) => lastPlayed.containsKey(playKey(it))).toList()
      ..sort((x, y) => lastPlayed[playKey(y)]!.compareTo(lastPlayed[playKey(x)]!));
    final rec = <HomeItem>[...played];
    for (final it in l) {
      if (!lastPlayed.containsKey(playKey(it))) rec.add(it);
    }
    recentItems = rec;
    homeIdx = _clampIdx(homeIdx, recentItems.length);
    _rebuildLib();
    pickIdx = _clampIdx(pickIdx, apps.length);
    editIdx = _clampIdx(editIdx, layer == Layer.editStore ? storeTitles.length : apps.length);
  }

  // ---------- favoritos e coleções da Biblioteca ----------
  String favKey(HomeItem it) => it.isStore ? 's:${it.title}' : 'a:${it.app!.package}';
  bool isFav(HomeItem it) => favs.contains(favKey(it));

  void _rebuildLib() {
    final all = homeItems;
    List<HomeItem> l;
    switch (libFilter) {
      case 1:
        final extra = <HomeItem>[
          for (var i = 0; i < storeTitles.length; i++)
            if (!pinned.contains(storeTitles[i])) HomeItem.store(i)
        ];
        l = [...all, ...extra].where(isFav).toList();
      case 2:
        l = [for (var i = 0; i < storeTitles.length; i++) HomeItem.store(i)];
      case 3:
        l = all.where((e) => !e.isStore).toList();
      default:
        l = [...all.where(isFav), ...all.where((e) => !isFav(e))];
    }
    libItems = l;
    libIdx = _clampIdx(libIdx, l.length);
  }

  void setFilter(int dir) {
    libFilter = (libFilter + dir + libFilters.length) % libFilters.length;
    libIdx = 0;
    _rebuildLib();
    sfx('tab');
    notifyListeners();
  }

  void toggleFav(HomeItem it) {
    final k = favKey(it);
    if (!favs.remove(k)) favs.add(k);
    _p.setStringList('favs', favs.toList());
    _rebuildLib();
    sfx('toggle');
    notifyListeners();
  }

  /// Item sob o foco na Início ou na Biblioteca (null nas outras abas).
  HomeItem? get focusedItem {
    if (tab == 0) return homeIdx < recentItems.length ? recentItems[homeIdx] : null;
    if (tab == 1) return libIdx < libItems.length ? libItems[libIdx] : null;
    return null;
  }

  void favoriteCurrent() {
    final it = focusedItem;
    if (it != null) toggleFav(it);
  }

  // ---------- cor da capa (fundo e brilho do card seguem a arte do jogo) ----------
  Color? tintFor(HomeItem? it) {
    if (it == null) return null;
    final k = favKey(it);
    final c = _tints[k];
    if (c != null) return c;
    if (_tinting.add(k)) _computeTint(it, k);
    return null;
  }

  Future<void> _computeTint(HomeItem it, String k) async {
    try {
      final img = itemImage(it);
      if (img == null) return;
      final done = Completer<ui.Image>();
      final stream = ResizeImage(img, width: 16, height: 16).resolve(ImageConfiguration.empty);
      late ImageStreamListener l;
      l = ImageStreamListener((info, _) {
        if (!done.isCompleted) done.complete(info.image);
        stream.removeListener(l);
      }, onError: (Object e, StackTrace? _) {
        if (!done.isCompleted) done.completeError(e);
        stream.removeListener(l);
      });
      stream.addListener(l);
      final image = await done.future.timeout(const Duration(seconds: 8));
      final bd = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      if (bd == null) return;
      double r = 0, g = 0, b = 0, w = 0;
      for (var i = 0; i + 3 < bd.lengthInBytes; i += 4) {
        final pr = bd.getUint8(i), pg = bd.getUint8(i + 1), pb = bd.getUint8(i + 2), pa = bd.getUint8(i + 3);
        if (pa < 128) continue;
        final mx = math.max(pr, math.max(pg, pb)), mn = math.min(pr, math.min(pg, pb));
        final wt = 0.05 + (mx - mn) / 255.0; // dá mais peso às cores vivas
        r += pr * wt;
        g += pg * wt;
        b += pb * wt;
        w += wt;
      }
      if (w <= 0) return;
      _tints[k] = Color.fromARGB(255, (r / w).round().clamp(0, 255), (g / w).round().clamp(0, 255), (b / w).round().clamp(0, 255));
      notifyListeners();
    } catch (_) {}
  }

  // ---------- menu rápido (painel do launcher e menu dentro do jogo) ----------
  int get quickIdx => gameUrl != null ? menuIdx : panelIdx;
  set quickIdx(int v) {
    if (gameUrl != null) {
      menuIdx = v;
    } else {
      panelIdx = v;
    }
  }

  List<QRow> get quickRows {
    final vol = QRow(tr('Volume'), 'volume', 'vol',
        () => muted ? tr('Mudo') : (volumePct < 0 ? '--' : '$volumePct%'), toggleMute, adjustVolume,
        frac: () => muted || volumePct < 0 ? 0 : volumePct / 100);
    final bri = QRow(tr('Brilho'), 'brightness', 'bri', () => brightness < 0 ? '--' : '$brightness%',
        () {}, adjustBrightness,
        frac: () => brightness < 0 ? 0.5 : brightness / 100);
    if (gameUrl != null) {
      return [
        QRow(tr('Continuar jogando'), 'play', 'btn', () => '', closeQuick, (_) {}),
        vol,
        bri,
        QRow(tr('Layout Nintendo (A↔B, X↔Y)'), 'gamepad', 'btn',
            () => nintendo ? tr('Ligado') : tr('Desligado'), () => toggle('nintendo'), (_) => toggle('nintendo')),
        QRow(tr('Ajuste da tela'), 'brightness', 'btn',
            () => tr(const ['Padrão', 'Preencher', 'Esticar'][gameFit]),
            () => setGameFit((gameFit + 1) % 3),
            (d) => setGameFit((gameFit + d + 3) % 3)),
        QRow(tr('Recarregar página'), 'refresh', 'btn', () => '', () {
          reloadTick++;
          closeQuick();
        }, (_) {}),
        QRow(tr('Voltar ao Ryzen'), 'home', 'btn', () => '', () {
          closeQuick();
          closeGame();
        }, (_) {}),
      ];
    }
    return [
      vol,
      bri,
      QRow(tr('Tema'), 'brightness', 'btn', () => dark ? tr('Escuro') : tr('Claro'),
          () => setMode(dark ? 0 : 1), (_) => setMode(dark ? 0 : 1)),
      QRow('Wi-Fi', 'wifi', 'btn',
          () => !wifiEnabled ? tr('Desligado') : (wifiConnected ? tr('Conectado') : tr('Sem conexão')), () {
        closeQuick();
        openNetLayer(Layer.wifi);
      }, (_) {}),
      QRow('Bluetooth', 'bluetooth', 'btn', () => btOn ? tr('Ligado') : tr('Desligado'), () {
        closeQuick();
        openNetLayer(Layer.bt);
      }, (_) {}),
      QRow(tr('Buscar'), 'search', 'btn', () => '', () {
        closeQuick();
        openSearch();
      }, (_) {}),
      QRow(tr('Configurações'), 'settings', 'btn', () => '', () {
        closeQuick();
        setTab(3);
      }, (_) {}),
      QRow(tr('Fechar'), 'close', 'btn', () => '', closeQuick, (_) {}),
    ];
  }

  Future<void> openQuick() async {
    if (!ready) return;
    if (gameUrl != null) {
      gameMenu = true;
      menuIdx = 0;
      Native.setMenuMode(true);
    } else {
      layer = Layer.panel;
      panelIdx = 0;
    }
    sfx('ok');
    notifyListeners();
    if (brightness < 0) {
      brightness = await Native.getBrightness();
      notifyListeners();
    }
  }

  void closeQuick() {
    if (gameUrl != null) {
      gameMenu = false;
      Native.setMenuMode(false);
    } else if (layer == Layer.panel) {
      layer = Layer.none;
    }
    sfx('back');
    notifyListeners();
  }

  void tapQuick(int i) {
    final rows = quickRows;
    if (i < 0 || i >= rows.length) return;
    quickIdx = i;
    sfx('ok');
    rows[i].onAccept();
    notifyListeners();
  }

  void adjustBrightness(int dir) {
    final b = ((brightness < 0 ? 50 : brightness) + dir * 10).clamp(5, 100).toInt();
    brightness = b;
    _p.setInt('brightness', b);
    Native.setBrightness(b);
    notifyListeners();
  }

  void _quickAct(Act a) {
    final rows = quickRows;
    final i = quickIdx.clamp(0, rows.length - 1).toInt();
    switch (a) {
      case Act.up:
        if (i > 0) {
          quickIdx = i - 1;
          sfx('move');
          notifyListeners();
        }
      case Act.down:
        if (i < rows.length - 1) {
          quickIdx = i + 1;
          sfx('move');
          notifyListeners();
        }
      case Act.left:
        rows[i].onSide(-1);
      case Act.right:
        rows[i].onSide(1);
      case Act.accept:
        sfx('ok');
        rows[i].onAccept();
      case Act.cancel:
      case Act.menu:
        closeQuick();
      default:
        break;
    }
  }

  // ---------- busca com teclado na tela ----------
  List<HomeItem> get searchResults {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return recentItems.take(12).toList();
    final out = <HomeItem>[];
    for (final a in apps) {
      if (a.name.toLowerCase().contains(q)) out.add(HomeItem.app(a));
      if (out.length >= 24) break;
    }
    for (var i = 0; i < storeTitles.length && out.length < 30; i++) {
      if (storeTitles[i].toLowerCase().contains(q)) out.add(HomeItem.store(i));
    }
    return out;
  }

  void openSearch() {
    layer = Layer.search;
    query = '';
    kbIdx = 0;
    resIdx = 0;
    inResults = false;
    sfx('ok');
    notifyListeners();
  }

  void kbTap(int i) {
    kbIdx = i;
    inResults = false;
    final k = kbKeys[i];
    if (k == '⌫') {
      if (query.isNotEmpty) query = query.substring(0, query.length - 1);
    } else if (k == '✕') {
      query = '';
    } else if (k == '␣') {
      if (query.isNotEmpty && !query.endsWith(' ')) query += ' ';
    } else {
      query += k;
    }
    resIdx = 0;
    sfx('move');
    notifyListeners();
  }

  void openResult(int i) {
    final r = searchResults;
    if (i < 0 || i >= r.length) return;
    final it = r[i];
    layer = Layer.none;
    sfx('ok');
    notifyListeners();
    if (it.isStore) {
      playStore(it.storeIndex);
    } else {
      launch(it.app!);
    }
  }

  void _searchAct(Act a) {
    if (a == Act.cancel) {
      closeLayer();
      return;
    }
    if (a == Act.details) {
      if (query.isNotEmpty) {
        query = query.substring(0, query.length - 1);
        resIdx = 0;
        sfx('move');
        notifyListeners();
      }
      return;
    }
    final res = searchResults;
    if (inResults) {
      if (a == Act.left && resIdx > 0) {
        resIdx--;
        sfx('move');
      } else if (a == Act.right && resIdx < res.length - 1) {
        resIdx++;
        sfx('move');
      } else if (a == Act.up) {
        inResults = false;
        sfx('move');
      } else if (a == Act.accept) {
        openResult(resIdx);
        return;
      }
      notifyListeners();
      return;
    }
    switch (a) {
      case Act.left:
        if (kbIdx % kbCols > 0) kbIdx--;
      case Act.right:
        if (kbIdx % kbCols < kbCols - 1) kbIdx++;
      case Act.up:
        if (kbIdx >= kbCols) kbIdx -= kbCols;
      case Act.down:
        if (kbIdx + kbCols < kbKeys.length) {
          kbIdx += kbCols;
        } else if (res.isNotEmpty) {
          inResults = true;
          resIdx = resIdx.clamp(0, res.length - 1).toInt();
        }
      case Act.accept:
        kbTap(kbIdx);
        return;
      default:
        return;
    }
    sfx('move');
    notifyListeners();
  }

  // ---------- descanso ----------
  /// Qualquer entrada acorda a tela de descanso. true = estava descansando (a entrada é descartada).
  bool wake() {
    lastInput = DateTime.now();
    if (idle) {
      idle = false;
      notifyListeners();
      return true;
    }
    return false;
  }

  int _clampIdx(int i, int n) => n == 0 ? 0 : i.clamp(0, n - 1).toInt();

  /// Chave do tempo/última vez: pacote para apps, "s:título" para jogos da Loja.
  static String storeKey(String title) => 's:$title';
  String playKey(HomeItem it) => it.isStore ? storeKey(it.title) : it.app!.package;

  void _addPlaySecs(String key, int secs) {
    if (secs < 20) return;
    playSecs[key] = (playSecs[key] ?? 0) + secs.clamp(0, 43200).toInt();
    _saveMap('playSecs', playSecs);
  }

  /// Último jogo jogado, seja da Biblioteca ou da Loja.
  HomeItem? get lastItem {
    HomeItem? best;
    var bestT = -1;
    for (final a in shown) {
      final t = lastPlayed[a.package] ?? -1;
      if (t > bestT) {
        bestT = t;
        best = HomeItem.app(a);
      }
    }
    for (var i = 0; i < storeTitles.length; i++) {
      final t = lastPlayed[storeKey(storeTitles[i])] ?? -1;
      if (t > bestT) {
        bestT = t;
        best = HomeItem.store(i);
      }
    }
    return best ?? (shown.isEmpty ? null : HomeItem.app(shown.first));
  }

  /// Tempo jogado, ex.: "1 h 25 min", "45 min".
  String hours(HomeItem? it) {
    final secs = it == null ? 0 : (playSecs[playKey(it)] ?? 0);
    final m = secs ~/ 60;
    if (m < 60) return '$m min';
    final h = m ~/ 60, r = m % 60;
    return r == 0 ? '$h h' : '$h h $r min';
  }

  /// Reabre (continua) o último jogo, da Loja ou da Biblioteca.
  void continueItem(HomeItem it) {
    if (it.isStore) {
      playStore(it.storeIndex);
    } else {
      launch(it.app!);
    }
  }

  // ---------- imagens ----------
  ImageProvider? customImage(String? path) {
    if (path == null) return null;
    final f = File(path);
    return f.existsSync() ? FileImage(f) : null;
  }

  ImageProvider? appImage(AppInfo a) {
    final c = customImage(gameMap[a.package]);
    if (c != null) return c;
    if (msCovers) {
      final m = customImage(msMap[a.package]);
      if (m != null) return m;
    }
    return a.icon == null ? null : MemoryImage(a.icon!);
  }

  /// Capa da Microsoft em uso (retrato) → preenche o card; ícone/imagem própria segue "capa inteira".
  BoxFit fitForApp(AppInfo a) {
    if (msCovers && !gameMap.containsKey(a.package) && customImage(msMap[a.package]) != null) {
      return BoxFit.cover;
    }
    return fitImages ? BoxFit.contain : BoxFit.cover;
  }

  /// Capa da Loja: a que você escolheu na galeria, ou a baixada do Xbox (senão, só o nome).
  ImageProvider? storeImage(int i) =>
      customImage(storeMap[storeTitles[i]]) ?? customImage(storeCovMap[storeTitles[i]]);

  ImageProvider? itemImage(HomeItem it) =>
      it.isStore ? storeImage(it.storeIndex) : appImage(it.app!);

  // ---------- papel de parede ----------
  List<WallOpt> get wallOptions => [
        const WallOpt('default', 'Padrão'),
        const WallOpt('game', 'Arte do jogo selecionado'),
        for (final e in _builtinWalls.entries)
          WallOpt('asset:assets/wallpapers/${e.key}.jpg', e.value),
        for (final c in customWalls) WallOpt(c, 'Meu: ${_fileName(c)}'),
        if (videoWall != null && File(videoWall!).existsSync()) const WallOpt('video', 'Vídeo'),
      ];

  /// Caminho do vídeo de fundo quando ele é o papel de parede escolhido.
  String? get videoWallPath =>
      wallKey == 'video' && videoWall != null && File(videoWall!).existsSync() ? videoWall : null;

  Future<void> pickVideoWall() async {
    try {
      final x = await ImagePicker().pickVideo(source: ImageSource.gallery);
      if (x == null) return;
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/vids')..createSync(recursive: true);
      for (final f in dir.listSync()) {
        try {
          f.deleteSync();
        } catch (_) {}
      }
      final ext = x.name.contains('.') ? x.name.substring(x.name.lastIndexOf('.')) : '.mp4';
      final dest = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}$ext';
      await File(x.path).copy(dest);
      videoWall = dest;
      _p.setString('videoWall', dest);
      wallKey = 'video';
      _p.setString('wallKey', wallKey);
      notifyListeners();
    } catch (_) {}
  }

  void removeVideoWall() {
    final v = videoWall;
    if (v == null) return;
    try {
      File(v).deleteSync();
    } catch (_) {}
    videoWall = null;
    _p.remove('videoWall');
    if (wallKey == 'video') {
      wallKey = 'default';
      _p.setString('wallKey', wallKey);
    }
    notifyListeners();
  }

  String _fileName(String p) => p.substring(p.lastIndexOf('/') + 1);

  int get wallIndex {
    final i = wallOptions.indexWhere((o) => o.key == wallKey);
    return i < 0 ? 0 : i;
  }

  String get wallName => wallOptions[wallIndex].name;
  bool get wallIsCustom => customWalls.contains(wallKey);

  ImageProvider? get wallProvider {
    if (wallKey == 'default') return null;
    if (wallKey == 'game') {
      if (tab > 1) return null;
      final list = tab == 1 ? libItems : recentItems;
      final i = tab == 1 ? libIdx : homeIdx;
      return i < list.length ? itemImage(list[i]) : null;
    }
    if (wallKey.startsWith('asset:')) return AssetImage(wallKey.substring(6));
    return customImage(wallKey);
  }

  void changeWall(int dir) {
    final o = wallOptions;
    wallKey = o[(wallIndex + dir + o.length) % o.length].key;
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  Future<String?> pickImage() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (x == null) return null;
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/imgs')..createSync(recursive: true);
      final safe = x.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
      final dest = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$safe';
      await File(x.path).copy(dest);
      return dest;
    } catch (_) {
      return null;
    }
  }

  Future<void> pickWall() async {
    final path = await pickImage();
    if (path == null) return;
    if (!customWalls.contains(path)) customWalls.add(path);
    _p.setStringList('customWalls', customWalls);
    wallKey = path;
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  void removeCurrentWall() {
    if (!wallIsCustom) return;
    customWalls.remove(wallKey);
    try {
      File(wallKey).deleteSync();
    } catch (_) {}
    _p.setStringList('customWalls', customWalls);
    wallKey = 'default';
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  // ---------- ícones / capas personalizados ----------
  bool isMapped(bool store, String key) => (store ? storeMap : gameMap).containsKey(key);

  Future<void> pickFor(bool store, String key) async {
    final path = await pickImage();
    if (path == null) return;
    final m = store ? storeMap : gameMap;
    m[key] = path;
    _saveMap(store ? 'storeMap' : 'gameMap', m);
    notifyListeners();
  }

  void clearMapped(bool store, String key) {
    final m = store ? storeMap : gameMap;
    if (m.remove(key) == null) return;
    _saveMap(store ? 'storeMap' : 'gameMap', m);
    sfx('back');
    notifyListeners();
  }

  // ---------- jogos ----------
  void toggleApp(String pkg) {
    if (!selected.remove(pkg)) selected.add(pkg);
    _p.setStringList('myGames', selected.toList());
    _rebuild();
    notifyListeners();
  }

  void selectAll() {
    selected = apps.map((a) => a.package).toSet();
    _p.setStringList('myGames', selected.toList());
    _rebuild();
    notifyListeners();
  }

  void selectNone() {
    selected = {};
    _p.setStringList('myGames', []);
    _rebuild();
    notifyListeners();
  }

  /// Abre o jogo da Loja: link próprio do jogo, ou o serviço de nuvem escolhido.
  Future<void> playStore(int i) async {
    final key = storeKey(storeTitles[i]);
    lastPlayed[key] = DateTime.now().millisecondsSinceEpoch;
    _saveMap('lastPlayed', lastPlayed);
    _rebuild();
    homeIdx = 0;
    notifyListeners();
    var link = storeLink(storeTitles[i]);
    final title = storeTitles[i], cover = storeImage(i), banner = bannerFor(title);
    if (link.isEmpty) {
      // sem link salvo: acha o jogo no catálogo do Xbox (ID do produto) e guarda para as próximas vezes
      try {
        final found = await XboxStoreCovers.playLink(title);
        if (found != null) {
          autoLinks[title] = found;
          _saveMap('autoLinks', autoLinks);
          link = found;
        }
      } catch (_) {}
    }
    if (link.isNotEmpty) {
      openLink(link, key: key, title: title, cover: cover, banner: banner);
      return;
    }
    final svc = cloudServices[cloudService];
    if (svc.pkg != null) {
      _launchPkg = key;
      _launchAt = DateTime.now();
      if (!await Native.launch(svc.pkg!)) {
        _launchPkg = null;
        _launchAt = null;
        await Native.openStore(svc.pkg!);
      }
    } else if (svc.url != null) {
      openLink(svc.url!, key: key, title: title, cover: cover, banner: banner);
    }
  }

  /// Link de streaming embutido no app (não editável); sem link, procura no catálogo do Xbox.
  String storeLink(String title) =>
      (defaultStoreLinks[title] ?? autoLinks[title] ?? '').trim();

  void setStoreLink(String title, String link) {
    final l = link.trim();
    if (l.isEmpty) {
      storeLinks.remove(title);
    } else {
      storeLinks[title] = l;
    }
    _saveMap('storeLinks', storeLinks);
    notifyListeners();
  }

  void togglePin(String title) {
    if (!pinned.remove(title)) pinned.add(title);
    _p.setStringList('pinnedStore', pinned);
    _rebuild();
    notifyListeners();
  }

  void launch(AppInfo a) {
    _launchPkg = a.package;
    _launchAt = DateTime.now();
    lastPlayed[a.package] = DateTime.now().millisecondsSinceEpoch;
    _saveMap('lastPlayed', lastPlayed);
    _rebuild();
    homeIdx = 0;
    Native.launch(a.package);
  }

  void activate(int i, {bool recent = false}) {
    final list = recent ? recentItems : libItems;
    if (i < 0 || i >= list.length) return;
    final it = list[i];
    if (it.isStore) {
      // Jogo fixado da Loja: abre o jogo (link próprio ou nuvem) em vez de ir pra aba Loja.
      playStore(it.storeIndex);
    } else {
      launch(it.app!);
    }
  }

  // ---------- configurações ----------
  /// Ordem visual das abas no dock.
  static const tabOrder = [0, 1, 2, 3];

  /// Fecha o jogo/link em tela cheia e volta ao Ryzen.
  void closeGame() {
    if (gameUrl == null) return;
    final wk = _webKey, wa = _webAt;
    _webKey = null;
    _webAt = null;
    if (wk != null && wa != null) _addPlaySecs(wk, DateTime.now().difference(wa).inSeconds);
    gameUrl = null;
    gameTitle = null;
    gameCover = null;
    gameBanner = null;
    gameMenu = false;
    lastInput = DateTime.now();
    notifyListeners();
  }

  /// Abre um link de jogo em tela cheia (esquemas de app, como market://, vão pro Android).
  void openLink(String url, {String? key, String? title, ImageProvider? cover, ImageProvider? banner}) {
    final u = url.trim();
    if (u.isEmpty) return;
    final uri = Uri.tryParse(u);
    if (uri != null && uri.hasScheme && uri.scheme != 'http' && uri.scheme != 'https') {
      if (key != null) {
        _launchPkg = key;
        _launchAt = DateTime.now();
      }
      Native.openUrl(u);
      return;
    }
    _webKey = key;
    _webAt = key == null ? null : DateTime.now();
    gameTitle = title;
    gameCover = cover;
    gameBanner = banner;
    gameUrl = u;
    gameMenu = false;
    lastInput = DateTime.now();
    notifyListeners();
  }

  void openPadTest() {
    _webKey = null;
    _webAt = null;
    gameUrl = padTestUrl;
    gameMenu = false;
    lastInput = DateTime.now();
    notifyListeners();
  }

  void setTab(int t) {
    if (t == tab) return;
    tab = t;
    sfx('tab');
    notifyListeners();
  }

  int choiceValue(String key) => switch (key) {
        'theme' => themeMode,
        'lang' => lang == 'en' ? 1 : 0,
        'gfit' => gameFit,
        'sq' => streamQ,
        'lowlat' => jbLevel,
        'sharp' => sharpLevel,
        'dz' => padDz,
        _ => glassLevel,
      };

  bool toggleValue(String key) => switch (key) {
        'clock' => showClock,
        'battery' => showBattery,
        'bt' => showBt,
        'only' => onlySelected,
        'ms' => msCovers,
        'sound' => soundOn,
        'nintendo' => nintendo,
        'h264' => h264,
        'stats' => showStats,
        _ => fitImages,
      };

  void setMode(int v) {
    themeMode = v;
    _p.setInt('themeMode', v);
    notifyListeners();
  }

  void setLang(int v) {
    lang = v == 1 ? 'en' : 'pt';
    _p.setString('lang', lang);
    notifyListeners();
  }

  void setStreamQ(int v) {
    streamQ = v.clamp(0, 2).toInt();
    _p.setInt('streamQ', streamQ);
    notifyListeners();
  }

  void setJb(int v) {
    jbLevel = v.clamp(0, 2).toInt();
    _p.setInt('jbLevel', jbLevel);
    notifyListeners();
  }

  void setMsLogged() {
    msLogged = true;
    _p.setBool('msLogged', true);
    notifyListeners();
  }

  void setPadDz(int v) {
    padDz = v.clamp(0, 4).toInt();
    _p.setInt('padDz', padDz);
    notifyListeners();
  }

  void setSharp(int v) {
    sharpLevel = v.clamp(0, 2).toInt();
    _p.setInt('sharpLevel', sharpLevel);
    notifyListeners();
  }

  void setChoice(String? key, int v) {
    if (key == 'theme') {
      setMode(v);
    } else if (key == 'lang') {
      setLang(v);
    } else if (key == 'gfit') {
      setGameFit(v);
    } else if (key == 'sq') {
      setStreamQ(v);
    } else if (key == 'lowlat') {
      setJb(v);
    } else if (key == 'sharp') {
      setSharp(v);
    } else if (key == 'dz') {
      setPadDz(v);
    } else {
      setGlass(v);
    }
  }

  void setGameFit(int v) {
    gameFit = v.clamp(0, 2).toInt();
    _p.setInt('gameFit', gameFit);
    notifyListeners();
  }

  void setGlass(int v) {
    glassLevel = v;
    _p.setInt('glassLevel', v);
    notifyListeners();
  }

  void toggle(String key) {
    switch (key) {
      case 'clock':
        showClock = !showClock;
        _p.setBool('showClock', showClock);
      case 'battery':
        showBattery = !showBattery;
        _p.setBool('showBattery', showBattery);
      case 'bt':
        showBt = !showBt;
        _p.setBool('showBt', showBt);
      case 'sound':
        soundOn = !soundOn;
        _p.setBool('soundOn', soundOn);
        if (soundOn) {
          _sfxReady = true;
          sfx('toggle');
        }
      case 'only':
        onlySelected = !onlySelected;
        _p.setBool('onlySelected', onlySelected);
        _rebuild();
      case 'nintendo':
        nintendo = !nintendo;
        _p.setBool('nintendo', nintendo);
      case 'h264':
        h264 = !h264;
        _p.setBool('h264', h264);
      case 'stats':
        showStats = !showStats;
        _p.setBool('showStats', showStats);
      case 'ms':
        msCovers = !msCovers;
        _p.setBool('msCovers', msCovers);
        if (msCovers) {
          fetchCovers(force: true);
          fetchBanners(force: true);
          fetchStoreCovers(force: true);
        }
      default:
        fitImages = !fitImages;
        _p.setBool('fitImages', fitImages);
    }
    notifyListeners();
  }

  String subText(int i) {
    final r = settingRows[i];
    if (r.kind == 'games') {
      return '${selected.length} de ${apps.length} jogos selecionados · A: escolher';
    }
    if (r.key == 'battery' && !hasBattery) return 'Bateria não detectada neste dispositivo';
    if (r.key == 'wifi') {
      final e = !wifiEnabled ? 'Desligado' : (wifiConnected ? 'Conectado' : 'Ligado, sem conexão');
      return '$e · A: ver redes disponíveis';
    }
    if (r.key == 'bluetooth') {
      return '${btOn ? 'Ligado' : 'Desligado'} · A: ver dispositivos disponíveis';
    }
    if (r.kind == 'pickvideo' && videoWall != null) return tr('Vídeo em uso · A: trocar · Direita: remover');
    return tr(r.sub);
  }

  void changeRow(int i, int dir) {
    final r = settingRows[i];
    switch (r.kind) {
      case 'choice':
        final n = r.options.length;
        final v = (choiceValue(r.key!) + (dir == 0 ? 1 : dir) + n) % n;
        if (r.key == 'theme') {
          setMode(v);
        } else if (r.key == 'lang') {
          setLang(v);
        } else if (r.key == 'gfit') {
          setGameFit(v);
        } else if (r.key == 'sq') {
          setStreamQ(v);
        } else if (r.key == 'lowlat') {
          setJb(v);
        } else if (r.key == 'sharp') {
          setSharp(v);
        } else if (r.key == 'dz') {
          setPadDz(v);
        } else {
          setGlass(v);
        }
      case 'wall':
        changeWall(dir == 0 ? 1 : dir);
      case 'games':
        openGames();
      case 'padtest':
        openPadTest();
      case 'profile':
        openProfile();
      case 'gameicons':
        layer = Layer.editApps;
        editIdx = 0;
        notifyListeners();
      case 'storeicons':
        layer = Layer.editStore;
        editIdx = 0;
        notifyListeners();
      case 'cloud':
        cloudService = (cloudService + (dir == 0 ? 1 : dir) + cloudServices.length) % cloudServices.length;
        _p.setInt('cloudService', cloudService);
        notifyListeners();
      case 'sys':
        openNetLayer(r.key == 'wifi' ? Layer.wifi : Layer.bt);
      case 'volume':
        if (dir == 0) {
          toggleMute();
        } else {
          adjustVolume(dir);
        }
      case 'pickvideo':
        if (dir == 0) {
          pickVideoWall();
        } else if (dir > 0) {
          removeVideoWall();
        }
      case 'pick':
        if (dir == 0) {
          pickWall();
        } else if (dir > 0) {
          removeCurrentWall();
        }
      default:
        toggle(r.key!);
    }
  }

  // ---------- perfil ----------
  String get userName => profName.isNotEmpty ? profName : tr('Jogador');

  ImageProvider? get avatar {
    if (profPhoto.isNotEmpty && File(profPhoto).existsSync()) return FileImage(File(profPhoto));
    return null;
  }

  List<String> get profileIds => [
        'edit',
        'photo',
        'config',
        'privacy',
        'about',
      ];

  /// Diálogos informativos do perfil (Privacidade / Sobre), abertos pela tela.
  int dlgTick = 0;
  String dlgKind = '';

  /// Jogos já abertos pelo Ryzen e tempo total jogado.
  int get playedCount => lastPlayed.length;
  String get totalHours {
    final secs = playSecs.values.fold<int>(0, (a, b) => a + b);
    final h = secs ~/ 3600, m = (secs % 3600) ~/ 60;
    return h == 0 && m > 0 ? '$m min' : '$h h';
  }

  void openProfile() {
    layer = Layer.profile;
    profIdx = 0;
    sfx('ok');
    notifyListeners();
  }

  void closeProfile() {
    closeLayer();
  }

  void profileAccept(int i) {
    final ids = profileIds;
    if (i < 0 || i >= ids.length) return;
    switch (ids[i]) {
      case 'edit':
        nameTick++;
        notifyListeners();
      case 'photo':
        pickAvatar();
      case 'config':
        closeProfile();
        setTab(3);
      case 'privacy':
      case 'about':
        dlgKind = ids[i];
        dlgTick++;
        notifyListeners();
    }
  }

  void _profileAct(Act a) {
    if (cropSrc != null) {
      if (a == Act.cancel) {
        cancelCrop();
      } else if (a == Act.accept) {
        cropTick++;
        notifyListeners();
      }
      return;
    }
    if (a == Act.up || a == Act.down) {
      _nav(a, profileIds.length, 1, profIdx, (v) => profIdx = v);
    } else if (a == Act.cancel) {
      closeProfile();
    } else if (a == Act.accept) {
      sfx('ok');
      profileAccept(profIdx);
    }
  }

  /// Escolhe uma foto na galeria e abre o editor de corte.
  Future<void> pickAvatar() async {
    final path = await pickImage();
    if (path == null) return;
    cropSrc = path;
    notifyListeners();
  }

  void cancelCrop() {
    final p = cropSrc;
    cropSrc = null;
    if (p != null) {
      try {
        File(p).deleteSync();
      } catch (_) {}
    }
    notifyListeners();
  }

  /// Recebe a foto já cortada (PNG quadrado) e grava como foto do perfil.
  Future<void> saveAvatarBytes(Uint8List bytes) async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}/imgs')..createSync(recursive: true);
    final dest = '${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png';
    await File(dest).writeAsBytes(bytes, flush: true);
    final old = profPhoto;
    profPhoto = dest;
    _p.setString('profPhoto', dest);
    if (old.isNotEmpty && old != dest) {
      try {
        File(old).deleteSync();
      } catch (_) {}
    }
    final src = cropSrc;
    cropSrc = null;
    if (src != null) {
      try {
        File(src).deleteSync();
      } catch (_) {}
    }
    sfx('ok');
    notifyListeners();
  }

  void clearAvatar() {
    profPhoto = '';
    _p.remove('profPhoto');
    profIdx = profIdx.clamp(0, profileIds.length - 1).toInt();
    notifyListeners();
  }

  void setUserName(String v) {
    profName = v.trim();
    if (profName.isEmpty) {
      _p.remove('profName');
    } else {
      _p.setString('profName', profName);
    }
    notifyListeners();
  }

  void openGames() {
    layer = Layer.games;
    pickIdx = 0;
    notifyListeners();
  }

  void closeLayer() {
    if (layer == Layer.gameInfo && shotOpen >= 0) {
      shotOpen = -1;
      sfx('back');
      notifyListeners();
      return;
    }
    layer = Layer.none;
    sfx('back');
    notifyListeners();
  }

  // ---------- toques ----------
  void tapHome(int i) {
    homeIdx = i;
    sfx('ok');
    activate(i, recent: true);
    notifyListeners();
  }

  void tapLib(int i) {
    libIdx = i;
    sfx('ok');
    activate(i);
    notifyListeners();
  }

  void tapStore(int i) {
    storeIdx = i;
    sfx('ok');
    openInfo(i);
  }

  // ---------- detalhes do jogo (Loja) ----------
  void openInfo(int i) {
    storeIdx = i;
    infoIdx = i;
    infoFocus = 0;
    relIdx = 0;
    trIdx = 0;
    shotOpen = -1;
    infoMsg = '';
    layer = Layer.gameInfo;
    notifyListeners();
    // trailer em vídeo: abre em tela cheia e já toca, sem precisar clicar
    if (kAutoTrailer && trailerVideoId(trailerFor(storeTitles[i])) != null) {
      openLink(trailerPlayUrl(storeTitles[i]));
    }
  }

  void infoPlay() {
    sfx('ok');
    layer = Layer.none;
    playStore(infoIdx);
  }

  void infoPin() {
    sfx('ok');
    togglePin(storeTitles[infoIdx]);
  }

  void openTrailer() {
    sfx('ok');
    openLink(trailerPlayUrl(storeTitles[infoIdx]));
  }

  void closeShot() {
    shotOpen = -1;
    sfx('back');
    notifyListeners();
  }

  /// Toque/A numa captura: abre em tela cheia.
  void openShot(int k) {
    sfx('ok');
    shotOpen = k;
    notifyListeners();
  }

  void tapTrailerRow(int idx) {
    infoFocus = 4;
    trIdx = idx;
    if (idx == 0) {
      openTrailer();
    } else {
      openShot(idx - 1);
    }
  }

  Future<void> infoShare() async {
    sfx('ok');
    final t = storeTitles[infoIdx];
    final link = storeLink(t);
    await Clipboard.setData(ClipboardData(text: link.isNotEmpty ? link : t));
    infoMsg = link.isNotEmpty ? 'Link copiado' : 'Nome copiado';
    notifyListeners();
  }

  void _infoAct(Act a) {
    if (a == Act.cancel) {
      closeLayer();
      return;
    }
    if (a == Act.details) {
      infoPin();
      return;
    }
    final rel = relatedTo(infoIdx);
    final nShots = shotsFor(storeTitles[infoIdx]).length;
    if (shotOpen >= 0) {
      if (a == Act.left && shotOpen > 0) {
        shotOpen--;
        sfx('move');
      } else if (a == Act.right && shotOpen < nShots - 1) {
        shotOpen++;
        sfx('move');
      } else if (a == Act.accept) {
        shotOpen = -1;
        sfx('back');
      }
      notifyListeners();
      return;
    }
    if (infoFocus == 4) {
      if (a == Act.left && trIdx > 0) {
        trIdx--;
        sfx('move');
      } else if (a == Act.right && trIdx < nShots) {
        trIdx++;
        sfx('move');
      } else if (a == Act.up) {
        infoFocus = 0;
        sfx('move');
      } else if (a == Act.down && rel.isNotEmpty) {
        infoFocus = 3;
        sfx('move');
      } else if (a == Act.accept) {
        tapTrailerRow(trIdx);
        return;
      }
    } else if (infoFocus == 3) {
      if (a == Act.left && relIdx > 0) {
        relIdx--;
        sfx('move');
      } else if (a == Act.right && relIdx < rel.length - 1) {
        relIdx++;
        sfx('move');
      } else if (a == Act.up) {
        infoFocus = 4;
        sfx('move');
      } else if (a == Act.accept && rel.isNotEmpty) {
        sfx('ok');
        openInfo(rel[relIdx.clamp(0, rel.length - 1).toInt()]);
        return;
      }
    } else {
      if (a == Act.left && infoFocus > 0) {
        infoFocus--;
        sfx('move');
      } else if (a == Act.right && infoFocus < 2) {
        infoFocus++;
        sfx('move');
      } else if (a == Act.down) {
        infoFocus = 4;
        sfx('move');
      } else if (a == Act.accept) {
        if (infoFocus == 0) {
          infoPlay();
        } else if (infoFocus == 1) {
          infoPin();
        } else {
          infoShare();
        }
        return;
      }
    }
    notifyListeners();
  }

  void tapCat(int c) {
    setCat = c;
    setIdx = settingCats[c].rows.first;
    setSide = true;
    sfx('move');
    notifyListeners();
  }

  void tapRow(int i) {
    setIdx = i;
    setCat = catOfRow(i);
    setSide = false;
    sfx('ok');
    changeRow(i, 0);
    notifyListeners();
  }

  // ---------- entrada (teclado / controle) ----------
  int? _target(Act a, int cur, int n, int cols) {
    switch (a) {
      case Act.left:
        return cur > 0 ? cur - 1 : null;
      case Act.right:
        return cur < n - 1 ? cur + 1 : null;
      case Act.up:
        return cur - cols >= 0 ? cur - cols : null;
      case Act.down:
        if (cur + cols < n) return cur + cols;
        return (cur ~/ cols < (n - 1) ~/ cols) ? n - 1 : null;
      default:
        return null;
    }
  }

  bool _nav(Act a, int n, int cols, int cur, void Function(int) set) {
    if (n == 0) return false;
    final t = _target(a, cur, n, cols);
    if (t == null) return false;
    set(t);
    sfx('move');
    notifyListeners();
    return true;
  }

  void act(Act a) {
    if (!ready) return;
    if (idle) {
      wake();
      return;
    }
    lastInput = DateTime.now();
    if (gameUrl != null) {
      if (gameMenu) {
        _quickAct(a);
      } else if (a == Act.cancel) {
        closeGame();
      }
      return;
    }
    // X vira "detalhes" nas telas onde ele já fixava/atualizava (Loja, Config e camadas)
    if (a == Act.favorite && (layer != Layer.none || tab >= 2)) a = Act.details;
    if (layer != Layer.none) {
      _layerAct(a);
      return;
    }
    if (a == Act.menu) {
      openQuick();
      return;
    }
    if (a == Act.search) {
      openSearch();
      return;
    }
    if (a == Act.favorite) {
      favoriteCurrent();
      return;
    }
    if (a == Act.filterNext || a == Act.filterPrev) {
      if (tab == 1) setFilter(a == Act.filterNext ? 1 : -1);
      return;
    }
    if (a == Act.next) {
      final p = tabOrder.indexOf(tab);
      if (p < tabOrder.length - 1) setTab(tabOrder[p + 1]);
      return;
    }
    if (a == Act.prev) {
      final p = tabOrder.indexOf(tab);
      if (p > 0) setTab(tabOrder[p - 1]);
      return;
    }
    if (a == Act.cancel) {
      if (tab == 3 && !setSide) {
        setSide = true;
        sfx('back');
        notifyListeners();
      } else if (tab != 0) {
        setTab(0);
      } else {
        sfx('back');
      }
      return;
    }
    const far = 1000000;
    switch (tab) {
      case 0:
        if (a == Act.accept) {
          sfx('ok');
          activate(homeIdx, recent: true);
        } else {
          _nav(a, recentItems.length, far, homeIdx, (v) => homeIdx = v);
        }
      case 1:
        if (a == Act.accept) {
          sfx('ok');
          activate(libIdx);
        } else {
          _nav(a, libItems.length, libCols, libIdx, (v) => libIdx = v);
        }
      case 2:
        if (a == Act.accept) {
          sfx('ok');
          openInfo(storeIdx);
        } else if (a == Act.details) {
          sfx('ok');
          togglePin(storeTitles[storeIdx]);
        } else {
          _nav(a, storeTitles.length, storeCols, storeIdx, (v) => storeIdx = v);
        }
      default:
        final rows = settingCats[setCat].rows;
        if (setSide) {
          if (a == Act.up || a == Act.down) {
            _nav(a, settingCats.length, 1, setCat, (v) {
              setCat = v;
              setIdx = settingCats[v].rows.first;
            });
          } else if (a == Act.accept || a == Act.right) {
            setSide = false;
            if (!rows.contains(setIdx)) setIdx = rows.first;
            sfx('ok');
            notifyListeners();
          }
        } else {
          if (!rows.contains(setIdx)) setIdx = rows.first;
          const adjustable = {'choice', 'wall', 'cloud', 'volume', 'pick', 'pickvideo'};
          if (a == Act.accept) {
            sfx('ok');
            changeRow(setIdx, 0);
          } else if (a == Act.left) {
            if (adjustable.contains(settingRows[setIdx].kind)) {
              changeRow(setIdx, -1);
            } else {
              setSide = true;
              sfx('back');
              notifyListeners();
            }
          } else if (a == Act.right) {
            changeRow(setIdx, 1);
          } else if (a == Act.up || a == Act.down) {
            _nav(a, rows.length, 1, rows.indexOf(setIdx), (v) => setIdx = rows[v]);
          }
        }
    }
  }

  void _layerAct(Act a) {
    if (layer == Layer.gameInfo) {
      _infoAct(a);
      return;
    }
    if (layer == Layer.profile) {
      _profileAct(a);
      return;
    }
    if (layer == Layer.panel) {
      _quickAct(a);
      return;
    }
    if (layer == Layer.search) {
      _searchAct(a);
      return;
    }
    if (layer == Layer.wifi || layer == Layer.bt) {
      if (a == Act.up || a == Act.down) {
        _nav(a, netCount, 1, netIdx, (v) => netIdx = v);
      } else if (a == Act.cancel) {
        closeLayer();
      } else if (a == Act.details) {
        scanNet();
      } else if (a == Act.accept) {
        sfx('ok');
        netAccept();
      }
      return;
    }
    final isGames = layer == Layer.games;
    final n = layer == Layer.editStore ? storeTitles.length : apps.length;
    final cur = isGames ? pickIdx : editIdx;
    if (a == Act.up || a == Act.down) {
      _nav(a, n, 1, cur, (v) => isGames ? pickIdx = v : editIdx = v);
      return;
    }
    if (a == Act.cancel || (a == Act.details && isGames)) {
      closeLayer();
      return;
    }
    if (n == 0) return;
    if (isGames) {
      if (a == Act.accept) {
        sfx('ok');
        toggleApp(apps[pickIdx].package);
      }
      return;
    }
    final store = layer == Layer.editStore;
    final key = store ? storeTitles[editIdx] : apps[editIdx].package;
    if (a == Act.accept) {
      sfx('ok');
      pickFor(store, key);
    } else if (a == Act.right || a == Act.details) {
      clearMapped(store, key);
    }
  }

  // ---------- sons ----------
  Future<void> sfx(String name) async {
    if (!soundOn || !_sfxReady) return;
    try {
      final p = _players.putIfAbsent(name, () => AudioPlayer());
      await p.stop();
      await p.play(AssetSource('sounds/$name.wav'), volume: 0.8);
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _featTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    for (final p in _players.values) {
      p.dispose();
    }
    super.dispose();
  }
}
