import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

/// Rede/Microsoft fora do ar, sem internet etc. (não deve virar "sem capa").
class CoverNetError implements Exception {
  final String why;
  CoverNetError([this.why = '']);
}

/// Busca capas de jogos no catálogo da Microsoft Store (o mesmo da Xbox/Microsoft Store).
/// 1) autosuggest procura o jogo pelo nome; 2) a ficha do produto traz o Poster/BoxArt.
class MsCovers {
  static const _host = 'displaycatalog.mp.microsoft.com';
  static const _lang = 'market=US&languages=en-US';
  static final HttpClient _http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 10)
    ..userAgent = 'Mozilla/5.0 (Linux; Android 13) Ryzen/2.0';

  static Future<List<int>> _get(Uri u) async {
    try {
      final req = await _http.getUrl(u).timeout(const Duration(seconds: 12));
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        await res.drain<void>();
        if (res.statusCode >= 500 || res.statusCode == 429) throw CoverNetError();
        return const [];
      }
      final b = <int>[];
      await for (final c in res.timeout(const Duration(seconds: 30))) {
        b.addAll(c);
      }
      return b;
    } on CoverNetError {
      rethrow;
    } catch (_) {
      throw CoverNetError();
    }
  }

  static Future<dynamic> _json(Uri u) async {
    final b = await _get(u);
    if (b.isEmpty) return null;
    try {
      return jsonDecode(utf8.decode(b));
    } catch (_) {
      return null;
    }
  }

  static String _clean(String n) => n
      .toLowerCase()
      .replaceAll(RegExp(r'[\(\[].*?[\)\]]'), ' ')
      .replaceAll(RegExp(r'[™®©:\-–_]'), ' ')
      .replaceAll(RegExp(r'[^a-z0-9 ]'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  /// 0 = não é o jogo; maior = melhor correspondência.
  static int _score(String want, String got) {
    final a = _clean(want), b = _clean(got);
    if (a.isEmpty || b.isEmpty) return 0;
    if (a == b) return 4;
    final short = a.length <= b.length ? a : b;
    final long = a.length <= b.length ? b : a;
    if (short.length >= 4 && (long.startsWith('$short ') || long.endsWith(' $short'))) return 3;
    final ta = a.split(' ').toSet(), tb = b.split(' ').toSet();
    final inter = ta.intersection(tb).length;
    final uni = ta.union(tb).length;
    return uni > 0 && inter / uni >= 0.75 ? 2 : 0;
  }

  static String _https(String u) => u.startsWith('//') ? 'https:$u' : u;

  /// Melhor correspondência do jogo no autosuggest da Microsoft.
  static Future<Map?> _bestMatch(String name) async {
    final q = _clean(name);
    if (q.length < 2) return null;
    final j = await _json(Uri.https(_host, '/v7.0/productFamilies/autosuggest', {
      'market': 'US',
      'languages': 'en-US',
      'query': q,
      'mediaType': 'games',
    }));
    if (j is! Map) return null;
    Map? best;
    var bestScore = 0;
    for (final rs in (j['ResultSets'] as List? ?? const [])) {
      for (final s in ((rs as Map)['Suggests'] as List? ?? const [])) {
        final m = s as Map;
        final src = (m['Source'] ?? 'Games').toString();
        if (src != 'Games') continue;
        final sc = _score(name, (m['Title'] ?? '').toString());
        if (sc > bestScore) {
          bestScore = sc;
          best = m;
        }
      }
    }
    return best;
  }

  /// Lista de imagens da ficha do produto (Poster, BoxArt, SuperHeroArt...).
  static Future<List> _images(Map best) async {
    String? bigId;
    for (final meta in (best['Metas'] as List? ?? const [])) {
      if ((meta as Map)['Key'] == 'BigCatalogId') bigId = meta['Value']?.toString();
    }
    if (bigId == null) return const [];
    final p = await _json(Uri.parse(
        'https://$_host/v7.0/products?bigIds=$bigId&$_lang&MS-CV=DGU1mcuYo0WMMp+F.1'));
    try {
      return (((p as Map)['Products'] as List).first['LocalizedProperties'] as List).first['Images']
          as List;
    } catch (_) {
      return const [];
    }
  }

  /// Devolve o link da capa (ou null se o jogo não existe no catálogo).
  static Future<String?> findUrl(String name) async {
    final best = await _bestMatch(name);
    if (best == null) return null;
    final imgs = await _images(best);
    for (final purpose in const ['Poster', 'BoxArt', 'Tile', 'Logo']) {
      for (final im in imgs) {
        if (im['ImagePurpose'] == purpose && im['Uri'] != null) return _https(im['Uri'].toString());
      }
    }
    final fallback = best['ImageUrl']?.toString();
    return fallback == null || fallback.isEmpty ? null : _https(fallback);
  }

  /// Devolve o link do BANNER (imagem larga) do jogo, ou null se não houver.
  static Future<String?> findBannerUrl(String name) async {
    final best = await _bestMatch(name);
    if (best == null) return null;
    final imgs = await _images(best);
    for (final purpose in const ['SuperHeroArt', 'TitledHeroArt', 'BrandedKeyArt', 'Hero']) {
      for (final im in imgs) {
        if (im['ImagePurpose'] == purpose && im['Uri'] != null) return _https(im['Uri'].toString());
      }
    }
    return null;
  }

  /// Procura e baixa a capa para [dest]. Retorna o caminho ou null (sem capa).
  static Future<String?> download(String name, File dest) async {
    final url = await findUrl(name);
    if (url == null) return null;
    var bytes = await _get(Uri.parse('$url${url.contains('?') ? '&' : '?'}w=600'));
    if (bytes.length < 1500) bytes = await _get(Uri.parse(url));
    if (bytes.length < 1500) return null;
    await dest.parent.create(recursive: true);
    await dest.writeAsBytes(bytes, flush: true);
    return dest.path;
  }
}


/// Banner (imagem larga) do card da Início: buscado só no uhdpaper.com.
class BannerSearch {
  static final HttpClient _http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 10)
    ..userAgent = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  /// Último erro de rede visto (para mostrar no app).
  static String lastErr = '';
  /// Tamanho da última imagem recusada por proporção/tamanho (para mostrar no app).
  static String lastShape = '';

  /// Baixa uma URL; falha de uma página não derruba a busca (devolve vazio).
  static Future<List<int>> _fetch(String url, {int max = 30 * 1024 * 1024, Map<String, String>? headers}) async {
    try {
      final req = await _http.getUrl(Uri.parse(url)).timeout(const Duration(seconds: 20));
      headers?.forEach(req.headers.set);
      final res = await req.close().timeout(const Duration(seconds: 40));
      if (res.statusCode != 200) {
        await res.drain<void>();
        lastErr = 'HTTP ${res.statusCode} em ${Uri.parse(url).host}';
        return const [];
      }
      final b = BytesBuilder(copy: false); // 1 byte por byte (uma lista de int gastaria 8x de memória)
      await for (final c in res.timeout(const Duration(seconds: 60))) {
        b.add(c);
        if (b.length > max) {
          lastErr = 'arquivo grande demais';
          return const [];
        }
      }
      return b.takeBytes();
    } catch (e) {
      lastErr = '${e.runtimeType} em ${Uri.parse(url).host}';
      return const [];
    }
  }

  /// Banner maior que 1920 px de largura é reduzido para 1920 (menos memória e carrega mais rápido).
  static Future<List<int>> _shrink(Uint8List bytes) async {
    try {
      final c0 = await ui.instantiateImageCodec(bytes);
      final f0 = (await c0.getNextFrame()).image;
      final w = f0.width;
      f0.dispose();
      c0.dispose();
      if (w <= 1920) return bytes;
      final c = await ui.instantiateImageCodec(bytes, targetWidth: 1920);
      final f = (await c.getNextFrame()).image;
      final d = await f.toByteData(format: ui.ImageByteFormat.png);
      f.dispose();
      c.dispose();
      return d == null ? bytes : d.buffer.asUint8List();
    } catch (_) {
      return bytes;
    }
  }

  /// Imagem de verdade com a proporção pedida (banner = larga; capa = em pé).
  static Future<bool> _shape(List<int> bytes, {required bool wide, required int minW}) async {
    if (bytes.length < 5000) return false;
    try {
      final codec = await ui.instantiateImageCodec(Uint8List.fromList(bytes));
      final f = (await codec.getNextFrame()).image;
      final r = f.width / f.height;
      final ok = f.width >= minW && (wide ? r >= 1.5 : (r <= 0.85 && r >= 0.5));
      if (!ok) lastShape = '${f.width}x${f.height}';
      f.dispose();
      codec.dispose();
      return ok;
    } catch (_) {
      return false;
    }
  }

  /// Quantos quadros a imagem tem (>1 = animada).
  static Future<int> _frames(List<int> bytes) async {
    try {
      final codec = await ui.instantiateImageCodec(Uint8List.fromList(bytes));
      final n = codec.frameCount;
      codec.dispose();
      return n;
    } catch (_) {
      return 0;
    }
  }

  /// Imagens (miniaturas) de uma página do uhdpaper, já pedindo a versão grande (s1920).
  static List<String> _images(String html) {
    final out = <String>[];
    final re = RegExp(r"""https?://[^"'\s)<>]*?(?:blogger\.googleusercontent\.com|bp\.blogspot\.com|uhdpaper\.com)[^"'\s)<>]*""");
    for (final m in re.allMatches(html)) {
      var u = m.group(0)!.replaceAll('&amp;', '&');
      final low = u.toLowerCase();
      if (low.contains('avatar') || low.contains('logo') || low.contains('favicon')) continue;
      u = u.replaceFirst(RegExp(r'/(?:s\d+|w\d+-h\d+)(?:-[a-z]+)*/'), '/s1920/');
      if (!out.contains(u)) out.add(u);
      if (out.length >= 12) break;
    }
    return out;
  }

  static Future<List<int>?> _firstGood(Iterable<String> urls, {int minW = 1000}) async {
    for (final u in urls) {
      final b = await _fetch(u);
      if (await _shape(b, wide: true, minW: minW)) return b;
    }
    return null;
  }

  static const _browser = {
    'Accept': 'text/html,application/xhtml+xml,application/json,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': 'https://www.uhdpaper.com/',
  };

  /// Retorna (bytes, achouAlgumaResposta). Tenta o feed do Blogger e depois a busca em HTML.
  static Future<(List<int>?, bool)> _uhd(String name) async {
    var online = false;
    final q = Uri.encodeQueryComponent(name);
    // 1) feed do Blogger (JSON): o jeito estável de buscar posts de um blog
    final fr = await _fetch('https://www.uhdpaper.com/feeds/posts/default?q=$q&alt=json&max-results=6',
        max: 3 * 1024 * 1024, headers: _browser);
    if (fr.isNotEmpty) {
      online = true;
      try {
        final j = jsonDecode(utf8.decode(fr, allowMalformed: true));
        final urls = <String>[];
        for (final e in (j['feed']['entry'] as List? ?? const [])) {
          final c = (e['content'] is Map ? e['content'][r'$t'] : null)?.toString() ?? '';
          urls.addAll(_images(c));
          final th = e['media\$thumbnail'];
          if (th is Map && th['url'] != null) urls.addAll(_images(th['url'].toString()));
        }
        final b = await _firstGood(urls.toSet());
        if (b != null) return (b, true);
      } catch (_) {}
    }
    // 2) página de busca em HTML (versão mobile)
    final r = await _fetch('https://www.uhdpaper.com/search?q=$q&m=1', max: 3 * 1024 * 1024, headers: _browser);
    if (r.isNotEmpty) {
      online = true;
      final html = utf8.decode(r, allowMalformed: true);
      final first = await _firstGood(_images(html));
      if (first != null) return (first, true);
      final posts = <String>[];
      for (final m in RegExp(r"""https?://www\.uhdpaper\.com/\d{4}/\d{2}/[^"'\s#?<>]+\.html""").allMatches(html)) {
        if (!posts.contains(m.group(0)!)) posts.add(m.group(0)!);
        if (posts.length >= 3) break;
      }
      for (final pu in posts) {
        final pr = await _fetch(pu, max: 3 * 1024 * 1024, headers: _browser);
        if (pr.isEmpty) continue;
        final b = await _firstGood(_images(utf8.decode(pr, allowMalformed: true)));
        if (b != null) return (b, true);
      }
    }
    return (null, online);
  }

  /// Baixa o banner direto de um link. null = o link não abriu ou não é imagem larga; CoverNetError = sem internet.
  static Future<String?> fromUrl(String url, File dest) async {
    final u = Uri.tryParse(url.trim());
    if (u == null || !u.hasScheme) return null;
    final urls = <String>[url.trim()];
    if (u.host.contains('steamstatic.com') || u.host.contains('akamaihd.net')) {
      for (final h in const ['cdn.cloudflare.steamstatic.com', 'cdn.akamai.steamstatic.com', 'steamcdn-a.akamaihd.net']) {
        final alt = u.replace(host: h).toString();
        if (!urls.contains(alt)) urls.add(alt);
      }
    }
    String? netErr;
    for (final x in urls) {
      lastErr = '';
      lastShape = '';
      var b = await _fetch(x, headers: const {'Accept': 'image/*,*/*;q=0.8'});
      if (b.isEmpty && lastErr.isNotEmpty && !lastErr.startsWith('HTTP') && !lastErr.startsWith('arquivo')) {
        b = await _fetch(x, headers: const {'Accept': 'image/*,*/*;q=0.8'}); // uma nova tentativa (conexão lenta)
      }
      if (b.isEmpty) {
        if (lastErr.isNotEmpty && !lastErr.startsWith('HTTP') && !lastErr.startsWith('arquivo')) netErr = lastErr;
        continue;
      }
      if (await _shape(b, wide: true, minW: 800)) {
        final small = await _shrink(Uint8List.fromList(b));
        await dest.parent.create(recursive: true);
        await dest.writeAsBytes(small, flush: true);
        return dest.path;
      }
    }
    if (netErr != null) throw CoverNetError(netErr);
    return null;
  }

  /// Procura no uhdpaper e grava em [dest]. null = não achou; CoverNetError = sem internet/bloqueio.
  static Future<String?> download(String name, File dest) async {
    final (b, online) = await _uhd(name);
    if (b == null) {
      if (!online) throw CoverNetError(lastErr);
      return null;
    }
    await dest.parent.create(recursive: true);
    await dest.writeAsBytes(b, flush: true);
    return dest.path;
  }
}


/// Capas (em pé) dos jogos da LOJA, buscadas no catálogo do Xbox (a mesma base do xbox.com/games e do play.xbox.com).
/// Passos: 1) procura o jogo pelo nome; 2) abre a ficha do produto; 3) baixa o Poster (ou BoxArt) para um arquivo só dele.
class XboxStoreCovers {
  static const _host = 'displaycatalog.mp.microsoft.com';
  static final HttpClient _http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 10)
    ..userAgent = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  /// Motivo da última falha (mostrado no rodapé da Loja para a gente saber o que deu errado).
  static String lastReason = '';

  /// Baixa uma URL. Sem internet/servidor fora do ar → CoverNetError. 404 etc. → lista vazia (e motivo).
  static Future<List<int>> _bytes(Uri u, {int max = 8 * 1024 * 1024}) async {
    try {
      final req = await _http.getUrl(u).timeout(const Duration(seconds: 12));
      req.headers.set('Accept', 'application/json, image/*, */*;q=0.8');
      req.headers.set('Accept-Language', 'pt-BR,pt;q=0.9,en;q=0.8');
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        await res.drain<void>();
        lastReason = 'HTTP ${res.statusCode} em ${u.host}';
        if (res.statusCode >= 500 || res.statusCode == 429) throw CoverNetError(lastReason);
        return const [];
      }
      final b = <int>[];
      await for (final c in res.timeout(const Duration(seconds: 30))) {
        b.addAll(c);
        if (b.length > max) {
          lastReason = 'arquivo grande demais';
          return const [];
        }
      }
      return b;
    } on CoverNetError {
      rethrow;
    } catch (e) {
      lastReason = '${e.runtimeType} em ${u.host}';
      throw CoverNetError(lastReason);
    }
  }

  static Future<dynamic> _json(Uri u) async {
    final b = await _bytes(u, max: 4 * 1024 * 1024);
    if (b.isEmpty) return null;
    try {
      return jsonDecode(utf8.decode(b, allowMalformed: true));
    } catch (_) {
      lastReason = 'resposta inválida de ${u.host}';
      return null;
    }
  }

  static String _https(String u) => u.startsWith('//') ? 'https:$u' : u;

  static String _bigId(Map m) {
    for (final meta in (m['Metas'] as List? ?? const [])) {
      if (meta is Map && meta['Key'] == 'BigCatalogId') return (meta['Value'] ?? '').toString();
    }
    return '';
  }

  /// 1) Procura o jogo no Xbox: tenta Brasil (pt-BR) e depois EUA (en-US); aceita só nome parecido.
  static Future<Map?> _search(String name) async {
    final q = MsCovers._clean(name);
    if (q.length < 2) return null;
    Map? best;
    var bestScore = 0;
    var answered = false;
    for (final v in const [
      ['BR', 'pt-BR', 'games'],
      ['US', 'en-US', 'games'],
      ['US', 'en-US', ''],
    ]) {
      final j = await _json(Uri.https(_host, '/v7.0/productFamilies/autosuggest', {
        'market': v[0],
        'languages': v[1],
        'query': q,
        if (v[2].isNotEmpty) 'mediaType': v[2],
      }));
      if (j is! Map) continue;
      answered = true;
      for (final rs in (j['ResultSets'] as List? ?? const [])) {
        if (rs is! Map) continue;
        for (final sg in (rs['Suggests'] as List? ?? const [])) {
          if (sg is! Map || _bigId(sg).isEmpty) continue;
          final sc = MsCovers._score(name, (sg['Title'] ?? '').toString());
          if (sc > bestScore) {
            bestScore = sc;
            best = sg;
          }
        }
      }
      if (bestScore >= 3) break; // achou uma boa, não precisa tentar as outras
    }
    if (best == null) lastReason = answered ? 'jogo não encontrado no Xbox' : lastReason;
    return best;
  }

  /// Link para jogar no xCloud: procura o jogo no catálogo do Xbox, pega o ID do produto
  /// e monta play.xbox.com/stream/<ID>/<nome>. null = não achei.
  static Future<String?> playLink(String name) async {
    final best = await _search(name);
    if (best == null) return null;
    final id = _bigId(best);
    if (id.isEmpty) return null;
    final slug = MsCovers._clean(name).replaceAll(' ', '-');
    return 'https://play.xbox.com/stream/$id/$slug';
  }

  /// 2) Ficha do produto: lista de imagens (Poster, BoxArt, Tile...).
  static Future<List> _images(Map best) async {
    final id = _bigId(best);
    for (final v in const [
      ['BR', 'pt-BR'],
      ['US', 'en-US']
    ]) {
      final p = await _json(Uri.https(_host, '/v7.0/products', {
        'bigIds': id,
        'market': v[0],
        'languages': v[1],
        'MS-CV': 'DGU1mcuYo0WMMp+F.1',
      }));
      try {
        final imgs = (((p as Map)['Products'] as List).first['LocalizedProperties'] as List).first['Images'] as List;
        if (imgs.isNotEmpty) return imgs;
      } catch (_) {}
    }
    lastReason = 'ficha do jogo sem imagens';
    return const [];
  }

  /// Confere se o arquivo é uma imagem de verdade e com formato de capa.
  static Future<bool> _isCover(List<int> b, {required bool portraitOnly}) async {
    if (b.length < 5000) return false;
    try {
      final codec = await ui.instantiateImageCodec(Uint8List.fromList(b));
      final f = (await codec.getNextFrame()).image;
      final r = f.width / f.height;
      final ok = f.width >= 200 && (portraitOnly ? r <= 0.85 : r <= 1.15);
      f.dispose();
      codec.dispose();
      return ok;
    } catch (_) {
      return false;
    }
  }

  static Future<List<int>?> _tryUrl(String url, {required bool portraitOnly}) async {
    final sep = url.contains('?') ? '&' : '?';
    for (final u in ['$url${sep}w=600&format=jpg', url]) {
      final b = await _bytes(Uri.parse(u));
      if (await _isCover(b, portraitOnly: portraitOnly)) return b;
    }
    return null;
  }

  /// Baixa a capa de um link DIRETO de imagem (ex.: library_600x900.jpg da Steam). Link que não é imagem
  /// (como página do SteamGridDB) é ignorado. Se o servidor da Steam falhar, tenta os espelhos dela.
  static Future<String?> fromUrl(String url, File dest) async {
    final u = Uri.tryParse(url.trim());
    if (u == null || !u.hasScheme) return null;
    final path = u.path.toLowerCase();
    if (!(path.endsWith('.jpg') || path.endsWith('.jpeg') || path.endsWith('.png') || path.endsWith('.webp'))) {
      lastReason = 'link da capa não é imagem direta';
      return null;
    }
    final urls = <String>[url.trim()];
    if (u.host.contains('steamstatic.com') || u.host.contains('akamaihd.net')) {
      for (final h in const ['cdn.cloudflare.steamstatic.com', 'cdn.akamai.steamstatic.com', 'steamcdn-a.akamaihd.net']) {
        final alt = u.replace(host: h).toString();
        if (!urls.contains(alt)) urls.add(alt);
      }
    }
    for (final x in urls) {
      List<int> b;
      try {
        b = await _bytes(Uri.parse(x));
      } on CoverNetError {
        continue; // tenta o próximo espelho
      }
      if (await _isCover(b, portraitOnly: true)) {
        await dest.parent.create(recursive: true);
        await dest.writeAsBytes(b, flush: true);
        return dest.path;
      }
    }
    if (lastReason.isEmpty) lastReason = 'capa do link não abriu';
    return null;
  }

  /// 3) Procura, baixa e grava a capa em [dest]. null = não achei (veja [lastReason]); CoverNetError = sem rede.
  static Future<String?> download(String name, File dest) async {
    final best = await _search(name);
    if (best == null) return null;
    final imgs = await _images(best);
    List<int>? got;
    // primeiro só capas em pé (Poster); depois aceita quadradas (BoxArt/Tile) — o card corta com BoxFit.cover
    for (final portraitOnly in const [true, false]) {
      for (final purpose in const ['Poster', 'BoxArt', 'Tile']) {
        if (portraitOnly && purpose != 'Poster') continue;
        for (final im in imgs) {
          if (im is! Map || im['ImagePurpose'] != purpose || im['Uri'] == null) continue;
          got = await _tryUrl(_https(im['Uri'].toString()), portraitOnly: portraitOnly);
          if (got != null) break;
        }
        if (got != null) break;
      }
      if (got != null) break;
    }
    if (got == null) {
      final fb = (best['ImageUrl'] ?? '').toString();
      if (fb.isNotEmpty) got = await _tryUrl(_https(fb), portraitOnly: false);
    }
    if (got == null) {
      if (imgs.isNotEmpty) lastReason = 'nenhuma imagem em formato de capa';
      return null;
    }
    await dest.parent.create(recursive: true);
    await dest.writeAsBytes(got, flush: true);
    return dest.path;
  }
}

/// Capa (em pé) e banner (largo) automáticos pela Steam, sem chave de API:
/// procura o jogo pelo nome na loja da Steam e baixa library_600x900 (capa) e library_hero (banner).
class SteamArt {
  static final Map<String, int> _ids = {};

  static Future<int?> _id(String name) async {
    final have = _ids[name];
    if (have != null) return have;
    final q = MsCovers._clean(name);
    if (q.length < 2) return null;
    final b = await BannerSearch._fetch(Uri.https('store.steampowered.com', '/api/storesearch/', {
      'term': q,
      'l': 'english',
      'cc': 'US',
    }).toString());
    int? best;
    var bestScore = 0;
    try {
      final j = jsonDecode(utf8.decode(b));
      for (final it in (j['items'] as List? ?? const [])) {
        final sc = MsCovers._score(name, (it['name'] ?? '').toString());
        if (sc > bestScore) {
          bestScore = sc;
          best = (it['id'] as num).toInt();
        }
      }
    } catch (_) {}
    if (best != null) _ids[name] = best;
    return best;
  }

  static Future<String?> _grab(String name, File dest, String file, {required bool wide, required int minW}) async {
    try {
      final id = await _id(name);
      if (id == null) return null;
      for (final h in const ['cdn.cloudflare.steamstatic.com', 'cdn.akamai.steamstatic.com']) {
        final b = await BannerSearch._fetch('https://$h/steam/apps/$id/$file', headers: const {'Accept': 'image/*,*/*;q=0.8'});
        if (b.isNotEmpty && await BannerSearch._shape(b, wide: wide, minW: minW)) {
          await dest.parent.create(recursive: true);
          await dest.writeAsBytes(b, flush: true);
          return dest.path;
        }
      }
    } catch (_) {}
    return null;
  }

  static Future<String?> downloadCover(String name, File dest) =>
      _grab(name, dest, 'library_600x900.jpg', wide: false, minW: 400);

  static Future<String?> downloadBanner(String name, File dest) =>
      _grab(name, dest, 'library_hero.jpg', wide: true, minW: 1000);
}

/// Capa direta: baixa o link do arquivo de capas (SteamGridDB) sem exigir formato específico.
class CatalogCovers {
  static Future<String?> download(String url, File dest) async {
    try {
      final b = await BannerSearch._fetch(url.trim(), headers: const {'Accept': 'image/*,*/*;q=0.8'});
      if (b.length < 3000) return null;
      final codec = await ui.instantiateImageCodec(Uint8List.fromList(b));
      final f = (await codec.getNextFrame()).image;
      final ok = f.width >= 200 && f.height >= 200;
      f.dispose();
      codec.dispose();
      if (!ok) return null;
      await dest.parent.create(recursive: true);
      await dest.writeAsBytes(b, flush: true);
      return dest.path;
    } catch (_) {
      return null;
    }
  }
}
